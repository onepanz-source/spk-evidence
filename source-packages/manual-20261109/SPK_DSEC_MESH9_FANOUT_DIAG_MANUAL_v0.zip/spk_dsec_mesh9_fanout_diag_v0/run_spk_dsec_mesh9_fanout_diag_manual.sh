#!/usr/bin/env bash
# SPK DSEC fixed-input fanout diagnostic, manual on fwork, no source checkout writes.
set -Eeuo pipefail
export LC_ALL=C
export PYTHONDONTWRITEBYTECODE=1
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO="${1:-${SPK_REPO:-$HOME/workspace/spk-backvalidation-v0}}"
for cmd in python3 git tar sha256sum; do command -v "$cmd" >/dev/null || { echo "COMANDO_MANCANTE: $cmd" >&2; exit 3; }; done
( cd "$ROOT" && sha256sum -c CODE_SHA256SUMS ) || { echo SOURCE_PACKAGE_SHA256_MISMATCH >&2; exit 4; }
EV="${SPK_DSEC_EVENTS_ZIP:-$HOME/Scaricati/train_events.zip}"
FLOW="${SPK_DSEC_FLOW_ZIP:-$HOME/Scaricati/train_optical_flow.zip}"
INTAKE="${SPK_DSEC_INTAKE:-$HOME/workspace/spk-dsec-intake}"
[[ -f "$EV" && -f "$FLOW" ]] || { echo "DSEC_ZIPS_MISSING $EV $FLOW" >&2; exit 3; }
python3 -c 'import numpy, h5py, hdf5plugin' || { echo 'ACTIVATE_DSEC_VENV: numpy h5py hdf5plugin' >&2; exit 3; }
( cd "$ROOT" && python3 -m unittest -q test_spk_dsec_mesh9_fanout_diag_v0 test_spk_dsec_mesh9_dev_v0 test_spk_mesh9_ethgateway_ref_v1 test_spk_mesh9_hybrid_ref_v0 test_spk_mesh8x64_ref_v0 )
[[ -e "$REPO/.git" ]] || { echo "SPK_REPO_MISSING: $REPO" >&2; exit 3; }
MAIN=787c8fbed87c1e2e4b703e985f68ae53c81c8444
if ! git -C "$REPO" cat-file -e "${MAIN}^{commit}" 2>/dev/null; then
  echo 'READ_ONLY_PIN_FETCH'
  git -C "$REPO" fetch --no-tags origin "$MAIN"
fi
[[ "$(git -C "$REPO" rev-parse "${MAIN}^{commit}")" == "$MAIN" ]] || { echo ORIGINAL_PE_COMMIT_MISMATCH >&2; exit 4; }
TMP="$(mktemp -d -t spk-dsec-mesh9-fanout-XXXXXXXX)"
trap 'rm -rf -- "$TMP"' EXIT
mkdir -p "$TMP/src"
git -C "$REPO" archive --format=tar "$MAIN" \
 spk_architecture_v1/pe_execution_v1b.py spk_architecture_v1/pe_fabric_v1a.py | tar -xf - -C "$TMP/src"
( cd "$ROOT" && python3 spk_mesh9_ethgateway_ref_v1.py --source-root "$TMP/src" --profile selftest )
OUT_BASE="${SPK_MESH_OUTPUT_BASE:-$HOME/workspace/spk-manual-runs}"
mkdir -p "$OUT_BASE"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$OUT_BASE/${STAMP}-dsec-mesh9-fanout-diag"
[[ ! -e "$OUT" && ! -e "$OUT.tar.gz" ]] || { echo OUTPUT_EXISTS >&2; exit 5; }
echo 'DSEC_DEVELOPMENT_ONLY: raw event H5+rectify+forward timestamp TXT, NO optical flow PNG.'
echo 'COUNTERFACTUAL ENABLED_LOCAL_ROUTES 0,1,2,4,8 x MESH_OFF_ON; original PE/ISA and sensor mapping unchanged.'
( cd "$ROOT" && python3 -u spk_dsec_mesh9_fanout_diag_v0.py \
 --source-root "$TMP/src" --events-zip "$EV" --flow-zip "$FLOW" --intake "$INTAKE" --out "$OUT" ) | tee "$TMP/console.log"
cp "$TMP/console.log" "$OUT/console.log"
( cd "$OUT" && sha256sum console.log >> SHA256SUMS && sha256sum -c SHA256SUMS )
ARCHIVE="$OUT.tar.gz"
tar -czf "$ARCHIVE" -C "$OUT_BASE" "$(basename "$OUT")"
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"
echo "PACCHETTO_EVIDENZE: $ARCHIVE"
echo -n 'SHA256_PACCHETTO: '; sha256sum "$ARCHIVE" | awk '{print $1}'
echo 'Carica qui .tar.gz e .tar.gz.sha256 per audit CIAT. NO FULL MULTIPAIR, NO FLOW GT.'
