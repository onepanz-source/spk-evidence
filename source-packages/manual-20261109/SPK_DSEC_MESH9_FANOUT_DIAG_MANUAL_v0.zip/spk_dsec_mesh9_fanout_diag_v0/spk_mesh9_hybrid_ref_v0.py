#!/usr/bin/env python3
"""SPK nine-island hybrid reference v0: 8 ESP32-C6-class + 1 Raspberry Pi5-class.

This is a new deterministic, bounded simulation scheduler. Each neuron batch
uses ORIGINAL frozen A1b _compute_local() after exact Git blob checks. The model
has NO BV, learning, original P writes, physical 802.15.4 or actual PI5 timing.
The Raspberry Pi5 is assumed to have ONE external 802.15.4 RCP, not built-in
Thread radio, and all its mesh traffic shares ONE finite virtual radio budget.
"""
from __future__ import annotations

import argparse
import collections
from dataclasses import dataclass, asdict
import hashlib
import importlib
import json
from pathlib import Path
import sys

SCHEMA = 'spk-mesh-9-hybrid-c6-pi5-forward-reference/v0'
MAIN = '787c8fbed87c1e2e4b703e985f68ae53c81c8444'
PINS = {
    'spk_architecture_v1/pe_execution_v1b.py': '2e16bdeddc7fc5eacbd341a6dbdf245d71095678',
    'spk_architecture_v1/pe_fabric_v1a.py': 'b0cf8b01a8e5ede6ad640349e11b91194c454763',
}
# Defend against accidental editing of pins; no inferred or newer implementation.
assert PINS['spk_architecture_v1/pe_fabric_v1a.py'] == 'b0cf8b01a8e5ede6ad640349e11b91194c454763'
C6_COUNT = 8
HUB = 8
N_ISLANDS = 9
SIZES = (64,) * 8 + (1024,)
FANOUT = 8
EDGE_OFFSETS = (1, 2, 3, 5, 8, 13, 21, 34)
C6_GATEWAYS = (0, 16, 32, 48)
PI_GATEWAYS = tuple(range(0, 1024, 64))
C6_INGRESS = (8, 24, 40, 56)
PI_INGRESS = tuple(x + 32 for x in PI_GATEWAYS)
C6_QUEUE = 256
PI_QUEUE = 2048
C6_BV_RESERVED = 128
PI_BV_RESERVED = 512
C6_TICK_CAP = 256
PI_TICK_CAP = 1024
STATE_BYTES = 32
EDGE_BYTES = 16
QUEUED_BYTES = 24
BV_BYTES = 48
MESSAGE_BYTES = 24


def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def sha(x):
    return hashlib.sha256(canonical(x).encode()).hexdigest()


def git_blob_sha1(data):
    return hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()


def verify_pe(root):
    out = {}
    for rel, desired in PINS.items():
        found = git_blob_sha1((Path(root) / rel).read_bytes())
        if found != desired:
            raise RuntimeError(f'SOURCE_PIN_MISMATCH {rel} {found} != {desired}')
        out[rel] = found
    return out


def load_compute(root):
    verify_pe(root)
    src = str(Path(root).resolve())
    if src not in sys.path:
        sys.path.insert(0, src)
    return importlib.import_module('spk_architecture_v1.pe_execution_v1b')._compute_local


@dataclass(frozen=True)
class Node:
    node_id: str
    instructions: tuple
    state_bits: int = 16
    fractional_bits: int = 0


def neuron_program(island, n):
    gateways = PI_GATEWAYS if island == HUB else C6_GATEWAYS
    ingress = PI_INGRESS if island == HUB else C6_INGRESS
    threshold = 6 if n in gateways else 2 if n in ingress else 5
    return Node(f'I{island}/N{n}', (
        ('ACC', (1, 1)), ('CMP', threshold), ('EMIT', 7), ('RESET', 0)))


def base_undirected():
    edges = {tuple(sorted((i, (i + 1) % 8))) for i in range(8)}
    edges.update((i, i + 4) for i in range(4))
    return tuple(sorted(edges))


def hybrid_undirected():
    return tuple(sorted(set(base_undirected()) | {(0, HUB), (4, HUB)}))


def graph(mode='hybrid'):
    return hybrid_undirected() if mode == 'hybrid' else base_undirected()


def adjacencies():
    adj = {i: [] for i in range(N_ISLANDS)}
    for x, y in hybrid_undirected():
        adj[x].append(y)
        adj[y].append(x)
    return {k: sorted(v) for k, v in adj.items()}


def path(src, dst):
    assert src != dst and 0 <= src < N_ISLANDS and 0 <= dst < N_ISLANDS
    graph_map = adjacencies()
    todo = collections.deque([(src,)])
    seen = {src}
    while todo:
        candidate = todo.popleft()
        if candidate[-1] == dst:
            return candidate
        for nxt in graph_map[candidate[-1]]:
            if nxt not in seen:
                todo.append(candidate + (nxt,))
                seen.add(nxt)
    raise RuntimeError('DISCONNECTED_MESH')


@dataclass(frozen=True)
class Config:
    horizon: int = 96
    seed: int = 211
    stimulus_every: int = 6
    stimulus_last_tick: int = 24
    local_delay: int = 1
    radio_hop_delay: int = 2
    link_queue_cap: int = 16
    link_flight_cap: int = 8
    link_tx_per_tick: int = 2
    pi_rcp_shared_tx_per_tick: int = 2
    max_processed_events: int = 140000

    def validate(self):
        for k, v in asdict(self).items():
            if not isinstance(v, int) or isinstance(v, bool) or (v < 0 if k == 'seed' else v <= 0):
                raise ValueError('INVALID_BOUNDED_CONFIG: ' + k)
        if self.stimulus_last_tick >= self.horizon:
            raise ValueError('STIMULUS_AFTER_HORIZON')


@dataclass(frozen=True)
class Pulse:
    eid: int
    tick: int
    origin: str
    hops: int = 0


@dataclass
class Packet:
    pid: int
    source: int
    source_neuron: int
    destination: int
    route: tuple
    hop_at: int
    parent_emission: int


class Island:
    def __init__(self, iid, horizon):
        self.iid = iid
        self.size = SIZES[iid]
        self.capacity = PI_QUEUE if iid == HUB else C6_QUEUE
        self.tick_cap = PI_TICK_CAP if iid == HUB else C6_TICK_CAP
        self.nodes = [neuron_program(iid, j) for j in range(self.size)]
        self.states = [[0, 0] for _ in range(self.size)]
        self.pending = {}
        self.queued = 0
        self.queue_peak = 0
        self.processed = self.emitted = self.batches = 0
        self.dropped_queue = self.dropped_horizon = self.dropped_tick_budget = 0
        self.horizon = horizon

    def enqueue(self, tick, neuron, pulse):
        assert 0 <= neuron < self.size
        if tick >= self.horizon:
            self.dropped_horizon += 1
            return False
        if self.queued >= self.capacity:
            self.dropped_queue += 1
            return False
        self.pending.setdefault(tick, {}).setdefault(neuron, []).append(pulse)
        self.queued += 1
        self.queue_peak = max(self.queue_peak, self.queued)
        return True

    def snapshot(self):
        return {
            'id': self.iid, 'kind': 'PI5' if self.iid == HUB else 'ESP32_C6',
            'neurons': self.size, 'edges': self.size * FANOUT,
            'queue_capacity': self.capacity, 'queue_peak': self.queue_peak,
            'queue_pending': self.queued, 'tick_event_cap': self.tick_cap,
            'processed': self.processed, 'emissions': self.emitted, 'batches': self.batches,
            'dropped_queue': self.dropped_queue,
            'dropped_horizon': self.dropped_horizon,
            'dropped_tick_budget': self.dropped_tick_budget,
            'state_sha256': sha(self.states),
            'sram_layout_model_bytes': (self.size * STATE_BYTES + self.size * FANOUT * EDGE_BYTES
                                       + self.capacity * QUEUED_BYTES
                                       + (PI_BV_RESERVED if self.iid == HUB else C6_BV_RESERVED) * BV_BYTES
                                       + (128 * 1024 if self.iid == HUB else 32 * 1024)),
        }


class Simulation:
    def __init__(self, compute, cfg, enabled):
        cfg.validate()
        self.cfg = cfg
        self.compute = compute
        self.enabled = enabled
        self.islands = [Island(i, cfg.horizon) for i in range(N_ISLANDS)]
        self.links = {(a, b): collections.deque() for u, v in hybrid_undirected()
                      for a, b in ((u, v), (v, u))}
        self.inflight = {}
        self.flight_n = collections.Counter()
        self.link_queue_peak = collections.Counter()
        self.link_flight_peak = collections.Counter()
        self.trace = hashlib.sha256()
        self.trace_sample = []
        self.stats = collections.Counter()
        self.hops = collections.Counter()
        self.serial = self.packet_serial = 0
        self.pi_rcp_tx_peak = 0

    def log(self, obj):
        self.trace.update((canonical(obj) + '\n').encode())
        if len(self.trace_sample) < 40:
            self.trace_sample.append(obj)

    def event_id(self):
        self.serial += 1
        return self.serial

    def inject(self):
        # The 8 ESP32-C6 inputs are byte-equivalent in pattern to the 8×64 v0.
        for tick in range(1, self.cfg.stimulus_last_tick + 1, self.cfg.stimulus_every):
            for iid in range(C6_COUNT):
                ix = ((tick // self.cfg.stimulus_every) + iid + self.cfg.seed) % 4
                gateway = C6_GATEWAYS[ix]
                self._inject_batch(iid, tick, gateway, 6)
                self._inject_batch(iid, tick, (gateway + 7) % 64, 3)
            # Pi5 island: activate two distinct gateway populations per pulse.
            # This tests 1,024 allocated neurons without claiming 1,024 active.
            for j in (0, 1):
                k = ((tick // self.cfg.stimulus_every) * 2 + j) % len(PI_GATEWAYS)
                g = PI_GATEWAYS[k]
                self._inject_batch(HUB, tick, g, 6)
                self._inject_batch(HUB, tick, (g + 7) % SIZES[HUB], 3)

    def _inject_batch(self, iid, tick, neuron, count):
        for _ in range(count):
            eid = self.event_id()
            self.stats['external_created'] += 1
            ok = self.islands[iid].enqueue(tick, neuron, Pulse(eid, tick, 'SENSOR'))
            self.stats['external_admitted' if ok else 'external_rejected'] += 1
            self.stats[f'external_{iid}_admitted' if ok else f'external_{iid}_rejected'] += 1

    def create_packet(self, tick, iid, neuron, eid):
        # Genuine traffic in both directions: half of ESP gateways export to Pi5.
        if iid == HUB:
            dst = (neuron // 64) % C6_COUNT
        else:
            dst = HUB if neuron in (0, 48) else (iid + 2 + (neuron // 16)) % C6_COUNT
        assert dst != iid
        self.packet_serial += 1
        pkt = Packet(self.packet_serial, iid, neuron, dst, path(iid, dst), 0, eid)
        self.stats['packets_created'] += 1
        if iid == HUB:
            self.stats['packets_created_from_pi'] += 1
        if dst == HUB:
            self.stats['packets_created_to_pi'] += 1
        self.log(['packet_create', tick, pkt.pid, iid, neuron, dst, eid, list(pkt.route)])
        self.enqueue_packet(pkt, tick)

    def enqueue_packet(self, pkt, tick):
        link = (pkt.route[pkt.hop_at], pkt.route[pkt.hop_at + 1])
        q = self.links[link]
        if len(q) >= self.cfg.link_queue_cap:
            self.stats['packets_dropped_link_queue'] += 1
            self.log(['link_queue_drop', tick, pkt.pid, *link])
            return False
        q.append(pkt)
        self.link_queue_peak[link] = max(self.link_queue_peak[link], len(q))
        return True

    def receive(self, tick):
        for pkt, link in self.inflight.pop(tick, []):
            self.flight_n[link] -= 1
            assert self.flight_n[link] >= 0
            assert (pkt.route[pkt.hop_at], pkt.route[pkt.hop_at + 1]) == link
            pkt.hop_at += 1
            self.hops[pkt.hop_at] += 1
            self.stats['hop_arrivals'] += 1
            self.log(['arrival', tick, pkt.pid, *link, pkt.hop_at])
            if pkt.hop_at != len(pkt.route) - 1:
                self.enqueue_packet(pkt, tick)
            else:
                iid = pkt.destination
                # Pi: source-specific accumulator; ESP: one common ingress at N8.
                neuron = (PI_INGRESS[pkt.source % len(PI_INGRESS)] if iid == HUB
                          else C6_INGRESS[0])
                pulse = Pulse(self.event_id(), tick, f'MESH/{pkt.pid}', pkt.hop_at)
                ok = self.islands[iid].enqueue(tick, neuron, pulse)
                self.stats['packets_arrived_at_destination'] += 1
                self.stats['mesh_neuron_admitted' if ok else 'mesh_neuron_rejected'] += 1
                if iid == HUB:
                    self.stats['packets_arrived_at_pi'] += 1
                if pkt.source == HUB:
                    self.stats['packets_arrived_from_pi'] += 1
                self.log(['destination', tick, pkt.pid, iid, neuron, int(ok)])

    def compute_local(self, tick):
        for island in self.islands:
            rows = island.pending.pop(tick, {})
            island.queued -= sum(len(p) for p in rows.values())
            assert island.queued >= 0
            used = 0
            for neuron in sorted(rows):
                pulses = rows[neuron]
                if used + len(pulses) > island.tick_cap:
                    island.dropped_tick_budget += len(pulses)
                    self.stats['dropped_tick_budget'] += len(pulses)
                    self.log(['tick_budget_drop', tick, island.iid, neuron, len(pulses)])
                    continue
                used += len(pulses)
                island.processed += len(pulses)
                self.stats['events_processed'] += len(pulses)
                if self.stats['events_processed'] > self.cfg.max_processed_events:
                    raise RuntimeError('GLOBAL_EVENT_LIMIT_REACHED')
                raw, guard, out = self.compute(
                    island.nodes[neuron], island.states[neuron], tick, (1,) * len(pulses))
                island.states[neuron] = [raw, tick]
                island.batches += 1
                self.stats['batches_processed'] += 1
                self.log(['batch', tick, island.iid, neuron, len(pulses), raw, int(guard), len(out)])
                for ch in out:
                    assert ch == 7
                    island.emitted += 1
                    self.stats['emissions'] += 1
                    eid = self.event_id()
                    self.log(['emit', tick, island.iid, neuron, eid])
                    for offset in EDGE_OFFSETS:
                        target = (neuron + offset) % island.size
                        ok = island.enqueue(tick + self.cfg.local_delay, target,
                                            Pulse(self.event_id(), tick + self.cfg.local_delay,
                                                  f'I{island.iid}/N{neuron}#{eid}'))
                        self.stats['local_edge_events_created'] += 1
                        self.stats['local_edge_events_admitted' if ok else 'local_edge_events_rejected'] += 1
                    if self.enabled and neuron in (PI_GATEWAYS if island.iid == HUB else C6_GATEWAYS):
                        self.create_packet(tick, island.iid, neuron, eid)

    def transmit(self, tick):
        pi_sent = 0
        for link in sorted(self.links):
            q = self.links[link]
            sent = 0
            while (q and sent < self.cfg.link_tx_per_tick
                   and self.flight_n[link] < self.cfg.link_flight_cap):
                # The Pi5 has exactly one hypothetical external RCP, SHARED by
                # all of its radio links, no secret per-peer extra transceiver.
                touches_pi = HUB in link
                if touches_pi and pi_sent >= self.cfg.pi_rcp_shared_tx_per_tick:
                    break
                pkt = q.popleft()
                sent += 1
                if touches_pi:
                    pi_sent += 1
                    self.stats['pi_rcp_link_transmissions'] += 1
                self.flight_n[link] += 1
                self.link_flight_peak[link] = max(self.link_flight_peak[link], self.flight_n[link])
                arrival = tick + self.cfg.radio_hop_delay
                self.inflight.setdefault(arrival, []).append((pkt, link))
                self.stats['link_transmissions'] += 1
                self.stats['logical_payload_bytes'] += MESSAGE_BYTES
                self.log(['tx', tick, pkt.pid, *link, arrival])
        self.pi_rcp_tx_peak = max(self.pi_rcp_tx_peak, pi_sent)

    def run(self):
        self.inject()
        for t in range(self.cfg.horizon):
            self.receive(t)
            self.compute_local(t)
            self.transmit(t)
        queued_packets = sum(map(len, self.links.values()))
        flying = sum(map(len, self.inflight.values()))
        assert self.stats['packets_created'] == (self.stats['packets_arrived_at_destination']
                       + self.stats['packets_dropped_link_queue'] + queued_packets + flying)
        assert self.stats['link_transmissions'] == self.stats['hop_arrivals'] + flying
        assert self.stats['local_edge_events_created'] == (self.stats['local_edge_events_admitted']
                                                          + self.stats['local_edge_events_rejected'])
        assert self.stats['external_created'] == self.stats['external_admitted'] + self.stats['external_rejected']
        self.stats['local_queued_at_horizon'] = sum(i.queued for i in self.islands)
        self.stats['link_queued_at_horizon'] = queued_packets
        self.stats['link_flight_at_horizon'] = flying
        self.stats['link_queue_peak'] = max(self.link_queue_peak.values(), default=0)
        self.stats['link_flight_peak'] = max(self.link_flight_peak.values(), default=0)
        self.stats['pi_rcp_tx_peak_per_tick'] = self.pi_rcp_tx_peak
        states = [i.snapshot() for i in self.islands]
        return {
            'schema': SCHEMA,
            'mesh_enabled': self.enabled,
            'config': asdict(self.cfg),
            'topology': {'undirected_links': hybrid_undirected(), 'directed_links': len(self.links),
                         'local_edges': sum(n * FANOUT for n in SIZES),
                         'pi_neighbors': adjacencies()[HUB]},
            'resources': {'total_neurons': sum(SIZES), 'per_island_neurons': SIZES,
                          'total_local_edges': sum(n * FANOUT for n in SIZES),
                          'pi_radio': 'EXTERNAL_802154_RCP_ABSTRACT',
                          'pi_rcp_shared_tx_per_tick': self.cfg.pi_rcp_shared_tx_per_tick,
                          'no_bv_writes': True, 'no_learning': True,
                          'sram_layout_model_only': True},
            'per_island': states,
            'stats': dict(sorted(self.stats.items())),
            'hops': dict(sorted(self.hops.items())),
            'state_sha256': sha([(i.iid, i.states) for i in self.islands]),
            'trace_sha256': self.trace.hexdigest(),
            'trace_sample': self.trace_sample,
            'P_writes': 0, 'bv_writes': 0, 'learning_updates': 0,
            'holdout_accesses': 0,
            'scope': 'BOUNDED_RESEARCH_REFERENCE_LOCAL_ORIGINAL_PE_ISA_NEW_MESH_SCHEDULER',
        }


def run_pair(compute, cfg):
    off = Simulation(compute, cfg, False).run()
    on = Simulation(compute, cfg, True).run()
    result = {
        'schema': SCHEMA + '/comparison',
        'source_main_commit': MAIN,
        'source_pins': PINS,
        'mesh_off': off,
        'mesh_on': on,
        'same_exogenous_inputs': (off['stats']['external_admitted'] == on['stats']['external_admitted']
                                  and off['stats']['external_created'] == on['stats']['external_created']),
        'state_difference': off['state_sha256'] != on['state_sha256'],
        'pi_state_difference': off['per_island'][HUB]['state_sha256'] != on['per_island'][HUB]['state_sha256'],
        'no_bv_no_learning': True,
        'verdict': 'MESH9_HYBRID_PHASE01_BOUNDED_REFERENCE_PRODUCED',
    }
    result['canonical_sha256'] = sha(result)
    return result


def selftest():
    import test_spk_mesh9_hybrid_ref_v0 as tests
    mirror = tests.mirror_compute
    a = run_pair(mirror, Config(horizon=28, stimulus_last_tick=12))
    b = run_pair(mirror, Config(horizon=28, stimulus_last_tick=12))
    assert canonical(a) == canonical(b)
    assert a['mesh_on']['stats']['packets_arrived_at_pi'] > 0
    assert a['mesh_on']['stats']['packets_arrived_from_pi'] > 0
    assert a['mesh_on']['per_island'][HUB]['queue_peak'] <= PI_QUEUE
    return {'SELFTEST': 'PASS', 'pi_to_mesh': a['mesh_on']['stats']['packets_arrived_from_pi'],
            'mesh_to_pi': a['mesh_on']['stats']['packets_arrived_at_pi']}


def cli(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-root', type=Path)
    parser.add_argument('--profile', choices=('selftest', 'smoke', 'full'), default='smoke')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args(argv)
    if not args.source_root:
        parser.error('--source-root is mandatory for pinned PE')
    compute = load_compute(args.source_root)
    if args.profile == 'selftest':
        test_result = selftest()
        # Independent mirror is separate; real original local PE also exercised.
        example = run_pair(compute, Config(horizon=28, stimulus_last_tick=12))
        assert example['mesh_on']['stats']['packets_arrived_at_pi'] > 0
        assert example['mesh_on']['stats']['packets_arrived_from_pi'] > 0
        print('SELFTEST_RESULT', canonical(test_result))
        return 0
    cfg = Config(horizon=28, stimulus_last_tick=12) if args.profile == 'smoke' else Config()
    report = run_pair(compute, cfg)
    replay = run_pair(compute, cfg)
    assert canonical(report) == canonical(replay), 'NON_DETERMINISTIC_REPLAY'
    if args.out:
        if args.out.exists():
            raise RuntimeError('OUTPUT_ALREADY_EXISTS_NONOVERWRITE')
        args.out.mkdir(parents=True)
        (args.out / 'report.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
        (args.out / 'protocol.json').write_text(json.dumps({
            'schema': SCHEMA+'/manual', 'profile': args.profile,
            'model': '8*64 ESP32-C6-class + 1*1024 RPi5-class, external shared 802.15.4 RCP',
            'topology': hybrid_undirected(), 'pins': PINS, 'source_main_commit': MAIN,
            'config': asdict(cfg), 'no_original_P_writes': True, 'no_holdout': True,
            'no_learning': True, 'scope': 'NEW_SCHEDULER_WITH_PINNED_ORIGINAL_PE_LOCAL_ISA',
        },sort_keys=True,indent=2)+'\n')
        lines = [f"{hashlib.sha256((args.out/name).read_bytes()).hexdigest()}  {name}"
                 for name in ('protocol.json','report.json')]
        (args.out / 'SHA256SUMS').write_text('\n'.join(lines)+'\n')
    off, on = report['mesh_off']['stats'], report['mesh_on']['stats']
    print('RUN_COMPLETE__HYBRID_ENGINEERING_RESEARCH_ONLY')
    print('CONFIG', canonical({'islands': N_ISLANDS, 'c6_islands': C6_COUNT,
                               'pi5_neurons': SIZES[HUB], 'neurons': sum(SIZES),
                               'edges': sum(x*FANOUT for x in SIZES), 'links': len(hybrid_undirected())}))
    print('ISOLATED', canonical({k:off.get(k,0) for k in ('events_processed','emissions','packets_created')}))
    print('MESH', canonical({k:on.get(k,0) for k in ('events_processed','emissions','packets_created',
                                                  'packets_arrived_at_destination','packets_arrived_at_pi',
                                                  'packets_arrived_from_pi','link_transmissions',
                                                  'packets_dropped_link_queue')}))
    print('STATE_DIFFERENCE', report['state_difference'])
    print('PI_STATE_DIFFERENCE', report['pi_state_difference'])
    print('DETERMINISTIC_REPLAY PASS')
    print('REPORT_SHA256', report['canonical_sha256'])
    if args.out:
        print('OUTPUT', args.out)
    return 0

if __name__ == '__main__':
    raise SystemExit(cli())
