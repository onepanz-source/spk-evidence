"""Offline, synthetic fixture only; NEVER reads DSEC or ground-truth pixels."""
from __future__ import annotations
import hashlib
from pathlib import Path
import tempfile
import types
import sys
from unittest import mock
import json
import unittest
import zipfile
import numpy as np
import spk_dsec_mesh9_dev_v0 as d
from test_spk_mesh9_ethgateway_ref_v1 import mirror_compute
import spk_mesh9_ethgateway_ref_v1 as mesh

class DEVProtocol(unittest.TestCase):
    def test_locked_split(self):
        self.assertEqual(d.SEQUENCE,'thun_00_a')
        self.assertEqual(d.RESERVED,('zurich_city_01_a','zurich_city_02_a'))
        self.assertEqual(d.PAIR_LIMIT,4)
    def test_mapping_neuron_bounds_and_polarity(self):
        # Distinct polarity and grid positions must have distinct neuron IDs.
        for x in (0,39,40,79,80,319,639):
            for y in (0,29,30,479):
                for p in (0,1):
                    c6=(x//40)//2; n=((x//40)%2)*32+(y//30)*2+p
                    pi=(x//20)*32+(y//30)*2+p
                    self.assertTrue(0<=c6<8 and 0<=n<64 and 0<=pi<1024)
        self.assertNotEqual(0*32+0*2+0,0*32+0*2+1)
    def test_fixed_top_k_and_erasable_counts(self):
        c=np.ones((d.TIME_BINS,8,64),dtype=np.int64)*40
        p=np.ones((d.TIME_BINS,1024),dtype=np.int64)*160
        stimuli,stats=d.encode_inputs(c,p)
        self.assertEqual(stats['selected_bin_occurrences'], d.TIME_BINS*(8*d.C6_TOPK+d.PI_TOPK))
        self.assertEqual(stats['sensor_spike_total'],d.TIME_BINS*(8*d.C6_TOPK*2+d.PI_TOPK*3))
        self.assertEqual(len(stimuli),stats['selected_bin_occurrences'])
        self.assertEqual(stats['per_island_selected_neurons'],[d.C6_TOPK]*8+[d.PI_TOPK])
        self.assertEqual(d.digest(stimuli),stats['sensor_input_sha256'])
    def test_quantization_is_fixed(self):
        self.assertEqual([d.pulse_count(x) for x in (0,1,39,40,159,160,9999)],[0,1,1,2,2,3,3])
    def test_inventory_does_not_require_reading_gt_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            ev=Path(tmp)/'train_events.zip';fl=Path(tmp)/'train_optical_flow.zip'
            with zipfile.ZipFile(ev,'w') as z:
                for seq in (d.SEQUENCE,*d.RESERVED):
                    z.writestr(f'zzz/{seq}/events/left/events.h5',b'event')
                    z.writestr(f'zzz/{seq}/events/left/rectify_map.h5',b'xyz')
            with zipfile.ZipFile(fl,'w') as z:
                for seq in (d.SEQUENCE,*d.RESERVED):
                    z.writestr(f'zzz/{seq}/flow/forward_timestamps.txt',b'100000 200000\n')
                    z.writestr(f'zzz/{seq}/flow/forward/000000.png',b'DO_NOT_OPEN_THIS_AS_GT')
            inv=d.inventory(ev,fl)
            self.assertEqual(set(inv['selected']),{d.SEQUENCE,*d.RESERVED})
            self.assertEqual(len(inv['selected'][d.SEQUENCE]),3)
    def test_missing_reserved_split_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            ev=Path(tmp)/'train_events.zip';fl=Path(tmp)/'train_optical_flow.zip'
            with zipfile.ZipFile(ev,'w') as z:
                z.writestr(f'{d.SEQUENCE}/events/left/events.h5',b'0')
                z.writestr(f'{d.SEQUENCE}/events/left/rectify_map.h5',b'0')
            with zipfile.ZipFile(fl,'w') as z:
                z.writestr(f'{d.SEQUENCE}/flow/forward_timestamps.txt',b'0')
            with self.assertRaises(RuntimeError):d.inventory(ev,fl)
    def test_pinned_extraction_rejects_wrong_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            zipp=Path(tmp)/'source.zip'
            with zipfile.ZipFile(zipp,'w') as z:z.writestr(f'{d.SEQUENCE}/events/left/events.h5',b'BAD')
            with zipfile.ZipFile(zipp) as z:
                info=d.exactly_one_member(z,d.SEQUENCE,'events/left/events.h5')
                with self.assertRaises(RuntimeError):
                    d.ensure_pinned_dev_member(z,info,Path(tmp)/'events.h5','0'*64)
    def test_episodes_replay_and_off_on_input_parity(self):
        c=np.zeros((d.TIME_BINS,8,64),dtype=np.int64)
        p=np.zeros((d.TIME_BINS,1024),dtype=np.int64)
        for t in range(d.TIME_BINS):
            for i in range(8):
                c[t,i,(t+i)%64]=180
                c[t,i,(t+i+5)%64]=41
            p[t,(t*3)%1024]=161
        stim,enc=d.encode_inputs(c,p)
        rep=d.run_episode(mirror_compute,mesh.Config(horizon=64,stimulus_last_tick=24,max_processed_events=1_000_000),stim,enc,0)
        self.assertEqual(rep['mesh_off']['stats']['external_created'],enc['sensor_spike_total'])
        self.assertEqual(rep['mesh_on']['stats']['external_created'],enc['sensor_spike_total'])
        self.assertEqual(rep['mesh_on']['active_neurons_processed_total']>0,True)
        self.assertEqual(rep['mesh_on']['P_writes'],0)
        self.assertEqual(rep['mesh_on']['bv_writes'],0)
        self.assertEqual(rep['mesh_on']['learning_updates'],0)
    def test_real_h5_time_offset_rectification_and_polarity_on_synthetic_fixture(self):
        import h5py
        with tempfile.TemporaryDirectory() as td:
            f=Path(td)/'events.h5'
            # Actual DSEC time is raw t + positive offset, and flow timestamps
            # are absolute. Inclusive start, exclusive end.
            with h5py.File(f,'w') as h:
                g=h.create_group('events')
                g['t']=np.array([0,1000,10000,50000,99999,100000,100001],dtype=np.int64)
                g['x']=np.array([1,2,3,41,41,41,41],dtype=np.int32)
                g['y']=np.array([1,2,3,32,32,32,32],dtype=np.int32)
                g['p']=np.array([0,1,0,1,0,1,0],dtype=np.int8)
                h['t_offset']=np.int64(100000)
            rect=np.zeros((480,640,2),dtype=np.float32)
            rect[:,:,0]=np.arange(640,dtype=np.float32)
            rect[:,:,1]=np.arange(480,dtype=np.float32)[:,None]
            with h5py.File(f,'r') as h:
                c6,pi,stats=d.dataset_bins(h,rect,(100000,200000))
            self.assertEqual(stats['raw_events'],5)
            self.assertEqual(stats['rectified_out_of_bounds'],0)
            self.assertEqual(stats['polarity_1'],2)
            self.assertEqual(int(c6.sum()),5)
            self.assertEqual(int(pi.sum()),5)
            self.assertEqual(int(c6[0,0,0]),1)
            self.assertEqual(int(c6[0,0,1]),1)
            self.assertEqual(int(c6[2,0,0]),1)
            self.assertEqual(int(c6[10,0,35]),1)
            self.assertEqual(int(c6[19,0,34]),1)

    def test_end_to_end_mock_dsec_zips_without_gt_pixels(self):
        # Exercises actual HDF5 -> ZIP -> pinned-member -> 9-island mesh -> report,
        # with synthetic lab data only, and bans any PNG payload access.
        import h5py
        with tempfile.TemporaryDirectory() as td:
            base=Path(td)
            event_bytes=base/'e.h5'; map_bytes=base/'m.h5'
            with h5py.File(event_bytes,'w') as f:
                g=f.create_group('events')
                t=np.array([j*100000+10000+k*1000 for j in range(4) for k in range(12)],dtype=np.int64)
                g['t']=t;g['x']=np.array([(k*37)%640 for k in range(48)],dtype=np.int32)
                g['y']=np.array([(k*23)%480 for k in range(48)],dtype=np.int32)
                g['p']=np.array([k%2 for k in range(48)],dtype=np.int8)
                f['t_offset']=np.int64(100000)
            with h5py.File(map_bytes,'w') as f:
                m=np.zeros((480,640,2),dtype=np.float32)
                m[:,:,0]=np.arange(640,dtype=np.float32)
                m[:,:,1]=np.arange(480,dtype=np.float32)[:,None]
                f['rectify_map']=m
            timestamp=b'# from_timestamp, to_timestamp\n'+b''.join(f'{start}, {start+100000}\n'.encode() for start in (100000,200000,300000,400000))
            inputs={'events/left/events.h5':event_bytes.read_bytes(),
                    'events/left/rectify_map.h5':map_bytes.read_bytes(),
                    'flow/forward_timestamps.txt':timestamp}
            pins={k:hashlib.sha256(v).hexdigest() for k,v in inputs.items()}
            e=base/'train_events.zip';f=base/'train_optical_flow.zip'
            with zipfile.ZipFile(e,'w',compression=zipfile.ZIP_DEFLATED) as z:
                for seq in (d.SEQUENCE,*d.RESERVED):
                    for path in ('events/left/events.h5','events/left/rectify_map.h5'):
                        z.writestr(f'prefix/{seq}/{path}',inputs[path] if seq==d.SEQUENCE else b'NO_READ_RESERVED')
            with zipfile.ZipFile(f,'w',compression=zipfile.ZIP_DEFLATED) as z:
                for seq in (d.SEQUENCE,*d.RESERVED):
                    z.writestr(f'prefix/{seq}/flow/forward_timestamps.txt',timestamp if seq==d.SEQUENCE else b'NO_READ_RESERVED')
                    z.writestr(f'prefix/{seq}/flow/forward/000000.png',b'GROUND_TRUTH_IS_FORBIDDEN')
            args=types.SimpleNamespace(events_zip=str(e),flow_zip=str(f),intake=str(base/'intake'),
                                       source_root=base,profile='smoke',out=str(base/'output'))
            open_real=zipfile.ZipFile.open
            opened=[]
            def guarded_open(z, name, *a, **kw):
                nm=name.filename if isinstance(name,zipfile.ZipInfo) else str(name)
                if nm.endswith('.png') or any(x in nm for x in d.RESERVED):
                    raise AssertionError('UNAUTHORIZED_GT_OR_RESERVED_MEMBER_READ: '+nm)
                opened.append(nm)
                return open_real(z,name,*a,**kw)
            with mock.patch.dict(d.PINS,pins,clear=True), \
                 mock.patch.object(d.v0,'load_compute',return_value=mirror_compute), \
                 mock.patch.dict(sys.modules,{'hdf5plugin':types.ModuleType('hdf5plugin')}), \
                 mock.patch.object(zipfile.ZipFile,'open',guarded_open):
                self.assertEqual(d.run(args),0)
            report=json.loads((base/'output'/'report.json').read_text())
            self.assertEqual(report['pair_count'],1)
            self.assertEqual(report['per_pair'][0]['raw']['raw_events'],12)
            self.assertFalse(report['gt_flow_png_opened'])
            self.assertEqual(set(opened),{f'prefix/{d.SEQUENCE}/{x}' for x in inputs})

    def test_timestamp_parser_accepts_official_dsec_comma_header(self):
        # Regression for real DSEC #214 fwork failure BAD_FORMAT_L2:
        # the first line is a comment; the data rows are comma-separated.
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'forward_timestamps.txt'
            f.write_text('# from_timestamp, to_timestamp\n'
                         '100358, 200359\n'
                         '600358,700359\n'
                         '1100358, 1200359\n'
                         '1600358 , 1700359\n')
            self.assertEqual(d.pair_times(f),[(100358,200359),(600358,700359),
                                             (1100358,1200359),(1600358,1700359)])

    def test_timestamp_parser_rejects_bad_shapes(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'t.txt'
            # Keep the original legacy synthetic whitespace fixture valid.
            f.write_text('100000 200000\n200000 300000\n300000 400000\n400000 500000\n')
            self.assertEqual(len(d.pair_times(f)),4)
            for bad in ('100000; 200000', '100000, 200000, 300000',
                        'start, end', '100000, 99999', '100000, 180000',
                        '100000, 200000 extra'):
                f.write_text('# header\n'+bad+'\n200000, 300000\n300000, 400000\n400000, 500000\n')
                with self.subTest(bad=bad), self.assertRaises(RuntimeError):
                    d.pair_times(f)


class CausalInputAdmissionRegression(unittest.TestCase):
    def test_future_events_not_queued_before_their_tick(self):
        cfg=mesh.Config(horizon=64, stimulus_last_tick=24,
                        max_processed_events=1000000)
        sim=d.RealDSECSimulation(mirror_compute, cfg, False,
                                 ((1,0,3,3),(3,8,5,2)))
        sim.inject()
        self.assertEqual(sim.stats['external_created'],0)
        self.assertEqual(sum(i.queued for i in sim.islands),0)
        sim.receive(0)
        self.assertEqual(sim.stats['external_created'],0)
        sim.receive(1)
        self.assertEqual(sim.stats['external_created'],3)
        self.assertEqual(sim.islands[0].queued,3)
        self.assertEqual(sim.islands[8].queued,0)
        sim.receive(2)
        self.assertEqual(sim.stats['external_created'],3)
        sim.receive(3)
        self.assertEqual(sim.stats['external_created'],5)
        self.assertEqual(sim.islands[8].queued,2)
        self.assertFalse(sim._sensor_by_tick)

    def test_future_prefill_bug_reproduction_and_fix_on_20_bins(self):
        # 480 source pulses on ONE 64-neuron island spread over 20 bins.
        # The original buggy inject() preloaded all of them, rejecting 224
        # immediately despite no simulated clock ticks having elapsed.
        cfg=mesh.Config(horizon=64, stimulus_last_tick=24,
                        max_processed_events=1000000)
        stm=tuple((t,0,n,3) for t in range(1,21) for n in range(8))
        sim=d.RealDSECSimulation(mirror_compute, cfg, False, stm)
        sim.inject()
        self.assertEqual(sim.stats['external_created'],0)
        self.assertEqual(sim.stats['external_rejected'],0)
        self.assertEqual(sim.islands[0].queued,0)
        sim.receive(1)
        self.assertEqual(sim.stats['external_created'],24)
        self.assertEqual(sim.stats['external_admitted'],24)
        self.assertEqual(sim.stats['external_rejected'],0)
        self.assertEqual(sim.islands[0].queued,24)
        self.assertEqual(len(sim._sensor_by_tick),19)

    def test_future_timestamp_outside_horizon_veto(self):
        cfg=mesh.Config(horizon=64, stimulus_last_tick=24,
                        max_processed_events=1000000)
        sim=d.RealDSECSimulation(mirror_compute,cfg,False,((64,0,3,1),))
        with self.assertRaisesRegex(RuntimeError,'INVALID_FUTURE_SENSOR_STIMULUS'):
            sim.inject()

if __name__=='__main__':unittest.main()
