"""Source-scoped controls. Unit tests use an arithmetic mirror, not fwork original PE."""
import unittest
import spk_dsec_mesh9_fanout_diag_v0 as diag
import spk_mesh9_hybrid_ref_v0 as v0
import spk_mesh9_ethgateway_ref_v1 as gateway
import spk_dsec_mesh9_dev_v0 as dsec

def mirror(node,state,t,channels):
    raw,prev=state
    cnt=channels.count(1)
    raw+=cnt
    threshold=next(arg for op,arg in node.instructions if op=='CMP')
    emit=raw>=threshold
    if emit:raw=0
    return raw,emit,(7,) if emit else ()

class DiagnosticTests(unittest.TestCase):
    def setUp(self):
        self.cfg=gateway.Config(horizon=25,stimulus_last_tick=20,max_processed_events=1000000)
        self.stimuli=((1,0,8,2),(2,0,24,2),(1,8,32,3),(3,8,32,2))

    def test_mask_restore(self):
        original=v0.EDGE_OFFSETS
        for f in diag.FANOUTS:
            with diag.masked_local_routes(f):
                self.assertEqual(v0.EDGE_OFFSETS,original[:f])
        self.assertEqual(v0.EDGE_OFFSETS,original)

    def test_invalid_mask_rejected(self):
        with self.assertRaisesRegex(ValueError,'INVALID_EFFECTIVE_FANOUT'):
            with diag.masked_local_routes(3):pass

    def test_no_recurrence_no_losses(self):
        r,t=diag.run_arm(mirror,self.cfg,self.stimuli,0,False)
        self.assertEqual(r['stats'].get('local_edge_events_created',0),0)
        self.assertEqual(r['stats']['external_created'],9)
        self.assertEqual(r['stats'].get('external_rejected',0),0)
        self.assertEqual(r['stats']['events_processed'],9)
        self.assertEqual(len(t),self.cfg.horizon)

    def test_per_tick_sensor_ingress_does_not_prefill(self):
        r,t=diag.run_arm(mirror,self.cfg,self.stimuli,0,False)
        self.assertEqual(t[0]['external_admitted'],0)
        self.assertEqual(t[1]['external_admitted'],5)
        self.assertEqual(t[2]['external_admitted'],2)
        self.assertEqual(t[3]['external_admitted'],2)

    def test_counter_conservation_all_masks(self):
        for f in diag.FANOUTS:
            for mesh in (False,True):
                r,_=diag.run_arm(mirror,self.cfg,self.stimuli,f,mesh)
                self.assertEqual(r['stats'].get('local_edge_events_created',0),f*r['stats']['emissions'])

    def test_full_mask_unmodified_reference_state_and_trace(self):
        for enabled in (False,True):
            with diag.masked_local_routes(8):
                original=dsec.RealDSECSimulation(mirror,self.cfg,enabled,self.stimuli).run()
            measured,t=diag.run_arm(mirror,self.cfg,self.stimuli,8,enabled)
            for key in ('trace_sha256','state_sha256','stats'):
                self.assertEqual(original[key],measured[key])
            self.assertEqual(len(t),self.cfg.horizon)

    def test_frozen_codes_protected(self):
        self.assertEqual(v0.EDGE_OFFSETS,(1,2,3,5,8,13,21,34))
        self.assertEqual(diag.ANCHOR_SENSOR_PULSES,4867)
        self.assertEqual(len(diag.ANCHOR_INPUT_SHA256),64)

if __name__=='__main__':unittest.main()
