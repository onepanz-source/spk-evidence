#!/usr/bin/env python3
"""DSEC thun_00_a DEV-only real event input -> 9-island SPK forward mesh.

Two original DSEC ZIPs are used: event H5/rectification source, and forward
optical-flow timestamp metadata. NEVER reads an optical-flow PNG, forward labels,
reserved validation/test source member content, or any GT pixel. No learning/BV.
This is a constrained sensor/transport experiment, NOT optical-flow estimation.
"""
from __future__ import annotations
import argparse
from collections import Counter
from dataclasses import asdict, dataclass
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import zipfile

import spk_mesh9_ethgateway_ref_v1 as mesh
import spk_mesh9_hybrid_ref_v0 as v0

SEQUENCE = 'thun_00_a'
RESERVED = ('zurich_city_01_a', 'zurich_city_02_a')
PINS = {
    'events/left/events.h5': 'ba2802de00445580c99f392dcc7e58708b97d5f91810343e3cfeb1686dabf066',
    'events/left/rectify_map.h5': 'ffbd69a5981fe86f141cc45a84e8bfafad5e68a46683a456edab7c06447c294e',
    'flow/forward_timestamps.txt': '27505c9e88e4245d5c52ef625cb57d983760b4af9291b687dac94f6a15852608',
}
SCHEMA = 'spk-dsec-mesh9-dev-events-readout/v0p2'
SOURCE_DEV = 'DSEC_D2C0_THUN_00_A_ALREADY_EXPOSED_DEV_FIRST_FOUR_FORWARD_PAIRS'
PAIR_LIMIT = 4
TIME_BINS = 20
C6_TOPK = 8
PI_TOPK = 32
MAX_RAW_PER_PAIR = 2_000_000
MAX_MEMBER_BYTES = 12 * 1024**3


def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def digest(x):
    return hashlib.sha256(canonical(x).encode()).hexdigest()


def hash_file(path):
    d = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b''):
            d.update(chunk)
    return d.hexdigest()


def exactly_one_member(z, sequence, suffix):
    """Check central-directory ONLY; never inspect any other archive bytes."""
    matched = []
    for info in z.infolist():
        p = info.filename.replace('\\', '/')
        parts = p.strip('/').split('/')
        if info.is_dir() or '..' in parts or p.startswith('/'):
            continue
        if len(parts) >= 2 and sequence in parts and p.endswith('/' + suffix):
            if parts[-len(suffix.split('/'))-1] != sequence:
                continue
            matched.append(info)
    if len(matched) != 1:
        raise RuntimeError(f'ZIP_MEMBER_AMBIGUOUS_OR_MISSING {z.filename} {sequence} {suffix}: {len(matched)}')
    return matched[0]


def inventory(events_zip, flow_zip):
    if not events_zip.is_file() or not flow_zip.is_file():
        raise FileNotFoundError('DSEC_ZIPS_MISSING: supply both train_events.zip and train_optical_flow.zip')
    out = {'schema': SCHEMA+'/zip-central-directory-inventory',
           'rule': 'LIST_FILENAME_METADATA_ONLY_NO_FLOW_PNG_OR_VALIDATION_TEST_DATA_READ',
           'event_zip': {'file_name': events_zip.name, 'file_size': events_zip.stat().st_size},
           'flow_zip': {'file_name': flow_zip.name, 'file_size': flow_zip.stat().st_size},
           'split_names': {'dev':SEQUENCE, 'reserved_validation':RESERVED[0], 'reserved_blind':RESERVED[1]},
           'selected': {}}
    with zipfile.ZipFile(events_zip) as e, zipfile.ZipFile(flow_zip) as f:
        for seq in (SEQUENCE, *RESERVED):
            a = exactly_one_member(e,seq,'events/left/events.h5')
            b = exactly_one_member(e,seq,'events/left/rectify_map.h5')
            c = exactly_one_member(f,seq,'flow/forward_timestamps.txt')
            out['selected'][seq] = [
                {'member': i.filename, 'bytes':i.file_size, 'crc32':f'{i.CRC:08x}', 'archive':archive}
                for i,archive in ((a,'events'),(b,'events'),(c,'flow'))]
    return out


def ensure_pinned_dev_member(z, info, path, expected_sha):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        actual=hash_file(path)
        if actual != expected_sha:
            raise RuntimeError(f'EXISTING_SOURCE_SHA_MISMATCH {path} {actual}')
        return {'path':str(path), 'sha256':actual,'source':'EXISTING_VERIFIED'}
    if info.file_size > MAX_MEMBER_BYTES or info.file_size <= 0:
        raise RuntimeError('DSEC_MEMBER_UNBOUNDED')
    if shutil.disk_usage(path.parent).free < info.file_size + 512*1024*1024:
        raise RuntimeError('NOT_ENOUGH_DISK_FOR_SELECTED_DSEC_MEMBER')
    pending=path.with_suffix(path.suffix+'.partial')
    if pending.exists():
        raise RuntimeError('PARTIAL_PREEXISTS_MANUAL_INSPECTION_REQUIRED')
    try:
        with z.open(info, 'r') as src, pending.open('xb') as dst:
            shutil.copyfileobj(src,dst,length=8*1024*1024)
        if pending.stat().st_size != info.file_size:
            raise RuntimeError('MEMBER_BYTE_LENGTH_MISMATCH')
        actual=hash_file(pending)
        if actual != expected_sha:
            raise RuntimeError(f'PINNED_MEMBER_HASH_MISMATCH {info.filename} {actual}')
        os.replace(pending,path)
    finally:
        if pending.exists():
            pending.unlink()
    return {'path':str(path), 'sha256':expected_sha,'source':'DEV_ONLY_SELECTED_ZIP_MEMBER_EXTRACTED'}


def prepare_dev(events_zip, flow_zip, intake):
    evidence={}
    with zipfile.ZipFile(events_zip) as e, zipfile.ZipFile(flow_zip) as f:
        for rel in PINS:
            archive=f if rel.startswith('flow/') else e
            info=exactly_one_member(archive,SEQUENCE,rel)
            evidence[rel]=ensure_pinned_dev_member(archive,info,intake/SEQUENCE/rel,PINS[rel])
    return evidence


def pair_times(path):
    rows=[]
    for ln,line in enumerate(path.read_text().splitlines(),1):
        s=line.strip()
        if not s or s.startswith('#'):
            continue
        # Official DSEC: "from, to" (comma with optional spaces), usually
        # after a "#" header. Preserve strict legacy two-whitespace-column
        # input for our pre-existing synthetic fixture, but no other shape.
        match = re.fullmatch(r'([0-9]+)\s*,\s*([0-9]+)', s)
        if match is None:
            match = re.fullmatch(r'([0-9]+)\s+([0-9]+)', s)
        if match is None:
            raise RuntimeError(f'FORWARD_TIMESTAMP_BAD_FORMAT_L{ln}')
        start, end = int(match.group(1)), int(match.group(2))
        if not 90000 <= (end-start) <= 110000:
            raise RuntimeError(f'FORWARD_TIMESTAMP_NOT_100MS_L{ln}')
        rows.append((start,end))
    if len(rows)<PAIR_LIMIT:
        raise RuntimeError('TOO_FEW_DEV_FORWARD_PAIRS')
    return rows[:PAIR_LIMIT]


def _bisection(dset,value):
    lo,hi=0,len(dset)
    while lo<hi:
        m=(lo+hi)//2
        if int(dset[m]) < value:
            lo=m+1
        else:
            hi=m
    return lo


def dataset_bins(h5,rect,ab):
    """Consume just the declared dev time window, rectify x/y, preserve polarity."""
    import numpy as np
    start,end=ab
    if rect.shape != (480,640,2):
        raise RuntimeError(f'RECTIFY_MAP_WRONG_SHAPE {rect.shape}')
    events=h5['events']
    for key in ('x','y','t','p'):
        if key not in events:
            raise RuntimeError('DSEC_H5_MISSING_EVENT_FIELD_'+key)
    t_offset=int(np.asarray(h5['t_offset'][()]).item())
    t0,t1=start-t_offset,end-t_offset
    if t0<0 or t1<=t0:
        raise RuntimeError('INVALID_EVENT_T_OFFSET_OR_TIME_WINDOW')
    times=events['t']
    idx0=_bisection(times,t0)
    idx1=_bisection(times,t1)
    if idx0>=idx1 or idx1-idx0 > MAX_RAW_PER_PAIR:
        raise RuntimeError(f'DSEC_EVENT_WINDOW_EMPTY_OR_UNBOUNDED {idx0} {idx1}')
    t=np.asarray(times[idx0:idx1],dtype=np.int64)
    x=np.asarray(events['x'][idx0:idx1],dtype=np.int32)
    y=np.asarray(events['y'][idx0:idx1],dtype=np.int32)
    p=np.asarray(events['p'][idx0:idx1],dtype=np.int32)
    if not (len(t)==len(x)==len(y)==len(p)):
        raise RuntimeError('EVENT_FIELD_MISMATCH')
    if np.any((x<0)|(x>=640)|(y<0)|(y>=480)|(p<0)|(p>1)):
        raise RuntimeError('DSEC_RAW_EVENT_OUT_OF_BOUNDS')
    if np.any(t[1:]<t[:-1]) or t[0]<t0 or t[-1]>=t1:
        raise RuntimeError('EVENT_TIMESTAMP_ORDER_OR_SLICE_BROKEN')
    xy=rect[y,x]
    xr=np.floor(xy[:,0]+0.5).astype(np.int32)
    yr=np.floor(xy[:,1]+0.5).astype(np.int32)
    good=(xr>=0)&(xr<640)&(yr>=0)&(yr<480)
    xr=xr[good];yr=yr[good];p=p[good];t=t[good]
    ticks=1+((t-t0)*TIME_BINS//(t1-t0)).astype(np.int32)
    if len(ticks) and (np.min(ticks)<1 or np.max(ticks)>TIME_BINS):
        raise RuntimeError('TIME_BIN_OUT_OF_RANGE')
    # Sensor 640x480. C6 16x16 spatial cells, 2 polarities -> 512 neurons.
    # Pi5 32x16 spatial cells, 2 polarities -> 1024 neurons.
    cc=xr//40; rr=yr//30
    c6_i=cc//2
    c6_n=(cc%2)*32 + rr*2+p
    pi_n=(xr//20)*32 + rr*2+p
    if not np.all((c6_i>=0)&(c6_i<8)&(c6_n>=0)&(c6_n<64)&(pi_n>=0)&(pi_n<1024)):
        raise RuntimeError('SENSOR_MAPPING_INVALID')
    c6_id=(ticks-1)*512+c6_i*64+c6_n
    pi_id=(ticks-1)*1024+pi_n
    c6=np.bincount(c6_id,minlength=TIME_BINS*512).reshape(TIME_BINS,8,64)
    pi=np.bincount(pi_id,minlength=TIME_BINS*1024).reshape(TIME_BINS,1024)
    return c6,pi,{'raw_events':int(idx1-idx0),'rectified_valid_events':int(len(t)),
                  'rectified_out_of_bounds':int(idx1-idx0-len(t)),
                  't_offset_us':t_offset,'h5_index_range':[idx0,idx1],
                  'event_window_us':[start,end],
                  'polarity_0':int(np.count_nonzero(p==0)),
                  'polarity_1':int(np.count_nonzero(p==1)),
                  'tick_occupancy':[int(np.sum(ticks==i)) for i in range(1,TIME_BINS+1)]}


def pulse_count(count):
    if count<=0:return 0
    if count>=160:return 3
    if count>=40:return 2
    return 1


def encode_inputs(c6,pi):
    """Fixed top-K per island per 5ms. Selection only by present/past input events.

    All events in the window are real DSEC, but neural inputs are THROTTLED:
    no raw-pixel-as-unbounded-neuron-event assertion is permissible.
    """
    stimuli=[]
    stats={'per_island_input_pulses':[0]*9,'per_island_selected_neurons':[set() for _ in range(9)],
           'per_tick_input_pulses':[],'per_tick_selected_bins':[]}
    for t in range(TIME_BINS):
        tot=0;bins=0
        for island in range(9):
            data=pi[t] if island==8 else c6[t,island]
            topk=PI_TOPK if island==8 else C6_TOPK
            # Lexicographic tie break: descending bin event count then ascending neuron ID.
            ranked=sorted(((-int(v),int(n)) for n,v in enumerate(data) if v>0))[:topk]
            for neg,n in ranked:
                count=pulse_count(-neg)
                stimuli.append((t+1,island,n,count))
                stats['per_island_selected_neurons'][island].add(n)
                stats['per_island_input_pulses'][island]+=count
                tot+=count;bins+=1
        stats['per_tick_input_pulses'].append(tot)
        stats['per_tick_selected_bins'].append(bins)
    stats['per_island_selected_neurons']=[len(s) for s in stats['per_island_selected_neurons']]
    stats['sensor_spike_total']=sum(stats['per_island_input_pulses'])
    stats['selected_bin_occurrences']=sum(stats['per_tick_selected_bins'])
    stats['sensor_input_sha256']=digest(stimuli)
    return tuple(stimuli),stats


class RealDSECSimulation(mesh.Simulation):
    def __init__(self,compute,cfg,enabled,stimuli):
        self.stimuli=stimuli
        self.active=[set() for _ in range(9)]
        super().__init__(compute,cfg,enabled)

    def inject(self):
        """Stage sensor events by their declared tick; no future input queue prefill.

        The original research simulator called inject() once before the clock
        loop. Its old DSEC subclass immediately enqueued all 20 future bins,
        spuriously occupying the ESP32-C6 256-slot queues before tick 1.
        Stage *only metadata* here, never create/admit pulses until tick t.
        """
        self._sensor_by_tick = {}
        for tick, iid, neuron, count in self.stimuli:
            if not (1 <= tick < self.cfg.horizon and
                    0 <= iid < 9 and 0 <= neuron < self.islands[iid].size and
                    type(count) is int and 0 < count <= 3):
                raise RuntimeError('INVALID_FUTURE_SENSOR_STIMULUS')
            self._sensor_by_tick.setdefault(tick, []).append((iid, neuron, count))
        if not self._sensor_by_tick:
            raise RuntimeError('NO_SENSOR_STIMULI')

    def receive(self, tick):
        # Called by the unchanged parent run loop before local PE compute(t).
        # Only events whose actual causal timestamp equals tick are admitted.
        for iid, neuron, count in self._sensor_by_tick.pop(tick, ()):
            self._inject_batch(iid, tick, neuron, count)
        super().receive(tick)

    def compute_local(self,tick):
        # Only neurons whose batch fits the same actual per-island budget are counted active.
        for i in self.islands:
            used=0
            for n,pulses in sorted(i.pending.get(tick,{}).items()):
                if used+len(pulses)<=i.tick_cap:
                    used+=len(pulses)
                    self.active[i.iid].add(n)
        super().compute_local(tick)

    def run(self):
        out=super().run()
        if self._sensor_by_tick:
            raise RuntimeError('UNCONSUMED_FUTURE_SENSOR_TICKS')
        out['sensor_ingress_policy']='AT_OWN_TICK_BEFORE_MESH_RECEIVE_NO_FUTURE_PREFILL'
        out['active_neurons_processed_per_island']=[len(a) for a in self.active]
        out['active_neurons_processed_total']=sum(map(len,self.active))
        return out


def run_episode(compute,cfg,stimuli,counts,idx):
    off=RealDSECSimulation(compute,cfg,False,stimuli).run()
    on=RealDSECSimulation(compute,cfg,True,stimuli).run()
    repeat=RealDSECSimulation(compute,cfg,True,stimuli).run()
    if canonical(on)!=canonical(repeat):
        raise RuntimeError('DETERMINISTIC_REPLAY_MISMATCH')
    if not (off['stats']['external_created']==on['stats']['external_created']==counts['sensor_spike_total']):
        raise RuntimeError('INPUT_PARITY')
    if off['stats']['external_created']!=counts['sensor_spike_total']:
        raise RuntimeError('INPUT_ENCODER_MISMATCH')
    output={'pair':idx,'source_sensor':counts,
            'mesh_off':off,'mesh_on':on,
            'same_external_input':off['stats']['external_created']==on['stats']['external_created'],
            'state_changed':off['state_sha256']!=on['state_sha256'],
            'pi_state_changed':off['per_island'][8]['state_sha256']!=on['per_island'][8]['state_sha256']}
    output['pair_digest']=digest(output)
    return output


def run(args):
    ev=Path(args.events_zip).expanduser();flow=Path(args.flow_zip).expanduser()
    inv=inventory(ev,flow)
    if args.profile=='inventory':
        print('INVENTORY_PASS_METADATA_ONLY',canonical(inv))
        return 0
    if args.out is None:
        raise RuntimeError('OUTPUT_REQUIRED')
    dest=Path(args.out)
    if dest.exists():
        raise RuntimeError('OUTPUT_EXISTS_NO_OVERWRITE')
    # Fail before reading selected H5 if wrong source/original engine.
    compute=v0.load_compute(args.source_root)
    if args.profile not in ('smoke','full'):
        raise RuntimeError('UNKNOWN_PROFILE')
    sources=prepare_dev(ev,flow,Path(args.intake).expanduser())
    pairs=pair_times(Path(sources['flow/forward_timestamps.txt']['path']))
    try:
        import numpy as np
        import hdf5plugin  # noqa: F401 - register DSEC Blosc ZSTD decoder
        import h5py
    except ImportError as e:
        raise RuntimeError('MISSING_PYTHON_DEPS: install numpy h5py hdf5plugin in active venv') from e
    count=1 if args.profile=='smoke' else 4
    per_pair=[]
    with h5py.File(sources['events/left/events.h5']['path'],'r') as h5, \
         h5py.File(sources['events/left/rectify_map.h5']['path'],'r') as maps:
        rect=maps['rectify_map'][:]
        for idx,ab in enumerate(pairs[:count]):
            c6,pi,raw=dataset_bins(h5,rect,ab)
            stimuli,encoding=encode_inputs(c6,pi)
            cfg=mesh.Config(horizon=64,stimulus_last_tick=24,max_processed_events=1_000_000)
            result=run_episode(compute,cfg,stimuli,encoding,idx)
            # Final report only aggregate counts and SHA; no raw event/GT pixels.
            sensor={'pair':idx,'raw':raw,'encode':encoding,'pair_digest':result['pair_digest']}
            for kind in ('mesh_off','mesh_on'):
                s=result[kind]
                sensor[kind]={
                    'stats':s['stats'],
                    'per_island':[{k:i[k] for k in ('id','neurons','processed','emissions','queue_peak','dropped_queue',
                                                  'dropped_horizon','dropped_tick_budget')}
                                  for i in s['per_island']],
                    'active_neurons_processed_per_island':s['active_neurons_processed_per_island'],
                    'active_neurons_processed_total':s['active_neurons_processed_total'],
                    'state_sha256':s['state_sha256'],'trace_sha256':s['trace_sha256'],
                }
            sensor['state_changed']=result['state_changed']
            sensor['pi_state_changed']=result['pi_state_changed']
            per_pair.append(sensor)
            print('PROGRESS_DSEC_DEV_PAIR',idx,'RAW_EVENTS',raw['raw_events'],
                  'SENSOR_SPIKES',encoding['sensor_spike_total'],
                  'MESH_PACKETS',sensor['mesh_on']['stats'].get('packets_created',0),flush=True)
    report={'schema':SCHEMA,'scope':'DSEC_THUN_00_A_EXPOSED_DEV_NO_GT_PIXELS_READ',
            'source_dev':SOURCE_DEV,'source_events_zip':inv['event_zip'],
            'source_flow_zip':inv['flow_zip'],'inventory_sha256':digest(inv),
            'verified_dev_input_sha256':{k:v['sha256'] for k,v in sources.items()},
            'source_original_pe_commit':v0.MAIN,'source_original_pe_blobs':v0.PINS,
            'profile':args.profile,'pair_count':count,
            'experiment':'NINE_ISLANDS_8x64_C6_PLUS_1024_PI_ETH_GATEWAY_REAL_DSEC_EVENT_INPUT',
            'input_mapping':'RECTIFIED_LEFT_640x480_C6_16x16x2_PI_32x16x2_FIXED_TOPK_PER_5MS',
            'c6_topk':C6_TOPK,'pi_topk':PI_TOPK,'pulse_bands':[1,40,160],
            'real_time_interval_us_per_pair_approx':100000,'logical_bins_per_pair':TIME_BINS,
            'logical_clock_is_not_physical_time':True,
             'sensor_ingress_policy':'AT_OWN_TICK_BEFORE_MESH_RECEIVE_NO_FUTURE_PREFILL',
            'gt_flow_png_opened':False,'validation_test_payload_read':False,
            'blind_access':False,'learned':False,'bv_writes':0,'original_p_writes':0,
            'per_pair':per_pair,'verdict':'DSEC_DEV_MESH_INGEST_AND_TRANSPORT_ENGINEERING_REFERENCE_SCIENTIFIC_HOLD'}
    report['canonical_sha256']=digest(report)
    dest.mkdir(parents=True)
    (dest/'report.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    (dest/'protocol.json').write_text(json.dumps({
        'schema':SCHEMA+'/preregistered-protocol','source_dev':SOURCE_DEV,
        'stage':'STAGE_A_REAL_DSEC_EVENT_INGEST_ZERO_GT_PIXELS',
        'split':{'dev':SEQUENCE,'val_reserved':RESERVED[0],'blind_reserved':RESERVED[1]},
        'source_pins':PINS,'original_pe_pins':v0.PINS,
        'optical_flow_zip_usage':'READ_ONLY_DEV_FORWARD_TIMESTAMPS_NO_GT_PNG',
        'pair_indices':list(range(count)), 'mapping':'rectified c6 16x16 cells x2 polarities; pi 32x16 x2',
        'tick_bins':TIME_BINS,'topk_c6':C6_TOPK,'topk_pi':PI_TOPK,
        'pulse_thresholds':[1,40,160], 'fixed_boundary':True,
         'sensor_ingress_policy':'AT_OWN_TICK_BEFORE_MESH_RECEIVE_NO_FUTURE_PREFILL',
        'excluded_validation_and_test_gt':True,
        'no_learning_or_bv':True, 'no_native_p_writes':True,
    },sort_keys=True,indent=2)+'\n')
    (dest/'zip_inventory.json').write_text(json.dumps(inv,sort_keys=True,indent=2)+'\n')
    for nm in ('protocol.json','zip_inventory.json','report.json'):
        pass
    (dest/'SHA256SUMS').write_text(''.join(f'{hash_file(dest/nm)}  {nm}\n'
             for nm in ('protocol.json','zip_inventory.json','report.json')))
    total_raw=sum(x['raw']['raw_events'] for x in per_pair)
    total_in=sum(x['encode']['sensor_spike_total'] for x in per_pair)
    total_packets=sum(x['mesh_on']['stats'].get('packets_created',0) for x in per_pair)
    total_delivered=sum(x['mesh_on']['stats'].get('packets_arrived_at_destination',0) for x in per_pair)
    print('RUN_COMPLETE__DSEC_REAL_DEV_STAGE_A_NO_GT_SCIENTIFIC_HOLD')
    print('REAL_RAW_EVENTS',total_raw,'ENCODED_SENSOR_SPIKES',total_in,'DSEC_DEV_PAIRS',count)
    print('NETWORK_PACKETS_CREATED',total_packets,'DELIVERED',total_delivered)
    print('REPORT_SHA256',report['canonical_sha256'])
    print('GT_FLOW_PIXELS_READ',False,'VAL_OR_BLIND_READ',False)
    print('OUTPUT',dest)
    return 0


def cli():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('profile',choices=('inventory','smoke','full'))
    p.add_argument('--events-zip',default='~/Scaricati/train_events.zip')
    p.add_argument('--flow-zip',default='~/Scaricati/train_optical_flow.zip')
    p.add_argument('--intake',default='~/workspace/spk-dsec-intake')
    p.add_argument('--source-root',type=Path,default=None)
    p.add_argument('--out',default=None)
    a=p.parse_args()
    if a.profile!='inventory' and a.source_root is None:
        p.error('--source-root is required for original frozen PE')
    return run(a)

if __name__=='__main__':
    sys.exit(cli())
