#!/usr/bin/env python3
"""SPK/* 9-island reference with an explicitly separate Ethernet/Thread gateway.

8 C6-class compute islands (64 neurons each), 1 Pi5-class compute island
(1024 neurons) and one NON-COMPUTE infrastructure node G9. Pi5 connects to
G9 using Ethernet; G9 has ONE shared abstract IEEE 802.15.4 radio attached
to C6 islands I0 and I4. New scheduler, frozen pinned PE local ISA.

This is neither a physical network emulator nor a proof of OpenThread
compatibility. No BV, learning, native owner writes or blind/holdout data.
"""
from __future__ import annotations
import argparse
import collections
from dataclasses import dataclass, asdict
import hashlib
import json
from pathlib import Path

import spk_mesh9_hybrid_ref_v0 as v0

SCHEMA='spk-mesh-9-ethernet-thread-gateway-reference/v1'
GW=9
HUB=v0.HUB
N_ISLANDS=v0.N_ISLANDS
MAIN=v0.MAIN
PINS=v0.PINS
sha=v0.sha
canonical=v0.canonical


def physical_links():
    """12 old C6 radio links + 2 GW radio links + 1 PI Ethernet link."""
    return tuple(sorted(set(v0.base_undirected()) | {(0,GW),(4,GW),(HUB,GW)}))


def medium(a,b):
    if set((a,b))=={HUB,GW}:
        return 'ETHERNET'
    if a==HUB or b==HUB:
        raise ValueError('PI_DIRECT_RADIO_FORBIDDEN')
    if tuple(sorted((a,b))) not in physical_links():
        raise ValueError('NONEXISTENT_PHYSICAL_LINK')
    return '802154'


def adjacencies():
    a={i:[] for i in range(GW+1)}
    for u,v in physical_links():
        a[u].append(v); a[v].append(u)
    return {i:sorted(x) for i,x in a.items()}


def path(src,dst):
    if not (0<=src<N_ISLANDS and 0<=dst<N_ISLANDS and src!=dst):
        raise ValueError('ISLAND_ENDPOINTS_REQUIRED')
    graph=adjacencies()
    todo=collections.deque([(src,)])
    seen={src}
    while todo:
        p=todo.popleft()
        if p[-1]==dst:
            return p
        for next_node in graph[p[-1]]:
            if next_node not in seen:
                seen.add(next_node)
                todo.append(p+(next_node,))
    raise ValueError('NO_ROUTE')


@dataclass(frozen=True)
class Config(v0.Config):
    gateway_radio_shared_tx_per_tick: int=2
    ethernet_tx_per_tick: int=32
    ethernet_delay_ticks: int=1
    ethernet_queue_cap: int=128
    ethernet_flight_cap: int=32

    def validate(self):
        super().validate()
        if self.ethernet_delay_ticks<=0:
            raise ValueError('ETHERNET_DELAY_INVALID')


class Simulation(v0.Simulation):
    def __init__(self,compute,cfg,enabled):
        super().__init__(compute,cfg,enabled)
        self.links={(a,b):collections.deque() for u,v in physical_links()
                    for a,b in ((u,v),(v,u))}
        self.gateway_shared_peak=0

    def create_packet(self,tick,iid,neuron,eid):
        if iid==HUB:
            dst=(neuron//64)%v0.C6_COUNT
        else:
            dst=HUB if neuron in (0,48) else (iid+2+(neuron//16))%v0.C6_COUNT
        assert dst!=iid
        self.packet_serial+=1
        pkt=v0.Packet(self.packet_serial,iid,neuron,dst,path(iid,dst),0,eid)
        self.stats['packets_created']+=1
        if iid==HUB:
            self.stats['packets_created_from_pi']+=1
        if dst==HUB:
            self.stats['packets_created_to_pi']+=1
        self.log(['packet_create',tick,pkt.pid,iid,neuron,dst,eid,list(pkt.route)])
        self.enqueue_packet(pkt,tick)

    def enqueue_packet(self,pkt,tick):
        link=(pkt.route[pkt.hop_at],pkt.route[pkt.hop_at+1])
        q=self.links[link]
        typ=medium(*link)
        cap=(self.cfg.ethernet_queue_cap if typ=='ETHERNET' else self.cfg.link_queue_cap)
        if len(q)>=cap:
            self.stats['packets_dropped_link_queue']+=1
            if typ=='ETHERNET':
                self.stats['packets_dropped_ethernet_queue']+=1
            self.log(['link_queue_drop',tick,pkt.pid,*link,typ])
            return False
        q.append(pkt)
        self.link_queue_peak[link]=max(self.link_queue_peak[link],len(q))
        return True

    def transmit(self,tick):
        shared=0
        for link in sorted(self.links):
            q=self.links[link]
            typ=medium(*link)
            ethernet=(typ=='ETHERNET')
            per_link=(self.cfg.ethernet_tx_per_tick if ethernet
                      else self.cfg.link_tx_per_tick)
            flight_cap=(self.cfg.ethernet_flight_cap if ethernet
                        else self.cfg.link_flight_cap)
            delay=(self.cfg.ethernet_delay_ticks if ethernet
                   else self.cfg.radio_hop_delay)
            gateway_radio=(GW in link and not ethernet)
            sent=0
            while q and sent<per_link and self.flight_n[link]<flight_cap:
                if gateway_radio and shared>=self.cfg.gateway_radio_shared_tx_per_tick:
                    break
                pkt=q.popleft()
                sent+=1
                if gateway_radio:
                    shared+=1
                    self.stats['gateway_radio_tx']+=1
                self.flight_n[link]+=1
                self.link_flight_peak[link]=max(self.link_flight_peak[link],self.flight_n[link])
                arrive=tick+delay
                self.inflight.setdefault(arrive,[]).append((pkt,link))
                self.stats['link_transmissions']+=1
                self.stats['logical_payload_bytes']+=v0.MESSAGE_BYTES
                if ethernet:
                    self.stats['ethernet_tx']+=1
                    self.stats['ethernet_payload_bytes']+=v0.MESSAGE_BYTES
                else:
                    self.stats['radio_tx']+=1
                    self.stats['radio_payload_bytes']+=v0.MESSAGE_BYTES
                self.log(['tx',tick,pkt.pid,*link,typ,arrive])
        self.gateway_shared_peak=max(self.gateway_shared_peak,shared)

    def run(self):
        out=super().run()
        out['schema']=SCHEMA
        out['config'].pop('pi_rcp_shared_tx_per_tick',None)
        out['topology']={
            'radio_undirected_links':[list(x) for x in physical_links()
                                       if medium(*x)=='802154'],
            'ethernet_undirected_links':[[HUB,GW]],
            'physical_links':len(physical_links()),
            'directed_links':len(self.links),
            'gateway_id':GW,
            'gateway_is_neuron_island':False,
            'gateway_radio_neighbors':[0,4],
            'pi_neighbors_radio':[],
            'pi_neighbors_ethernet':[GW],
            'local_edges':sum(n*v0.FANOUT for n in v0.SIZES),
        }
        out['resources'].pop('pi_radio',None)
        out['resources'].pop('pi_rcp_shared_tx_per_tick',None)
        out['resources'].update({
            'pi_transport':'ETHERNET_IP_BACKHAUL',
            'gateway_transport':'ETHERNET_TO_THREAD_BORDER_ROUTER_ABSTRACT',
            'gateway_has_single_802154_radio':True,
            'gateway_radio_shared_tx_per_tick':self.cfg.gateway_radio_shared_tx_per_tick,
            'gateway_eth_queue_cap':self.cfg.ethernet_queue_cap,
            'gateway_does_not_compute_spk':True,
            'radio_protocol_not_emulated':True,
        })
        out['stats'].pop('pi_rcp_tx_peak_per_tick',None)
        out['stats']['gateway_radio_tx_peak_per_tick']=self.gateway_shared_peak
        out['stats']['radio_link_queue_peak']=max((self.link_queue_peak[k]
            for k in self.links if medium(*k)=='802154'),default=0)
        out['stats']['ethernet_link_queue_peak']=max((self.link_queue_peak[k]
            for k in self.links if medium(*k)=='ETHERNET'),default=0)
        out['stats']['radio_link_flight_peak']=max((self.link_flight_peak[k]
            for k in self.links if medium(*k)=='802154'),default=0)
        out['stats']['ethernet_link_flight_peak']=max((self.link_flight_peak[k]
            for k in self.links if medium(*k)=='ETHERNET'),default=0)
        out['scope']='RESEARCH_FORWARD_ONLY_ORIGINAL_PE_LOCAL_ISA_NEW_GATEWAY_SCHEDULER'
        return out


def run_pair(compute,cfg):
    off=Simulation(compute,cfg,False).run()
    on=Simulation(compute,cfg,True).run()
    result={
        'schema':SCHEMA+'/comparison',
        'source_main_commit':MAIN,'source_pins':PINS,
        'mesh_off':off,'mesh_on':on,
        'same_exogenous_inputs':(off['stats']['external_admitted']==on['stats']['external_admitted']
                          and off['stats']['external_created']==on['stats']['external_created']),
        'state_difference':off['state_sha256']!=on['state_sha256'],
        'pi_state_difference':off['per_island'][HUB]['state_sha256']!=on['per_island'][HUB]['state_sha256'],
        'no_bv_no_learning':True,
        'verdict':'MESH9_ETHERNET_BORDER_GATEWAY_BOUNDED_REFERENCE_PRODUCED',
    }
    result['canonical_sha256']=sha(result)
    return result


def cli():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-root',type=Path,required=True)
    ap.add_argument('--profile',choices=('smoke','full','selftest'),default='smoke')
    ap.add_argument('--out',type=Path)
    args=ap.parse_args()
    compute=v0.load_compute(args.source_root)
    cfg=(Config(horizon=28,stimulus_last_tick=12) if args.profile in ('smoke','selftest')
         else Config())
    result=run_pair(compute,cfg)
    if args.profile=='selftest':
        from test_spk_mesh9_ethgateway_ref_v1 import mirror_compute
        mirror=run_pair(mirror_compute,cfg)
        assert canonical(result)==canonical(mirror),'PINNED_PE_MIRROR_MISMATCH'
        assert result['mesh_on']['stats']['gateway_radio_tx']>0
        print('SELFTEST_GATEWAY_PASS',json.dumps({
            'mesh_to_pi':result['mesh_on']['stats']['packets_arrived_at_pi'],
            'pi_to_mesh':result['mesh_on']['stats']['packets_arrived_from_pi'],
            'gateway_radio_tx':result['mesh_on']['stats']['gateway_radio_tx']},sort_keys=True))
        return
    replay=run_pair(compute,cfg)
    assert canonical(result)==canonical(replay),'REPLAY_MISMATCH'
    if args.out:
        if args.out.exists():
            raise RuntimeError('NONOVERWRITE_OUT_EXISTS')
        args.out.mkdir(parents=True)
        (args.out/'report.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
        (args.out/'protocol.json').write_text(json.dumps({
            'schema':SCHEMA+'/manual', 'profile':args.profile,
            'scope':'C6_THREAD_MESH_PLUS_PI5_ETHERNET_TO_EXTERNAL_THREAD_GATEWAY',
            'source_pins':PINS, 'main':MAIN,
            'config':{k:v for k,v in asdict(cfg).items() if k!='pi_rcp_shared_tx_per_tick'},'physical_links':physical_links(),
            'no_original_p_writes':True, 'no_bv':True,'no_holdout':True,'no_learning':True,
        },sort_keys=True,indent=2)+'\n')
        lines=[f"{hashlib.sha256((args.out/n).read_bytes()).hexdigest()}  {n}" for n in ('protocol.json','report.json')]
        (args.out/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
    off,on=result['mesh_off']['stats'],result['mesh_on']['stats']
    print('RUN_COMPLETE__HYBRID_ETHERNET_GATEWAY_ENGINEERING_RESEARCH_ONLY')
    print('TOPOLOGY',canonical({'islands':9,'neurons':1536,'compute_gateway':False,'external_gateway':GW,
                             'radio_links':14,'ethernet_links':1,'pi_to_gateway_medium':'ETHERNET'}))
    for label,s in [('ISOLATED',off),('MESH',on)]:
        print(label,canonical({k:s.get(k,0) for k in (
            'events_processed','emissions','packets_created','packets_arrived_at_destination',
            'packets_arrived_at_pi','packets_arrived_from_pi','gateway_radio_tx','ethernet_tx',
            'packets_dropped_link_queue')}))
    print('GATEWAY_RADIO_PEAK',on['gateway_radio_tx_peak_per_tick'])
    print('PI_STATE_DIFFERENCE',result['pi_state_difference'])
    print('DETERMINISTIC_REPLAY PASS')
    print('REPORT_SHA256',result['canonical_sha256'])
    if args.out: print('OUTPUT',args.out)

if __name__=='__main__':
    cli()
