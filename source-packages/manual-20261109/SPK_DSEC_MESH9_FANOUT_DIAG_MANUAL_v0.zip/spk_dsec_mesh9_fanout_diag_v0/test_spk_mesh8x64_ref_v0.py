"""Standalone deterministic bounds tests; the launcher ALSO tests pinned PE code."""
from __future__ import annotations

import collections
import unittest

import spk_mesh8x64_ref_v0 as m


def test_compute(node, state, tick, channels):
    """Independent tiny ACC/CMP/EMIT/RESET oracle for transport unit tests.

    Do NOT mistake this oracle for the original PE. Manual fwork selftest and
    full run use frozen unmodified A1b _compute_local after source blob checks.
    """
    raw, previous = state
    assert tick >= previous
    counts = collections.Counter(channels)
    guard = False
    out = []
    for op, arg in node.instructions:
        if op == 'ACC':
            weight, ch = arg
            raw += weight * (1 << node.fractional_bits) * counts[ch]
            if raw >= (1 << node.state_bits):
                raise ValueError('overcapacity')
        elif op == 'CMP':
            guard = raw >= arg
        elif op == 'EMIT':
            if guard:
                out.append(arg)
        elif op == 'RESET':
            if guard:
                raw = arg
        else:
            raise AssertionError(op)
    return raw, guard, tuple(out)


class TestTopology(unittest.TestCase):
    def test_eight_islands_and_fixed_links(self):
        self.assertEqual(len(m.graph()), 12)
        self.assertEqual(len(m.neighbors()), 8)
        self.assertTrue(all(len(v) == 3 for v in m.neighbors().values()))
        self.assertEqual(m.ISLANDS * m.NEURONS, 512)
        self.assertEqual(m.ISLANDS * m.NEURONS * m.FANOUT, 4096)

    def test_shortest_path_deterministic(self):
        self.assertEqual(m.shortest_path(0, 2), (0, 1, 2))
        self.assertEqual(m.shortest_path(0, 4), (0, 4))
        for i in range(m.ISLANDS):
            for j in range(m.ISLANDS):
                if i == j:
                    continue
                route = m.shortest_path(i, j)
                self.assertEqual((route[0], route[-1]), (i, j))
                self.assertTrue(all(y in m.neighbors()[x]
                                    for x, y in zip(route, route[1:])))

    def test_program_subfragment(self):
        n = m.program(0, 0)
        self.assertEqual(n.instructions[0], ('ACC', (1, 1)))
        self.assertEqual(test_compute(n, [0, 0], 1, (1,) * 5), (5, False, ()))
        self.assertEqual(test_compute(n, [5, 1], 2, (1,)), (0, True, (7,)))


class TestReference(unittest.TestCase):
    def setUp(self):
        self.cfg = m.Config(horizon=28, stimulus_last_tick=12)

    def test_packet_delivery_and_routing(self):
        result = m.compare(test_compute, self.cfg)
        off, on = result['mesh_off']['stats'], result['mesh_on']['stats']
        self.assertEqual(off.get('packets_created', 0), 0)
        self.assertGreater(on['packets_created'], 0)
        self.assertGreater(on['packets_delivered_target'], 0)
        self.assertGreater(on['hop_arrivals'], on['packets_delivered_target'])
        self.assertTrue(result['island_state_changed_by_mesh'])

    def test_conservation_and_order(self):
        result = m.compare(test_compute, self.cfg)
        for item in (result['mesh_off'], result['mesh_on']):
            stats = item['stats']
            self.assertEqual(stats['external_created'],
                             stats.get('external_admitted', 0) + stats.get('external_rejected', 0))
            self.assertEqual(stats['local_edge_events_created'],
                             stats.get('local_edge_events_admitted', 0) + stats.get('local_edge_events_rejected', 0))
            self.assertEqual(stats.get('bv_writes', 0), 0)
            self.assertTrue(all(x['queue_peak'] <= self.cfg.local_queue_cap
                                for x in item['per_island']))
            self.assertLessEqual(item['max_link_queue'], self.cfg.link_queue_cap)
            self.assertLessEqual(item['max_link_inflight'], self.cfg.link_flight_cap)

    def test_replay_deterministic(self):
        a = m.compare(test_compute, self.cfg)
        b = m.compare(test_compute, self.cfg)
        self.assertEqual(m.canonical(a), m.canonical(b))
        self.assertEqual(a['mesh_on']['trace_sha256'], b['mesh_on']['trace_sha256'])

    def test_queue_backpressure_is_reported(self):
        cfg = m.Config(horizon=28, stimulus_last_tick=12,
                       local_queue_cap=5, link_queue_cap=1,
                       link_flight_cap=1, link_per_tick_cap=1)
        out = m.Simulation(test_compute, cfg, True).run()
        self.assertGreater(out['stats']['external_rejected'], 0)
        self.assertLessEqual(out['max_link_queue'], 1)
        self.assertTrue(all(x['queue_peak'] <= 5 for x in out['per_island']))

    def test_no_mesh_isolation(self):
        out = m.Simulation(test_compute, self.cfg, False).run()
        self.assertEqual(out['stats'].get('packets_created', 0), 0)
        self.assertEqual(out['stats'].get('mesh_neuron_admitted', 0), 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
