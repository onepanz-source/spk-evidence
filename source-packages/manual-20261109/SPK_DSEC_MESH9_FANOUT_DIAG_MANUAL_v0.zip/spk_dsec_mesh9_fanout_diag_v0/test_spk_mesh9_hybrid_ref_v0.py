"""Independent ISA-mirror unit tests for bounded 9-island mesh scheduler.

These do NOT authenticate original PE. Manual launcher separately verifies the
frozen source hashes and runs original _compute_local through all islands.
"""
from __future__ import annotations
import collections
import unittest
import spk_mesh9_hybrid_ref_v0 as m
import spk_mesh8x64_ref_v0 as old


def mirror_compute(node, state, tick, channels):
    raw, prev = state
    if tick < prev:
        raise ValueError('BACKWARD_TIME')
    count = collections.Counter(channels)
    guard = False
    emitted = []
    for op, arg in node.instructions:
        if op == 'ACC':
            w, channel = arg
            raw += w * (1 << node.fractional_bits) * count[channel]
            if raw >= (1 << node.state_bits):
                raise ValueError('OVERFLOW')
        elif op == 'CMP':
            guard = raw >= arg
        elif op == 'EMIT':
            if guard:
                emitted.append(arg)
        elif op == 'RESET':
            if guard:
                raw = arg
        else:
            raise AssertionError('OP_NOT_ADMITTED')
    return raw, guard, tuple(emitted)


class Topology(unittest.TestCase):
    def test_8_c6_and_one_pi_exactly(self):
        self.assertEqual(m.SIZES, (64,)*8 + (1024,))
        self.assertEqual(sum(m.SIZES), 1536)
        self.assertEqual(sum(m.SIZES)*m.FANOUT, 12288)
        self.assertEqual(len(m.base_undirected()),12)
        self.assertEqual(len(m.hybrid_undirected()),14)
        self.assertEqual(len(m.adjacencies()[m.HUB]),2)
        self.assertEqual(m.adjacencies()[m.HUB],[0,4])

    def test_routes_reachable_without_virtual_full_mesh(self):
        for src in range(m.N_ISLANDS):
            for dst in range(m.N_ISLANDS):
                if src != dst:
                    p=m.path(src,dst)
                    self.assertEqual((p[0],p[-1]),(src,dst))
                    for a,b in zip(p,p[1:]):
                        self.assertIn(b,m.adjacencies()[a])
        self.assertEqual(m.path(8,0),(8,0))
        self.assertEqual(m.path(8,2),(8,0,1,2))

    def test_original_subfragment_mirror(self):
        pi = m.neuron_program(m.HUB,0)
        self.assertEqual(mirror_compute(pi,[0,0],1,(1,)*6),(0,True,(7,)))
        c6 = m.neuron_program(0,1)
        self.assertEqual(mirror_compute(c6,[0,0],1,(1,)*3),(3,False,()))

    def test_resource_model_is_not_hardware_measurement(self):
        x=m.Simulation(mirror_compute,m.Config(horizon=28,stimulus_last_tick=12),False)
        snap=[i.snapshot() for i in x.islands]
        self.assertEqual(snap[0]['queue_capacity'],256)
        self.assertEqual(snap[8]['queue_capacity'],2048)
        self.assertLess(snap[0]['sram_layout_model_bytes'],512*1024)
        self.assertLess(snap[8]['sram_layout_model_bytes'],4*1024*1024)


class Simulation(unittest.TestCase):
    def setUp(self):
        self.cfg = m.Config(horizon=32, stimulus_last_tick=12)

    def test_legacy_eight_island_off_counts_preserved(self):
        """Small islands, in isolation, must match frozen 8x64 reference.

        PI external sensor events are additional but must not affect C6 state.
        """
        old_cfg = old.Config(horizon=32,stimulus_last_tick=12)
        old_result = old.Simulation(mirror_compute,old_cfg,False).run()
        new_result = m.Simulation(mirror_compute,self.cfg,False).run()
        for small, classic in zip(new_result['per_island'][:8],old_result['per_island']):
            self.assertEqual(small['processed'],classic['processed'])
            self.assertEqual(small['batches'],classic['batches'])
            self.assertEqual(small['emissions'],classic['emissions'])
            self.assertEqual(small['queue_peak'],classic['queue_peak'])

    def test_bidirectional_real_radio_hops(self):
        out=m.run_pair(mirror_compute,self.cfg)
        s=out['mesh_on']['stats']
        self.assertGreater(s['packets_created_to_pi'],0)
        self.assertGreater(s['packets_created_from_pi'],0)
        self.assertGreater(s['packets_arrived_at_pi'],0)
        self.assertGreater(s['packets_arrived_from_pi'],0)
        self.assertGreater(s['link_transmissions'],s['packets_arrived_at_destination'])
        self.assertEqual(out['mesh_off']['stats'].get('packets_created',0),0)
        self.assertTrue(out['state_difference'])

    def test_shared_pi_radio_budget(self):
        cfg=m.Config(horizon=32,stimulus_last_tick=12,pi_rcp_shared_tx_per_tick=1)
        s=m.Simulation(mirror_compute,cfg,True).run()
        self.assertLessEqual(s['stats']['pi_rcp_tx_peak_per_tick'],1)
        self.assertGreater(s['stats']['pi_rcp_link_transmissions'],0)
        self.assertLessEqual(s['stats']['pi_rcp_link_transmissions'],
                             s['stats']['link_transmissions'])

    def test_no_silent_loss_and_queue_bounds(self):
        cfg=m.Config(horizon=32,stimulus_last_tick=12,link_queue_cap=1,
                     link_flight_cap=1,link_tx_per_tick=1,pi_rcp_shared_tx_per_tick=1)
        x=m.Simulation(mirror_compute,cfg,True).run()
        s=x['stats']
        self.assertEqual(s['packets_created'],s['packets_arrived_at_destination']+
                         s.get('packets_dropped_link_queue',0)+
                         s['link_queued_at_horizon']+s['link_flight_at_horizon'])
        self.assertLessEqual(s['link_queue_peak'],1)
        self.assertLessEqual(s['link_flight_peak'],1)
        self.assertLessEqual(s['pi_rcp_tx_peak_per_tick'],1)
        self.assertTrue(all(row['queue_peak']<=row['queue_capacity'] for row in x['per_island']))

    def test_deterministic_against_independent_island_runs(self):
        a=m.run_pair(mirror_compute,self.cfg)
        b=m.run_pair(mirror_compute,self.cfg)
        self.assertEqual(m.canonical(a),m.canonical(b))
        self.assertEqual(a['canonical_sha256'],m.sha({k:v for k,v in a.items() if k!='canonical_sha256'}))

    def test_negative_local_queue_pressure_reported(self):
        # Explicitly monkeypatch capacity on fresh island objects; no mutation
        # of the production resource configuration or source program.
        sim=m.Simulation(mirror_compute,self.cfg,False)
        for island in sim.islands:
            island.capacity=5
        out=sim.run()
        self.assertGreater(out['stats']['external_rejected'],0)
        self.assertTrue(all(x['queue_peak']<=5 for x in out['per_island']))

    def test_no_bv_learning_or_native_write(self):
        x=m.run_pair(mirror_compute,self.cfg)
        for mode in ('mesh_off','mesh_on'):
            a=x[mode]
            self.assertEqual((a['P_writes'],a['bv_writes'],a['learning_updates'],a['holdout_accesses']),
                             (0,0,0,0))

if __name__ == '__main__':
    unittest.main(verbosity=2)
