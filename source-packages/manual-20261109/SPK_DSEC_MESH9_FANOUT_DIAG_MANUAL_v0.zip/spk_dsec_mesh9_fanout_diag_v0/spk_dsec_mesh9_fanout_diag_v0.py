#!/usr/bin/env python3
"""DSEC DEV pair0 causal congestion counterfactual, fixed sensor/ISA source.

No GT pixels, no validation/blind dataset payload, no learning/BV/P writes.
One original DSEC pair and the exact same 4867 prelocked input spikes are used
for all arms. Only an independent per-emission local ROUTE ENABLE MASK changes.
The stored 8-edge topology and memory layout remains unchanged; only the number
of enabled outgoing local routes changes. No inference from optical-flow GT.
"""
from __future__ import annotations
import argparse
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import sys

import spk_dsec_mesh9_dev_v0 as dsec
import spk_mesh9_ethgateway_ref_v1 as mesh
import spk_mesh9_hybrid_ref_v0 as v0

SCHEMA='spk-dsec-mesh9-causal-fanout-diagnostic/v0'
FANOUTS=(0,1,2,4,8)
DEV_PAIR_INDEX=0
# Pin exact v0p2 REAL fwork smoke stimulus readout without its unavailable HDF5 bytes.
ANCHOR_INPUT_SHA256='b3ddbbfe2c4816671035c6e673c09a89e206b1b312fcee06478cd216341ba4a4'
ANCHOR_SENSOR_PULSES=4867
ANCHOR_OUT={'state_sha256':'45b2e969af36b15d6df7273a58b94863fef9f56e383ad2ac30a6a4318cfd980c',
            'trace_sha256':'20cd12c8fcbc8cdcaeab2b0b1d3d6134bd1676d2b44f547b9b613732daf91424'}
ANCHOR_ON={'state_sha256':'84d86e2b6ee8545b5a259709971fc0edea71bf3c7bf950b4418acbd14b3e8812',
           'trace_sha256':'34826a1a45a00b37009f8116a0710878cdb1a64cb18c8a1ff3ebe4bd763e70e5'}

@contextmanager
def masked_local_routes(fanout:int):
    """Gate a prefix of routes only; preserve original ISA and source files."""
    if type(fanout) is not int or fanout not in FANOUTS:
        raise ValueError('INVALID_EFFECTIVE_FANOUT')
    before=v0.EDGE_OFFSETS
    if before!=(1,2,3,5,8,13,21,34):
        raise RuntimeError('FROZEN_LOCAL_EDGE_OFFSETS_CHANGED')
    try:
        v0.EDGE_OFFSETS=before[:fanout]
        yield
    finally:
        v0.EDGE_OFFSETS=before

class DiagnosticSimulation(dsec.RealDSECSimulation):
    def __init__(self,compute,cfg,enabled,stimuli):
        self.tick_audit=[]
        super().__init__(compute,cfg,enabled,stimuli)

    def receive(self,tick):
        before_admitted=self.stats.get('external_admitted',0)
        before_rejected=self.stats.get('external_rejected',0)
        local_before=[i.queued for i in self.islands]
        super().receive(tick)
        self.tick_audit.append({
            'tick':tick,
            'external_admitted':self.stats.get('external_admitted',0)-before_admitted,
            'external_rejected':self.stats.get('external_rejected',0)-before_rejected,
            'local_queue_before_receive':local_before,
            'local_queue_after_receive':[i.queued for i in self.islands],
        })

    def compute_local(self,tick):
        before_processed=self.stats.get('events_processed',0)
        before_emitted=self.stats.get('emissions',0)
        super().compute_local(tick)
        assert self.tick_audit[-1]['tick']==tick
        self.tick_audit[-1].update({
            'processed':self.stats.get('events_processed',0)-before_processed,
            'emitted':self.stats.get('emissions',0)-before_emitted,
            'local_queue_after_compute':[i.queued for i in self.islands],
        })

    def run(self):
        result=super().run()
        if len(self.tick_audit)!=self.cfg.horizon:
            raise RuntimeError('TICK_TELEMETRY_INCOMPLETE')
        return result

def run_arm(compute, cfg, stimuli, fanout, mesh_enabled):
    with masked_local_routes(fanout):
        sim=DiagnosticSimulation(compute,cfg,mesh_enabled,stimuli)
        out=sim.run()
    s=out['stats']
    delivered=s.get('packets_arrived_at_destination',0)
    admitted=s.get('mesh_neuron_admitted',0)
    rejected=s.get('mesh_neuron_rejected',0)
    packets=s.get('packets_created',0)
    assert s.get('external_created',0)==s.get('external_admitted',0)+s.get('external_rejected',0)
    assert s.get('local_edge_events_created',0)==fanout*s.get('emissions',0)
    assert s.get('local_edge_events_created',0)==s.get('local_edge_events_admitted',0)+s.get('local_edge_events_rejected',0)
    assert delivered==admitted+rejected
    assert packets==(delivered+s.get('packets_dropped_link_queue',0)+
                     s.get('link_queued_at_horizon',0)+s.get('link_flight_at_horizon',0))
    assert sum(x['external_admitted'] for x in sim.tick_audit)==s.get('external_admitted',0)
    assert sum(x['external_rejected'] for x in sim.tick_audit)==s.get('external_rejected',0)
    assert sum(x['processed'] for x in sim.tick_audit)==s.get('events_processed',0)
    assert sum(x['emitted'] for x in sim.tick_audit)==s.get('emissions',0)
    if fanout==0 and not mesh_enabled:
        assert not s.get('external_rejected',0)
        assert not s.get('local_edge_events_created',0)
        assert not s.get('packets_created',0)
    return out, sim.tick_audit

def encode_dev_only(events_zip,flow_zip,intake,source_root):
    # Calls the original v0p2 fail-closed ZIP inventory and DEV SHA verifier.
    inv=dsec.inventory(events_zip,flow_zip)
    sources=dsec.prepare_dev(events_zip,flow_zip,intake)
    pairs=dsec.pair_times(Path(sources['flow/forward_timestamps.txt']['path']))
    import numpy as np  # noqa: F401
    import hdf5plugin  # noqa: F401
    import h5py
    with h5py.File(sources['events/left/events.h5']['path'],'r') as h5, \
         h5py.File(sources['events/left/rectify_map.h5']['path'],'r') as maps:
        rect=maps['rectify_map'][:]
        c6,pi,raw=dsec.dataset_bins(h5,rect,pairs[DEV_PAIR_INDEX])
    stimuli,encoding=dsec.encode_inputs(c6,pi)
    if encoding['sensor_input_sha256']!=ANCHOR_INPUT_SHA256 or encoding['sensor_spike_total']!=ANCHOR_SENSOR_PULSES:
        raise RuntimeError('SENSOR_ENCODE_DEV_PAIR0_DIVERGED_FROM_FROZEN_V0P2')
    return inv,sources,raw,stimuli,encoding

def run(args):
    out=Path(args.out)
    if out.exists():raise RuntimeError('OUTPUT_EXISTS_NO_OVERWRITE')
    if args.source_root is None:raise RuntimeError('PINNED_ORIGINAL_PE_SOURCE_REQUIRED')
    compute=v0.load_compute(args.source_root)  # byte exact pinned original source
    inv,sources,raw,stimuli,enc=encode_dev_only(Path(args.events_zip).expanduser(),
        Path(args.flow_zip).expanduser(),Path(args.intake).expanduser(),args.source_root)
    cfg=mesh.Config(horizon=64,stimulus_last_tick=24,max_processed_events=1_000_000)
    runs=[]; ticks=[]
    for f in FANOUTS:
        for on in (False,True):
            result,history=run_arm(compute,cfg,stimuli,f,on)
            s=result['stats']
            if f==8:
                pin=ANCHOR_ON if on else ANCHOR_OUT
                for k,want in pin.items():
                    if result[k]!=want:raise RuntimeError(f'FROZEN_V0P2_REFERENCE_ANCHOR_MISMATCH_{k}_{int(on)}')
            tag=f'fanout{f}_mesh{int(on)}'
            runs.append({
                'arm':tag,'effective_local_fanout':f,'mesh_enabled':on,
                'external_created':s.get('external_created',0),
                'external_admitted':s.get('external_admitted',0),
                'external_rejected':s.get('external_rejected',0),
                'events_processed':s.get('events_processed',0),
                'emissions':s.get('emissions',0),
                'local_edge_events_created':s.get('local_edge_events_created',0),
                'local_edge_events_admitted':s.get('local_edge_events_admitted',0),
                'local_edge_events_rejected':s.get('local_edge_events_rejected',0),
                'dropped_tick_budget':s.get('dropped_tick_budget',0),
                'active_neurons_processed_total':result['active_neurons_processed_total'],
                'active_neurons_processed_per_island':result['active_neurons_processed_per_island'],
                'packets_created':s.get('packets_created',0),
                'packets_arrived_at_destination':s.get('packets_arrived_at_destination',0),
                'mesh_neuron_admitted':s.get('mesh_neuron_admitted',0),
                'mesh_neuron_rejected':s.get('mesh_neuron_rejected',0),
                'packets_dropped_link_queue':s.get('packets_dropped_link_queue',0),
                'link_queued_at_horizon':s.get('link_queued_at_horizon',0),
                'link_flight_at_horizon':s.get('link_flight_at_horizon',0),
                'per_island_queue_peak':[i['queue_peak'] for i in result['per_island']],
                'per_island_dropped_queue':[i['dropped_queue'] for i in result['per_island']],
                'per_island_dropped_horizon':[i['dropped_horizon'] for i in result['per_island']],
                'trace_sha256':result['trace_sha256'],
                'state_sha256':result['state_sha256'],
                'tick_telemetry_sha256':dsec.digest(history),
            })
            ticks.extend({'arm':tag,**t} for t in history)
            print('ARM',tag,'EXT_ADM',s.get('external_admitted',0),'EXT_REJ',s.get('external_rejected',0),
                  'LOCAL_CREATED',s.get('local_edge_events_created',0),
                  'MESH_PACKETS',s.get('packets_created',0),'MESH_ADM',s.get('mesh_neuron_admitted',0),
                  flush=True)
    assert len(runs)==len(FANOUTS)*2
    report={
        'schema':SCHEMA,'scope':'DEV_THUN_00_A_PAIR0_CAUSAL_LOAD_DIAGNOSTIC_NO_FLOW_GT',
        'description':'COUNTERFACTUAL_ENABLED_LOCAL_EDGE_MASK_ON_SAME_ALLOCATED_8_EDGE_GRAPH',
        'not_a_learning_or_prediction_score':True,
        'original_local_PE_main_commit':v0.MAIN,'original_PE_blobs':v0.PINS,
        'source_pins':dsec.PINS,
        'real_raw_events':raw['raw_events'],'rectified_valid_events':raw['rectified_valid_events'],
        'sensor_input_sha256':enc['sensor_input_sha256'],'sensor_spike_total':enc['sensor_spike_total'],
        'same_sensory_input_every_arm':True,'fixed_input_topk_and_theta':True,
        'local_edge_offsets_allocation':list(v0.EDGE_OFFSETS),
        'effective_fanout_arms':list(FANOUTS),'mesh_arms':[False,True],
        'simulation_horizon':64,
        'note':'Logical ticks not calibrated to physical Thread radio duration; changing enabled route count is a controlled diagnostic, not native synapse learning.',
        'runs':runs,
        'tick_audit_records':len(ticks),
        'tick_audit_sha256':dsec.digest(ticks),
        'gt_pixels_read':False,'validation_or_blind_read':False,
        'bv_writes':0,'learning_updates':0,'original_p_writes':0,
        'verdict':'DSEC_MESH9_FANOUT_COUNTERFACTUAL_RESEARCH_DIAGNOSTIC_ONLY',
    }
    report['canonical_sha256']=dsec.digest(report)
    protocol={
        'schema':SCHEMA+'/protocol','source_archive_names':['train_events.zip','train_optical_flow.zip'],
        'scene':'thun_00_a','dev_pair_index':0,
        'source_original_pe':v0.MAIN, 'source_pins':dsec.PINS,
        'actor_program_unchanged':True, 'neuron_counts':[64]*8+[1024],
        'allocated_local_routes_per_neuron':8,
        'enabled_local_routes_per_neuron':list(FANOUTS),
        'route_enable_order':list(v0.EDGE_OFFSETS),
        'mesh_enabled':[False,True],
        'same_stimuli_sha256':enc['sensor_input_sha256'],
        'same_stimuli_pulses':enc['sensor_spike_total'],
        'reference_anchor_report_sha256':'f3c78e6906c7b2b5e9fac1136ca1af6e4b7b479cfd2bc2f85becd3d9d23103bc',
        'fixed_sensory_encoding':{'c6_topk':dsec.C6_TOPK,'pi_topk':dsec.PI_TOPK,'bins':dsec.TIME_BINS,
                                   'bands':[1,40,160]},
        'read_no_gt_png':True,'reserved_validation_blind_data_not_read':True,
        'original_P_writes':0,'native_learning':False,
        'result_is_research_only':True,
    }
    out.mkdir(parents=True)
    (out/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    (out/'protocol.json').write_text(json.dumps(protocol,indent=2,sort_keys=True)+'\n')
    (out/'tick_telemetry.jsonl').write_text(''.join(dsec.canonical(t)+'\n' for t in ticks))
    (out/'SHA256SUMS').write_text(''.join(f'{dsec.hash_file(out/n)}  {n}\n' for n in
          ['report.json','protocol.json','tick_telemetry.jsonl']))
    print('DIAGNOSTIC_COMPLETE_DSEC_DEV_ONLY_NO_GT_NO_BV_NO_P_WRITES')
    print('REPORT_SHA256',report['canonical_sha256'])
    print('TICK_TELEMETRY_SHA256',report['tick_audit_sha256'])
    print('OUTPUT',out)
    return 0

def cli():
    p=argparse.ArgumentParser()
    p.add_argument('--events-zip',default='~/Scaricati/train_events.zip')
    p.add_argument('--flow-zip',default='~/Scaricati/train_optical_flow.zip')
    p.add_argument('--intake',default='~/workspace/spk-dsec-intake')
    p.add_argument('--source-root',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    return run(p.parse_args())

if __name__=='__main__':
    sys.exit(cli())
