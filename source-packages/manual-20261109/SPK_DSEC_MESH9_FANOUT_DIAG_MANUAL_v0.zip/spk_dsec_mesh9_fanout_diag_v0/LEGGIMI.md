# SPK/* DSEC-MESH9 causal fanout diagnostic v0 — manual fwork

Questo **non** è un nuovo test di accuratezza del movimento: misura il motivo per cui i 4.867 spike DSEC DEV generano >202.000 eventi di connessione locale e saturano la mesh.

- Dati: ESATTAMENTE `thun_00_a` primo pair DSEC DEV autorizzato, eventi H5 e mappa di rettifica da `~/Scaricati/train_events.zip`; `train_optical_flow.zip` utilizzato SOLO per `flow/forward_timestamps.txt`. Zero PNG optical flow o dati validation/blind letti.
- Rete immutata: 8 isole ESP32-C6 ×64 neuroni, 1 isola Pi5 ×1024, gateway Ethernet/Thread separato, programma SPK `ACC/CMP/EMIT/RESET` da sorgente originale PINNATO. Zero apprendimento, BV/P write.
- Esperimento controllato: stesse 4.867 occorrenze sensoriali e stesse soglie/programmi in 10 bracci. Agiscono SOLO i collegamenti locali abilitati per emissione: 0, 1, 2, 4 o 8 su 8 connessioni allocate per neurone; ciascuno mesh OFF/ON. La memoria di modello continua a riservare tutte le 8 connessioni. Un esperimento di sensibilità strutturale, non una proposta automatica di ridurre il fanout a regime.
- Controllo fondamentale: con 8 collegamenti e mesh ON/OFF **gli hash di stato e traccia devono essere identici** al run reale v0p2 verificato, altrimenti STOP. Non serve accesso ai PNG GT.
- Per ogni braccio: numero di ingressi ammessi/rifiutati, eventi elaborati, emissioni, eventi locali generati, saturazione code, pacchetti consegnati / rifiutati ai neuroni, numero neuroni attivi, e un audit tick-per-tick. Un numero di emissioni superiore non equivale a migliore elaborazione o informazione.

## Fedora fwork

Scaricare `SPK_DSEC_MESH9_FANOUT_DIAG_MANUAL_v0.zip` in `~/Scaricati`:

```bash
cd ~/Scaricati
unzip SPK_DSEC_MESH9_FANOUT_DIAG_MANUAL_v0.zip
cd spk_dsec_mesh9_fanout_diag_v0
source ~/Scaricati/spk_dsec_mesh9_dev_v0/.venv/bin/activate
bash run_spk_dsec_mesh9_fanout_diag_manual.sh
```

Il programma controlla gli SHA256 di tutti i sorgenti e recupera solo gli stessi tre DEV members già estratti, con hash storici D0. Non riscarica il dataset. Produce un nuovo archivio append-only in `~/workspace/spk-manual-runs/` con file `.sha256` separato. Caricare entrambi in ChatGPT.

L'esecuzione dei 10 bracci può occupare più tempo del test smoke, perché ripete la simulazione con 5 maschere. Non avviare il vecchio `full` mentre è in corso l'audit del carico. Nessun M/W/V scheduler, nessun merge, nessuna modifica del PE o delle ISA.
