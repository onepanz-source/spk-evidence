"""Independent local-ISA mirror tests: NOT a second mesh-scheduler implementation."""
import unittest
import spk_mesh9_ethgateway_ref_v1 as m
import spk_mesh9_hybrid_ref_v0 as prev
from test_spk_mesh9_hybrid_ref_v0 import mirror_compute


class GatewayTopology(unittest.TestCase):
    def test_ten_physical_participants_nine_spk_islands(self):
        self.assertEqual(m.N_ISLANDS,9)
        self.assertEqual(m.GW,9)
        self.assertEqual(len(m.physical_links()),15)
        self.assertEqual(len([l for l in m.physical_links() if m.medium(*l)=='802154']),14)
        self.assertEqual([l for l in m.physical_links() if m.medium(*l)=='ETHERNET'],[(8,9)])
        self.assertEqual(m.adjacencies()[8],[9])
        self.assertEqual(m.adjacencies()[9],[0,4,8])
        self.assertEqual(sum(prev.SIZES),1536)

    def test_pi_cannot_use_direct_radio(self):
        self.assertEqual(m.path(8,0),(8,9,0))
        self.assertEqual(m.path(0,8),(0,9,8))
        for src in range(9):
            for dst in range(9):
                if src==dst: continue
                p=m.path(src,dst)
                for a,b in zip(p,p[1:]):
                    self.assertIn(b,m.adjacencies()[a])
                    self.assertFalse(m.medium(a,b)=='802154' and (8 in (a,b)))
        with self.assertRaises(ValueError):m.medium(8,0)

    def test_config_rejects_unbounded(self):
        for field in ('gateway_radio_shared_tx_per_tick','ethernet_tx_per_tick',
                      'ethernet_delay_ticks','ethernet_queue_cap','ethernet_flight_cap'):
            kw={field:0}
            with self.assertRaises(ValueError):m.Config(**kw).validate()


class GatewayTransport(unittest.TestCase):
    def setUp(self):self.cfg=m.Config(horizon=32,stimulus_last_tick=12)

    def test_ethernet_and_radio_are_separate_transport(self):
        r=m.run_pair(mirror_compute,self.cfg)
        a=r['mesh_on']; s=a['stats']
        self.assertTrue(r['pi_state_difference'])
        self.assertEqual(a['topology']['pi_neighbors_radio'],[])
        self.assertEqual(a['topology']['pi_neighbors_ethernet'],[9])
        self.assertEqual(a['topology']['gateway_is_neuron_island'],False)
        self.assertGreater(s['ethernet_tx'],0)
        self.assertGreater(s['gateway_radio_tx'],0)
        self.assertEqual(s['radio_tx']+s['ethernet_tx'],s['link_transmissions'])
        self.assertEqual(s['radio_payload_bytes']+s['ethernet_payload_bytes'],s['logical_payload_bytes'])
        self.assertGreater(s['packets_arrived_at_pi'],0)
        self.assertGreater(s['packets_arrived_from_pi'],0)
        self.assertTrue(r['same_exogenous_inputs'])

    def test_gateway_radio_shared_capacity_both_directions(self):
        cfg=m.Config(horizon=32,stimulus_last_tick=12,gateway_radio_shared_tx_per_tick=1)
        r=m.Simulation(mirror_compute,cfg,True).run()
        self.assertLessEqual(r['stats']['gateway_radio_tx_peak_per_tick'],1)
        self.assertGreater(r['stats']['gateway_radio_tx'],0)

    def test_radio_queue_pressure_explicit(self):
        cfg=m.Config(horizon=32,stimulus_last_tick=12,
                     link_queue_cap=1,link_tx_per_tick=1,link_flight_cap=1,
                     gateway_radio_shared_tx_per_tick=1)
        r=m.Simulation(mirror_compute,cfg,True).run()
        s=r['stats']
        self.assertEqual(s['packets_created'],s['packets_arrived_at_destination']+
            s.get('packets_dropped_link_queue',0)+s['link_flight_at_horizon']+s['link_queued_at_horizon'])
        self.assertLessEqual(s['radio_link_queue_peak'],1)
        self.assertLessEqual(s['gateway_radio_tx_peak_per_tick'],1)

    def test_ethernet_queue_pressure_explicit(self):
        cfg=m.Config(horizon=32,stimulus_last_tick=12,ethernet_queue_cap=1,
                     ethernet_tx_per_tick=1,ethernet_flight_cap=1)
        r=m.Simulation(mirror_compute,cfg,True).run()
        self.assertLessEqual(r['stats']['ethernet_link_queue_peak'],1)
        self.assertGreater(r['stats']['ethernet_tx'],0)

    def test_old_small_island_off_unchanged(self):
        old=prev.Simulation(mirror_compute,prev.Config(horizon=32,stimulus_last_tick=12),False).run()
        now=m.Simulation(mirror_compute,self.cfg,False).run()
        for x,y in zip(old['per_island'],now['per_island']):
            self.assertEqual(x['state_sha256'],y['state_sha256'])
        self.assertEqual(old['stats']['events_processed'],now['stats']['events_processed'])

    def test_deterministic_and_no_native_writes(self):
        a=m.run_pair(mirror_compute,self.cfg)
        b=m.run_pair(mirror_compute,self.cfg)
        self.assertEqual(m.canonical(a),m.canonical(b))
        self.assertEqual(a['canonical_sha256'],m.sha({k:v for k,v in a.items() if k!='canonical_sha256'}))
        for k in ('mesh_off','mesh_on'):
            self.assertEqual((a[k]['P_writes'],a[k]['bv_writes'],a[k]['learning_updates'],a[k]['holdout_accesses']),(0,0,0,0))

if __name__=='__main__':unittest.main(verbosity=2)
