#!/usr/bin/env python3
"""SPK-MESH-8x64 reference v0: bounded, deterministic forward-only islands.

Research engineering reference, NOT ESP32 firmware. Each local neuron batch is
computed by the unmodified pinned SPK PE _compute_local() ISA fragment.
The multi-island scheduler and bounded mesh transport are NEW reference code,
not frozen native owner dispatch. No learning, no BV→P or owner writes.
"""
from __future__ import annotations

import argparse
import collections
from dataclasses import asdict, dataclass
import hashlib
import heapq
import importlib
import json
from pathlib import Path
import sys

SCHEMA = "spk-mesh-8x64-forward-reference/v0"
MAIN_COMMIT = "787c8fbed87c1e2e4b703e985f68ae53c81c8444"
SOURCE_PINS = {
    "spk_architecture_v1/pe_execution_v1b.py": "2e16bdeddc7fc5eacbd341a6dbdf245d71095678",
    "spk_architecture_v1/pe_fabric_v1a.py": "b0cf8b01a8e5ede6ad640349e11b91194c454763",
}
ISLANDS = 8
NEURONS = 64
FANOUT = 8
EDGE_OFFSETS = (1, 2, 3, 5, 8, 13, 21, 34)
GATEWAYS = (0, 16, 32, 48)
INGRESS_NEURONS = (8, 24, 40, 56)
STATE_BYTES_EST = 32
EDGE_BYTES_EST = 16
EVENT_BYTES_EST = 24
BV_BYTES_EST = 48
BV_SLOTS = 128  # reserved capacity, NOT used in this forward-only phase
GATEWAY_THRESHOLD = 6
NORMAL_THRESHOLD = 5
INGRESS_THRESHOLD = 2  # require two received/local occurrences to fire
NODE_STATE_BITS = 16
LINK_PAYLOAD_BYTES = 24


def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_json(x):
    return hashlib.sha256(canonical(x).encode("utf-8")).hexdigest()


def git_blob_sha1(data):
    return hashlib.sha1((f"blob {len(data)}\0").encode() + data).hexdigest()


def source_check(root):
    root = Path(root)
    out = {}
    for rel, expected in SOURCE_PINS.items():
        p = root / rel
        actual = git_blob_sha1(p.read_bytes())
        if actual != expected:
            raise RuntimeError(f"SOURCE_PIN_MISMATCH {rel} {actual} != {expected}")
        out[rel] = actual
    return out


def load_pe(root):
    source_check(root)
    # Only the frozen two-file PE source tree is placed in sys.path.
    root = str(Path(root).resolve())
    if root not in sys.path:
        sys.path.insert(0, root)
    pe = importlib.import_module("spk_architecture_v1.pe_execution_v1b")
    return pe._compute_local


@dataclass(frozen=True)
class Node:
    node_id: str
    instructions: tuple
    state_bits: int = NODE_STATE_BITS
    fractional_bits: int = 0


def program(island, neuron):
    threshold = (GATEWAY_THRESHOLD if neuron in GATEWAYS else
                 INGRESS_THRESHOLD if neuron in INGRESS_NEURONS else NORMAL_THRESHOLD)
    # The exact A1b ISA fragment: ACC, CMP, EMIT, RESET with frac_bits=0.
    return Node(f"I{island}/N{neuron}",
                (("ACC", (1, 1)), ("CMP", threshold), ("EMIT", 7), ("RESET", 0)))


def graph():
    # 8-node ring + 4 opposite chords = 12 undirected, 24 directed links.
    undirected = {tuple(sorted((i, (i + 1) % ISLANDS))) for i in range(ISLANDS)}
    undirected |= {(i, i + ISLANDS // 2) for i in range(ISLANDS // 2)}
    assert len(undirected) == 12
    return sorted(undirected)


def neighbors():
    adj = {i: set() for i in range(ISLANDS)}
    for a, b in graph():
        adj[a].add(b)
        adj[b].add(a)
    return {i: tuple(sorted(v)) for i, v in adj.items()}


def shortest_path(a, b):
    assert 0 <= a < ISLANDS and 0 <= b < ISLANDS and a != b
    adj = neighbors()
    todo = collections.deque([(a,)])
    visited = {a}
    while todo:
        p = todo.popleft()
        if p[-1] == b:
            return p
        for nxt in adj[p[-1]]:
            if nxt not in visited:
                todo.append(p + (nxt,))
                visited.add(nxt)
    raise AssertionError("graph disconnected")


@dataclass(frozen=True)
class Config:
    horizon: int = 96
    seed: int = 211
    local_queue_cap: int = 256  # per island pending event occurrences
    tick_event_cap: int = 256  # processed event occurrences per island and tick
    link_queue_cap: int = 16  # pending mesh packets per directed logical link
    link_flight_cap: int = 8  # per directed logical link
    link_per_tick_cap: int = 2  # per directed link per logical tick
    link_delay: int = 2  # ticks per mesh hop
    local_delay: int = 1
    max_processed_events: int = 120000
    stimulus_last_tick: int = 24
    stimulus_every: int = 6

    def validate(self):
        for k, v in asdict(self).items():
            if k == "seed":
                if type(v) is not int or v < 0:
                    raise ValueError("invalid seed")
            elif type(v) is not int or v <= 0:
                raise ValueError(f"invalid bounded config: {k}")
        if self.stimulus_last_tick >= self.horizon:
            raise ValueError("stimulus_last_tick must precede horizon")


@dataclass(frozen=True)
class Pulse:
    eid: int
    tick: int
    source: str
    hop_count: int


@dataclass
class Packet:
    pid: int
    source_island: int
    source_neuron: int
    target_island: int
    route: tuple[int, ...]
    hop_at: int
    born_tick: int
    parent_emission: int


class Island:
    def __init__(self, index, cfg):
        self.index = index
        self.nodes = tuple(program(index, i) for i in range(NEURONS))
        self.states = [[0, 0] for _ in range(NEURONS)]
        self.pending = {}  # tick -> neuron -> list[Pulse]
        self.queued = 0
        self.queue_peak = 0
        self.processed = 0
        self.emitted = 0
        self.dropped_capacity = 0
        self.dropped_tick_budget = 0
        self.dropped_horizon = 0
        self.batch_count = 0
        self.cfg = cfg

    def enqueue(self, tick, neuron, pulse):
        if tick >= self.cfg.horizon:
            self.dropped_horizon += 1
            return False
        if self.queued >= self.cfg.local_queue_cap:
            self.dropped_capacity += 1
            return False
        self.pending.setdefault(tick, {}).setdefault(neuron, []).append(pulse)
        self.queued += 1
        self.queue_peak = max(self.queue_peak, self.queued)
        assert self.queue_peak <= self.cfg.local_queue_cap
        return True


class Simulation:
    def __init__(self, compute, cfg, mesh_enabled):
        cfg.validate()
        self.compute = compute
        self.cfg = cfg
        self.mesh_enabled = mesh_enabled
        self.islands = [Island(i, cfg) for i in range(ISLANDS)]
        self.links = {(a, b): collections.deque()
                      for i, j in graph() for a, b in ((i, j), (j, i))}
        self.inflight = {}  # arrival_tick -> list[(packet, directed_link)]
        self.flight_count = {k: 0 for k in self.links}
        self.link_peak = {k: 0 for k in self.links}
        self.link_flight_peak = {k: 0 for k in self.links}
        self.serial = 0
        self.packet_serial = 0
        self.trace = hashlib.sha256()
        self.first_events = []
        self.stats = collections.Counter()
        self.hop_hist = collections.Counter()
        
    def log(self, row):
        b = (canonical(row) + "\n").encode("utf-8")
        self.trace.update(b)
        if len(self.first_events) < 40:
            self.first_events.append(row)

    def next_id(self):
        self.serial += 1
        return self.serial

    def inject(self):
        # Fixed input events, identical under mesh ON/OFF, deterministic with seed.
        for tick in range(1, self.cfg.stimulus_last_tick + 1, self.cfg.stimulus_every):
            for island in range(ISLANDS):
                gateway = GATEWAYS[((tick // self.cfg.stimulus_every) + island + self.cfg.seed) % len(GATEWAYS)]
                # Six real spike occurrences at the same (tick, neuron),
                # sufficient to fire gateway CMP(6) exactly once.
                for _ in range(GATEWAY_THRESHOLD):
                    e = Pulse(self.next_id(), tick, "SENSOR", 0)
                    self.stats["external_created"] += 1
                    if self.islands[island].enqueue(tick, gateway, e):
                        self.stats["external_admitted"] += 1
                    else:
                        self.stats["external_rejected"] += 1
                # Three non-gateway observations exercise state integration.
                target = (gateway + 7) % NEURONS
                for _ in range(3):
                    e = Pulse(self.next_id(), tick, "SENSOR", 0)
                    self.stats["external_created"] += 1
                    if self.islands[island].enqueue(tick, target, e):
                        self.stats["external_admitted"] += 1
                    else:
                        self.stats["external_rejected"] += 1

    def create_packet(self, t, island, neuron, emission_id):
        self.packet_serial += 1
        # Every gateway exports to one nonlocal destination; several choices
        # require two mesh hops so routing is genuinely tested.
        dst = (island + 2 + (neuron // 16)) % ISLANDS
        path = shortest_path(island, dst)
        pkt = Packet(self.packet_serial, island, neuron, dst, path, 0, t, emission_id)
        self.stats["packets_created"] += 1
        self.log(["mesh_create", t, pkt.pid, island, neuron, dst, emission_id, list(path)])
        self.enqueue_packet(pkt, t)

    def enqueue_packet(self, pkt, tick):
        assert pkt.hop_at + 1 < len(pkt.route)
        link = (pkt.route[pkt.hop_at], pkt.route[pkt.hop_at + 1])
        q = self.links[link]
        if len(q) >= self.cfg.link_queue_cap:
            self.stats["packets_dropped_link_queue"] += 1
            self.log(["link_drop", tick, pkt.pid, link[0], link[1], "LINK_QUEUE_FULL"])
            return False
        q.append(pkt)
        self.link_peak[link] = max(self.link_peak[link], len(q))
        return True

    def deliver_mesh(self, tick):
        arrivals = self.inflight.pop(tick, [])
        for pkt, link in arrivals:
            assert self.flight_count[link] > 0
            self.flight_count[link] -= 1
            assert pkt.route[pkt.hop_at] == link[0]
            assert pkt.route[pkt.hop_at + 1] == link[1]
            pkt.hop_at += 1
            self.hop_hist[pkt.hop_at] += 1
            self.stats["hop_arrivals"] += 1
            self.log(["hop_arrive", tick, pkt.pid, link[0], link[1], pkt.hop_at])
            if pkt.hop_at == len(pkt.route) - 1:
                assert pkt.route[-1] == pkt.target_island
                # An arriving spike is not a native BV credit or authorization.
                target_neuron = (pkt.source_neuron + 8) % NEURONS
                pulse = Pulse(self.next_id(), tick, f"MESH/{pkt.pid}", pkt.hop_at)
                accepted = self.islands[pkt.target_island].enqueue(tick, target_neuron, pulse)
                self.stats["packets_delivered_target"] += 1
                self.stats["mesh_neuron_admitted" if accepted else "mesh_neuron_rejected"] += 1
                self.log(["mesh_target", tick, pkt.pid, pkt.target_island, target_neuron, int(accepted)])
            else:
                self.enqueue_packet(pkt, tick)

    def process_local(self, tick):
        for island in self.islands:
            rows = island.pending.pop(tick, {})
            island.queued -= sum(len(v) for v in rows.values())
            assert island.queued >= 0
            used = 0
            for neuron in sorted(rows):
                pulses = rows[neuron]
                if used + len(pulses) > self.cfg.tick_event_cap:
                    island.dropped_tick_budget += len(pulses)
                    self.stats["local_tick_budget_drop"] += len(pulses)
                    self.log(["tick_drop", tick, island.index, neuron, len(pulses)])
                    continue
                used += len(pulses)
                island.processed += len(pulses)
                self.stats["events_processed"] += len(pulses)
                if self.stats["events_processed"] > self.cfg.max_processed_events:
                    raise RuntimeError("GLOBAL_EVENT_LIMIT_REACHED")
                old = island.states[neuron]
                # Real original A1b local ISA implementation, unchanged source.
                raw, guard, emissions = self.compute(island.nodes[neuron], old, tick, (1,) * len(pulses))
                island.states[neuron] = [raw, tick]
                island.batch_count += 1
                self.stats["batches_processed"] += 1
                self.log(["batch", tick, island.index, neuron, len(pulses), raw, int(guard), len(emissions)])
                for out in emissions:
                    assert out == 7
                    island.emitted += 1
                    self.stats["emissions"] += 1
                    emid = self.next_id()
                    self.log(["emit", tick, island.index, neuron, emid])
                    for offset in EDGE_OFFSETS:
                        target = (neuron + offset) % NEURONS
                        nxt = tick + self.cfg.local_delay
                        e = Pulse(self.next_id(), nxt, f"I{island.index}/N{neuron}#{emid}", 0)
                        self.stats["local_edge_events_created"] += 1
                        if island.enqueue(nxt, target, e):
                            self.stats["local_edge_events_admitted"] += 1
                        else:
                            self.stats["local_edge_events_rejected"] += 1
                    if self.mesh_enabled and neuron in GATEWAYS:
                        self.create_packet(tick, island.index, neuron, emid)

    def transmit_mesh(self, tick):
        # Strict deterministic FIFO arbitration per directed link.
        for link in sorted(self.links):
            q = self.links[link]
            count = 0
            while (q and count < self.cfg.link_per_tick_cap
                   and self.flight_count[link] < self.cfg.link_flight_cap):
                pkt = q.popleft()
                count += 1
                self.flight_count[link] += 1
                assert self.flight_count[link] <= self.cfg.link_flight_cap
                self.link_flight_peak[link] = max(self.link_flight_peak[link], self.flight_count[link])
                arrival = tick + self.cfg.link_delay
                self.inflight.setdefault(arrival, []).append((pkt, link))
                self.stats["link_transmissions"] += 1
                self.stats["mesh_payload_bytes"] += LINK_PAYLOAD_BYTES
                self.log(["tx", tick, pkt.pid, link[0], link[1], arrival])

    def run(self):
        self.inject()
        for t in range(self.cfg.horizon):
            # Arrivals, local computation, and link sends occur in that order.
            # Every local edge adds >=1 tick; mesh hop adds >=2 ticks.
            self.deliver_mesh(t)
            self.process_local(t)
            self.transmit_mesh(t)
        queued_packets = sum(map(len, self.links.values()))
        in_flight_packets = sum(map(len, self.inflight.values()))
        assert self.stats["packets_created"] == (
            self.stats["packets_delivered_target"]
            + self.stats["packets_dropped_link_queue"]
            + queued_packets + in_flight_packets)
        assert self.stats["link_transmissions"] == (
            self.stats["hop_arrivals"] + in_flight_packets)
        assert self.stats["external_created"] == self.stats["external_admitted"] + self.stats["external_rejected"]
        assert self.stats["local_edge_events_created"] == (
            self.stats["local_edge_events_admitted"] + self.stats["local_edge_events_rejected"])
        state = [{"island": i.index, "neuron_raw": [s[0] for s in i.states],
                  "neuron_last": [s[1] for s in i.states]}
                 for i in self.islands]
        self.stats["pending_local_events_at_horizon"] = sum(i.queued for i in self.islands)
        self.stats["pending_link_packets_at_horizon"] = queued_packets
        self.stats["inflight_packets_at_horizon"] = in_flight_packets
        return {
            "schema": SCHEMA,
            "mesh_enabled": self.mesh_enabled,
            "config": asdict(self.cfg),
            "topology": {"undirected_edges": graph(), "directed_links": len(self.links),
                         "local_edges": ISLANDS * NEURONS * FANOUT},
            "resources": {
                "islands": ISLANDS, "neurons_per_island": NEURONS, "total_neurons": ISLANDS * NEURONS,
                "local_fanout": FANOUT, "edges_per_island": NEURONS * FANOUT,
                "local_queue_cap": self.cfg.local_queue_cap,
                "bv_reserved_slots_no_writes": BV_SLOTS,
                "spk_sram_model_bytes_per_island": (
                    NEURONS * STATE_BYTES_EST + NEURONS * FANOUT * EDGE_BYTES_EST
                    + self.cfg.local_queue_cap * EVENT_BYTES_EST + BV_SLOTS * BV_BYTES_EST
                    + 32 * 1024),
                "sram_model_note": "UNMEASURED upper-end illustrative layout, not ESP-IDF heap",
            },
            "per_island": [
                {"island": i.index, "processed": i.processed, "batches": i.batch_count,
                 "emissions": i.emitted, "queue_peak": i.queue_peak,
                 "queue_at_horizon": i.queued, "dropped_queue": i.dropped_capacity,
                 "dropped_tick_budget": i.dropped_tick_budget,
                 "dropped_horizon": i.dropped_horizon}
                for i in self.islands
            ],
            "stats": dict(sorted(self.stats.items())),
            "max_link_queue": max(self.link_peak.values(), default=0),
            "max_link_inflight": max(self.link_flight_peak.values(), default=0),
            "mesh_hops_histogram": dict(sorted(self.hop_hist.items())),
            "final_state_sha256": sha256_json(state),
            "trace_sha256": self.trace.hexdigest(),
            "trace_sample": self.first_events,
            "owner_writes": 0,
            "bv_writes": 0,
            "learning_updates": 0,
            "holdout_accesses": 0,
            "scope": "ENGINEERING_RESEARCH_REFERENCE_NEW_SCHEDULER_USING_PINNED_PE_LOCAL_ISA",
        }


def compare(compute, cfg):
    off = Simulation(compute, cfg, mesh_enabled=False).run()
    on = Simulation(compute, cfg, mesh_enabled=True).run()
    assert off["stats"]["external_created"] == on["stats"]["external_created"]
    assert off["stats"]["external_admitted"] == on["stats"]["external_admitted"]
    assert off["stats"].get("packets_created", 0) == 0
    assert on["stats"]["packets_created"] > 0
    assert on["stats"]["packets_delivered_target"] > 0
    assert on["stats"]["hop_arrivals"] > on["stats"]["packets_delivered_target"]
    assert on["stats"]["emissions"] > off["stats"]["emissions"]
    return {"schema": SCHEMA + "/comparison", "mesh_off": off, "mesh_on": on,
            "same_input_admission": True,
            "island_state_changed_by_mesh": off["final_state_sha256"] != on["final_state_sha256"],
            "no_bv_or_learning": True,
            "verdict": "MESH_8X64_PHASE01_BOUNDED_REFERENCE_PRODUCED"}


def selftest(compute):
    assert len(graph()) == 12
    assert set(map(len, neighbors().values())) == {3}
    assert sum(len(neighbors()[i]) for i in range(ISLANDS)) == 24
    assert len(EDGE_OFFSETS) == FANOUT and len(set(EDGE_OFFSETS)) == FANOUT
    assert shortest_path(0, 2) == (0, 1, 2)
    assert shortest_path(0, 4) == (0, 4)
    node = program(0, 0)
    # Exact local PE semantics: below CMP6 no output; at CMP6 emit7 reset0.
    raw, guard, out = compute(node, [0, 0], 1, (1,) * 5)
    assert (raw, guard, out) == (5, False, ())
    raw, guard, out = compute(node, [5, 1], 2, (1,))
    assert (raw, guard, out) == (0, True, (7,))
    smoke = Config(horizon=28, stimulus_last_tick=12, stimulus_every=6)
    a = compare(compute, smoke)
    b = compare(compute, smoke)
    assert canonical(a) == canonical(b)
    assert a["island_state_changed_by_mesh"]
    # Overcapacity should be reported, never bypassed.
    bounded = Config(horizon=28, stimulus_last_tick=12, local_queue_cap=5,
                     link_queue_cap=1, link_flight_cap=1, link_per_tick_cap=1)
    u = Simulation(compute, bounded, mesh_enabled=True).run()
    assert u["stats"]["external_rejected"] > 0
    assert all(i["queue_peak"] <= 5 for i in u["per_island"])
    assert u["max_link_queue"] <= 1 and u["max_link_inflight"] <= 1
    return {"selftest": "PASS", "scope": "pinned_PE_local_semantics_and_bounded_mesh_invariants",
            "smoke_mesh_packets": a["mesh_on"]["stats"]["packets_delivered_target"]}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source-root", required=True, help="temp directory containing frozen original PE + fabric")
    p.add_argument("--profile", choices=("selftest", "smoke", "full"), default="smoke")
    p.add_argument("--out", type=Path, default=None)
    args = p.parse_args(argv)
    compute = load_pe(args.source_root)
    if args.profile == "selftest":
        print("SELFTEST_RESULT", canonical(selftest(compute)))
        return 0
    cfg = Config(horizon=40, stimulus_last_tick=18) if args.profile == "smoke" else Config()
    report = compare(compute, cfg)
    report["profile"] = args.profile
    report["source_main_commit"] = MAIN_COMMIT
    report["verified_source_blobs"] = source_check(args.source_root)
    report["canonical_sha256"] = sha256_json({k:v for k,v in report.items() if k != "canonical_sha256"})
    # A second isolated replay tests bit-for-bit determinism before recording.
    second = compare(compute, cfg)
    assert report["mesh_off"]["trace_sha256"] == second["mesh_off"]["trace_sha256"]
    assert report["mesh_on"]["trace_sha256"] == second["mesh_on"]["trace_sha256"]
    assert report["mesh_off"]["final_state_sha256"] == second["mesh_off"]["final_state_sha256"]
    assert report["mesh_on"]["final_state_sha256"] == second["mesh_on"]["final_state_sha256"]
    if args.out:
        if args.out.exists():
            raise RuntimeError("OUTPUT_EXISTS_NONOVERWRITE " + str(args.out))
        args.out.mkdir(parents=True)
        (args.out / "report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
        (args.out / "protocol.json").write_text(json.dumps({
            "schema": SCHEMA + "/manual", "profile": args.profile,
            "experiment": "islands OFF vs mesh ON with identical exogenous streams",
            "scope": "bounded forward-only original-PE-local-ISA research; no BV, no learning, no ESP32 firmware",
            "source_pins": SOURCE_PINS, "main_commit": MAIN_COMMIT,
            "topology": graph(), "local_edges_per_island": NEURONS * FANOUT,
            "config": asdict(cfg), "nonoverwrite": True}, indent=2, sort_keys=True) + "\n")
        digest_lines = [f"{hashlib.sha256((args.out / nm).read_bytes()).hexdigest()}  {nm}"
                        for nm in ("protocol.json", "report.json")]
        (args.out / "SHA256SUMS").write_text("\n".join(digest_lines) + "\n")
    off = report["mesh_off"]["stats"]
    on = report["mesh_on"]["stats"]
    print("RUN_COMPLETE__ENGINEERING_RESEARCH_ONLY")
    print("CONFIG", canonical({"islands": ISLANDS, "neurons_per_island": NEURONS,
                               "local_edges": ISLANDS * NEURONS * FANOUT,
                               "links_undirected": len(graph()), "horizon": cfg.horizon}))
    print("ISOLATED", canonical({k:off.get(k,0) for k in ("events_processed","emissions","packets_created","link_transmissions")}))
    print("MESH", canonical({k:on.get(k,0) for k in ("events_processed","emissions","packets_created","packets_delivered_target","link_transmissions","hop_arrivals","mesh_payload_bytes","packets_dropped_link_queue")}))
    print("STATE_DIFFERENCE", report["island_state_changed_by_mesh"])
    print("DETERMINISTIC_REPLAY", "PASS")
    print("REPORT_SHA256", report["canonical_sha256"])
    if args.out:
        print("OUTPUT", args.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
