#!/usr/bin/env bash
# SPK-MESH-8x64: user-triggered manual fwork run; NO M/W/V, no git writes.
set -Eeuo pipefail
export LC_ALL=C

PROFILE="${1:-smoke}"
REPO="${2:-${SPK_REPO:-$HOME/workspace/spk-backvalidation-v0}}"
case "$PROFILE" in smoke|full) ;; *) echo "USO: bash $0 [smoke|full] [repo_git_locale]" >&2; exit 2;; esac
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
( cd "$SCRIPT_DIR" && sha256sum --check CODE_SHA256SUMS ) || {
  echo "PACKAGE_HASH_MISMATCH" >&2
  exit 4
}
[[ -d "$REPO/.git" || -f "$REPO/.git" ]] || {
  echo "ERRORE: repository Git non trovato: $REPO" >&2
  echo "Passa il percorso del repo come secondo argomento." >&2
  exit 3
}
for COMMAND in git tar sha256sum python3; do
  command -v "$COMMAND" >/dev/null || { echo "COMANDO_MANCANTE: $COMMAND" >&2; exit 3; }
done
MAIN="787c8fbed87c1e2e4b703e985f68ae53c81c8444"
# If the historical commit is not locally present, fetch only Git objects.
# Does not checkout/reset/merge/commit/push; leaves active working tree intact.
if ! git -C "$REPO" cat-file -e "${MAIN}^{commit}" 2>/dev/null; then
  echo "Pin $MAIN assente, recupero Git oggetti da origin (solo lettura del remote)..."
  git -C "$REPO" fetch --no-tags origin "$MAIN"
fi
[[ "$(git -C "$REPO" rev-parse "${MAIN}^{commit}")" == "$MAIN" ]] || {
  echo "MAIN_SOURCE_PIN_MISMATCH" >&2
  exit 4
}

TMP="$(mktemp -d -t spk-mesh8x64-XXXXXXXX)"
trap 'rm -rf -- "$TMP"' EXIT
mkdir -p "$TMP/source"
git -C "$REPO" archive --format=tar "$MAIN" \
    spk_architecture_v1/pe_execution_v1b.py \
    spk_architecture_v1/pe_fabric_v1a.py | tar -xf - -C "$TMP/source"

echo "Verifico semantica ISA PE ORIGINALE pinnato + integrita' sorgenti..."
python3 "$SCRIPT_DIR/spk_mesh8x64_ref_v0.py" --source-root "$TMP/source" --profile selftest

echo "Verifico gli 8 unit test standalone sul trasporto e le code..."
( cd "$SCRIPT_DIR" && python3 -m unittest -v test_spk_mesh8x64_ref_v0 )

OUTPUT_BASE="${SPK_MESH_OUTPUT_BASE:-$HOME/workspace/spk-manual-runs}"
mkdir -p "$OUTPUT_BASE"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$OUTPUT_BASE/${STAMP}-mesh8x64-${PROFILE}"
[[ ! -e "$OUT" && ! -e "$OUT.tar.gz" ]] || {
  echo "OUTPUT_ESISTENTE: $OUT; NON sovrascrivo" >&2
  exit 5
}

echo "SPK-MESH-8x64 FWORK MANUAL, profile=$PROFILE, PE=$MAIN"
echo "No BV, no learning, no P writes, no holdout, no GitHub writes."
python3 "$SCRIPT_DIR/spk_mesh8x64_ref_v0.py" \
  --source-root "$TMP/source" --profile "$PROFILE" --out "$OUT" | tee "$TMP/console.log"
cp "$TMP/console.log" "$OUT/console.log"
(
  cd "$OUT"
  sha256sum console.log >> SHA256SUMS
  sha256sum --check SHA256SUMS
)
ARCHIVE="${OUT}.tar.gz"
tar -czf "$ARCHIVE" -C "$OUTPUT_BASE" "$(basename "$OUT")"
sha256sum "$ARCHIVE" > "${ARCHIVE}.sha256"
printf '\nPACCHETTO_EVIDENZE: %s\n' "$ARCHIVE"
printf 'SHA256_PACCHETTO: '
sha256sum "$ARCHIVE" | awk '{print $1}'
echo "Carica in chat il file .tar.gz e il suo .sha256 per l'audit indipendente CIAT."
