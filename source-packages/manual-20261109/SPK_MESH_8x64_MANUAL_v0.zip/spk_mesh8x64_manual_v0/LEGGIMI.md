# SPK-MESH-8x64, ricerca engineering reference v0

**Contesto:** GitHub issue #211, SPK/*, novembre 2026. Primo simulatore di otto isole autonome da 64 neuroni (512 in totale), su Fedora fwork. Solo Phase 0/1: trasporto forward, nessun apprendimento e nessuna scrittura BV→P. ESP32-C6 è un obiettivo di porting, **non** hardware già verificato.

## Esecuzione manuale

Estrarre `SPK_MESH_8x64_MANUAL_v0.zip` in `~/Scaricati` e lanciare:

```bash
cd ~/Scaricati
unzip SPK_MESH_8x64_MANUAL_v0.zip
cd spk_mesh8x64_manual_v0
bash run_spk_mesh8x64_manual.sh smoke
```

Se smoke passa, eseguire:

```bash
bash run_spk_mesh8x64_manual.sh full
```

**Dipendenze:** Python 3.9+, Git e GNU tar/sha256sum. Nessun venv, NumPy, ESP-IDF, Wi-Fi o 8 ESP32 fisici necessari. Per il repo Git viene usato `~/workspace/spk-backvalidation-v0` oppure un secondo argomento al lanciatore. I file originali sono letti come Git objects dal commit fisso `787c8fbed87c1e2e4b703e985f68ae53c81c8444` e materializzati **solo** sotto una directory temporanea. Hash Git blob dei due sorgenti PE verificati prima di eseguire. Se mancano gli oggetti Git, il lanciatore esegue solo `git fetch` di quel commit; non modifica il checkout o i file di lavoro. Non è richiesto né utilizzato il codice della PR #209.

**Restituire a CIAT** i due file prodotti:

- `~/workspace/spk-manual-runs/<UTC>-mesh8x64-smoke.tar.gz`
- `~/workspace/spk-manual-runs/<UTC>-mesh8x64-smoke.tar.gz.sha256`

Analogamente per il profilo `full`. Nessuna pubblicazione automatica su GitHub. Ciascun output è in un percorso versione/UTC nuovo, non sovrascritto. CIAT potrà verificare i file e registrare risultati e SHA su GitHub.

## Definizione del test

- Otto isole `I0..I7`, 64 neuroni per isola, 8 edge locali per neurone = 512 edge/isola, 4.096 totali.
- Topologia logica **anello a 8 isole + 4 corde opposte**, 12 link bidirezionali, 24 direzioni. Percorsi minimi BFS e tie-break lessicografico riproducibile; almeno alcuni eventi richiedono due hop.
- Ogni isola mantiene 64 stati indipendenti e una coda eventi limitata a 256 occorrenze, massimo 256 eventi trattati per isola e tick; ogni link diretto ha 16 pacchetti in attesa, 8 in volo, 2 trasmissioni/tick, latenza 2 tick/hop. I collegamenti locali ritardano ogni spike di 1 tick. I budget sono modelli logici, non frequenze misurate su una radio reale.
- **Computazione neuronale non reinventata:** le chiamate locali `_compute_local()` sono eseguite sul modulo originale e pinnato `pe_execution_v1b.py`. Programma per neurone `ACC(1,1) → CMP(θ) → EMIT(7) → RESET(0)` con `fractional_bits=0`, `state_bits=16` e θ=6 per neuroni gateway, θ=2 per gli ingressi da mesh, θ=5 per gli altri. Nessun aggiornamento θ. **Il nuovo scheduler multiplo non è il motore originale 3-PE**, pertanto non è una prova di equivalenza complessiva del PE.
- Ingressi esogeni deterministici e identici, per entrambe le condizioni: mesh OFF (otto isole isolate) e mesh ON (24 link direzionali disponibili). Sorgente e numero di neuroni/edge/budget invariati; quando il gateway emette un segnale, mesh ON costruisce un messaggio per una destinazione non adiacente per almeno parte del traffico. Nessun sensore della futura finestra target, nessun payload di truth.
- Simulazione globale a clock logico unico, ordine di tick: arrivi mesh, processi locali, trasmissioni link. Mantenimento causale: ogni edge locale aggiunge 1 tick, ogni hop 2 tick, ogni percorso è conservato nel pacchetto. Eventi oltre orizzonte e code piene **non spariscono**: sono contati esplicitamente. I pacchetti ricevuti possono attivare i neuroni d'ingresso e diffondersi internamente, ma nessuna BV viene elaborata.
- Il modello di SRAM, **non misurato**, usa 32 B/neuron, 16 B/edge, 24 B/coda, 48 B/record BV riservato e 32 KiB di altri buffer. Non misura FreeRTOS/Thread/heap, prestazioni C6 o consumi energetici.

## Verifiche e limiti

L'autotest usa davvero la `_compute_local` pinnata su un campione e verifica la mesh. Gli otto test `unittest` usano una **piccola implementazione-oracolo indipendente** solo per il trasporto; non sono considerati test di equivalenza totale con il PE originale. L'esecuzione `smoke`/`full` chiama invece la semantica locale reale. Il test viene ripetuto internamente e deve produrre digest byte-identici per stato finale e traccia.

Output: `protocol.json`, `report.json`, `console.log`, `SHA256SUMS` con SHA256, archivio TAR e relativo SHA. Il report contiene ingressi uguali, conteggio eventi per isola, emissioni, messaggi creati/inviati/consegnati, numeri di hop, byte payload, massimi delle code, pacchetti pending al termine, SHA256 di stato e traccia. **Non** inferire apprendimento, predizione o comportamento emergente da questi conteggi: in questa fase testiamo soltanto computazione locale, trasporto causale e vincoli finite-resource.

**HOLD permanenti:** P_writes=0, science GO0/3, nessun E2/holdout, nessun merge e nessun aggiramento dei confini umani C0–C5, G2, dispatch e BV→P. Non riattivare M/W/V.
