# SPK/* MESH9 Ethernet Gateway Manual v1

## Ipotesi e stato

NOVE isole computazionali: I0..I7, 64 neuroni/isola classe ESP32-C6; I8, 1024 neuroni classe Raspberry Pi 5. **G9 e` solo il gateway Ethernet ↔ Thread, con zero neuroni SPK**. I8 non possiede alcuna radio 802.15.4. Il Raspberry Pi 5 ha Ethernet Gigabit integrata; un gateway esterno come un coordinatore Ethernet/PoE configurato in modalita` Thread Border Router fornisce accesso radio alla mesh. In particolare SMLIGHT SLZB-06P7U e` un esempio documentato dal produttore per Thread **oppure** Zigbee (singola radio): configurarlo per Thread lo sottrae a un'eventuale rete Zigbee esistente.

Questo e` un **riferimento deterministico di trasporto e calcolo**, non una emulazione completa di OTBR/IP/UDP/Thread, non un benchmark radio o ESP32-C6 reale. Nessun peer review scientifico, nessun apprendimento, BV o P-write.

## Topologia e canali

- Restano i 12 link radio bidirezionali della mesh C6 originaria (anello + quattro corde).
- Il gateway G9 e` raggiungibile via radio da I0 e I4: 2 link radio aggiuntivi.
- Il Pi I8 ha un **solo link Ethernet** bidirezionale verso G9.
- Totale **15 link fisici** non direzionali: 14 radio + 1 Ethernet. La connettivita` applicativa tra le 9 isole rimane completa con routing multi-hop, **senza creare un'isola G9**.
- Ogni trasmissione di G9 sulla radio condivide un budget totale di **2 pacchetti/tick** per tutti i link e direzioni del gateway. E` un proxy di contesa, non il MAC IEEE 802.15.4 reale.
- Link radio: 2 tick di ritardo, coda max16, 2 trasmissioni/tick per direzione, in-flight 8.
- Ethernet: 1 tick di ritardo, coda max128, 32 trasmissioni/tick per direzione, in-flight32. Sono numeri logici arbitrari, NON una stima di banda fisica a unita` temporali reali.
- Payload evento logico 24 byte, contabilizzato per singolo hop. Nessun header IPv6/6LoWPAN/UDP, overhead o MTU effettivi simulati; non inferire dati di throughput reali.

## Compatibilita` e sicurezza dei sorgenti

Lancio manuale Fedora. Python 3.10+ standard library, git, tar e sha256sum. Venv NON richiesto.
Il launcher verifica `CODE_SHA256SUMS` e poi estrae tramite `git archive` i soli due file originali dal commit Git congelato `787c8fbed87c1e2e4b703e985f68ae53c81c8444`, controlla blob Git esatti:

- `spk_architecture_v1/pe_execution_v1b.py` `2e16bdeddc7fc5eacbd341a6dbdf245d71095678`
- `spk_architecture_v1/pe_fabric_v1a.py` `b0cf8b01a8e5ede6ad640349e11b91194c454763`

Usa `_compute_local()` autentico per i batch di neuroni: il nuovo scheduler/rete/gateway NON e` il vecchio PE globale. Si esegue un self-test con un oracolo di algebra neuronale scritto separatamente e 28 test (9 nuovi, 11 precedenti e 8 regressioni base). Vengono controllati replay deterministico e conservazione pacchetti. Non cambia checkout, non scrive GitHub, non apre holdout.

## Esecuzione

```bash
cd ~/Scaricati
unzip SPK_MESH9_ETHERNET_GATEWAY_MANUAL_v1.zip
cd spk_mesh9_ethgateway_manual_v1
bash run_spk_mesh9_ethgateway_manual.sh smoke
bash run_spk_mesh9_ethgateway_manual.sh full
```

Opzionale secondo argomento percorso del repository, default `~/workspace/spk-backvalidation-v0`.

Gli output append-only sono in `~/workspace/spk-manual-runs/<UTC>-mesh9ethernet-{smoke|full}/`, con `report.json`, `protocol.json`, `console.log`, `SHA256SUMS`, archivio `.tar.gz` e sua `.tar.gz.sha256`. Caricare **entrambe** le copie archive smoke e full, se disponibili.

## Criteri di interpretazione

Confronto a identici ingressi esterni: mesh OFF contro ON. Nessun BV, apprendimento, P writes, autenticazione dell'owner, hardware o timing radio reale. La differenza di stato tra Pi e isole e` prova solo del funzionamento di una rete event-driven deterministica. I 1024 neuroni Pi sono **allocati**, non tutti attivi; nessuna misura di capacita` predittiva. Nessuna modifica agli HOLD umani C0-C5, G2, dispatch, BV->P.

## Fonti di rete

- Raspberry Pi 5: https://www.raspberrypi.com/products/raspberry-pi-5/
- OpenThread Border Router: https://openthread.io/guides/border-router
- SMLIGHT SLZB-06P7U: https://smlight.tech/products/slzb-06p7u
