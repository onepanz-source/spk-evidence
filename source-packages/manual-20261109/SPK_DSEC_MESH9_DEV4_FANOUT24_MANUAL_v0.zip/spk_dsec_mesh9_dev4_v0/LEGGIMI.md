# SPK DSEC MESH9 DEV4 — fan-out 2 contro fan-out 4, mesh OFF/ON

Questo pacchetto sostituisce soltanto l'esperimento di carico, non le versioni precedenti. NON modifica il PE originale, nessun target optical-flow GT o sequenza validation/blind viene letto. L'utente esegue manualmente su Fedora fwork.

## Ipotesi e limite epistemico

Il precedente test DEV pair0 (#215) ha mostrato che il fan-out locale 4 elimina la saturazione presente al fan-out 8. **Quattro è stato scelto dopo aver visto pair0**: tutti i risultati di questo esperimento sono sviluppo esplorativo, non validazione indipendente. La capacità di previsione del flusso ottico e l'apprendimento non sono testati. Il fan-out 2 è un controllo meno connesso, non un candidato scelto tramite ground truth.

## Protocollo immutabile

Usare **esattamente** i primi quattro intervalli forward ufficiali della sequenza DEV `thun_00_a`, da `/home/ste/Scaricati/train_events.zip` e `train_optical_flow.zip`. Solo `events/left/events.h5`, `events/left/rectify_map.h5` e `flow/forward_timestamps.txt` per la scena DEV, verificati contro gli SHA D0. VALIDATION `zurich_city_01_a` e BLIND `zurich_city_02_a`: solo inventario central-directory dei ZIP, mai apertura del contenuto. ZERO PNG/GT optical flow.

Mantenere: 9 isole (8x64 C6-class +1024 Pi-class), 1536 neuroni; bridge Ethernet/Thread non computazionale; 20 intervalli temporali/finestra, topK 8 (C6) e 32 (Pi), bande 1/40/160, stessa ISA originale ACC/CMP/EMIT/RESET. Il fan-out è **abilitazione dei primi 2 o 4** dei medesimi 8 collegamenti statici. Input tick-causale già corretto; stati neurali RESET a ogni nuova finestra (non rappresenta streaming continuo). 64 tick logici per finestra, nessuna pretesa di equivalenza con millisecondi hardware.

Per ogni coppia DSEC: fan-out 2 OFF/ON e fan-out 4 OFF/ON =16 arms. Lo stesso input tra arms; compare numero eventi elaborati, attivazione, code, perdita e trasporto. Replay separato mesh-ON per riproducibilità. Il pair0 **DEVE** riprodurre i quattro digest di stato+traccia del test già auditato #215, altrimenti si ferma.

## Fedora fwork

Scarica lo ZIP in `~/Scaricati`, poi:

```bash
cd ~/Scaricati
unzip SPK_DSEC_MESH9_DEV4_FANOUT24_MANUAL_v0.zip
cd spk_dsec_mesh9_dev4_v0
source ~/Scaricati/spk_dsec_mesh9_dev_v0/.venv/bin/activate
bash run_spk_dsec_mesh9_dev4_manual.sh
```

Se il repository non è nel percorso standard: `bash run_spk_dsec_mesh9_dev4_manual.sh /percorso/repository`.

L'output append-only finisce in `~/workspace/spk-manual-runs/<UTC>-dsec-mesh9-dev4-fanout24/` e nei corrispondenti `.tar.gz` e `.tar.gz.sha256`. Carica l'archivio qui, per verificare tutte le 16 arms. Non avviare nuove finestre o ground truth fino a completamento audit CIAT.
