#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

printf '%s\n' 'SPK DSEC MESH9 STAGE B DEV ONLY: SHA LOCK BEFORE GT PIXELS'
printf '%s\n' 'NO VAL/BLIND; NO BV/LEARNING/P WRITES; NO E2; NO POST-GT TUNING'
sha256sum -c CODE_SHA256SUMS
python -m unittest -v test_spk_dsec_mesh9_flow_stageb_v0.py
python -c 'import numpy,png; print("NUMPY_PYPNG_OK",numpy.__version__)'

STAGEA="${1:-$HOME/workspace/spk-manual-runs/20261109T223220Z-dsec-mesh9-readout-stagea.tar.gz}"
FLOWZIP="${2:-$HOME/Scaricati/train_optical_flow.zip}"
ROOT="${SPK_MANUAL_RUNS_ROOT:-$HOME/workspace/spk-manual-runs}"
mkdir -p -- "$ROOT"
UTC="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$ROOT/$UTC-dsec-mesh9-stageb-dev-gt-v0"
mkdir -- "$OUT"

# Every invocation validates exact Stage A TAR and all locked maps before ANY PNG read.
# The scorer writes only aggregate metrics, never source GT pixels or target arrays.
(
  python spk_dsec_mesh9_flow_stageb_v0.py --stagea "$STAGEA" --flow-zip "$FLOWZIP" --out "$OUT/report.json"
  python spk_dsec_mesh9_flow_stageb_v0.py --stagea "$STAGEA" --flow-zip "$FLOWZIP" --out "$OUT/report.json" --verify
) 2>&1 | tee "$OUT/console.log"

python - "$OUT" <<'PY'
from pathlib import Path
import json,sys
out=Path(sys.argv[1]);r=json.loads((out/'report.json').read_text())
p={
 'schema':'spk-dsec-mesh9-stageb-manual-protocol/v0',
 'scope':'thun_00_a_DEV_4_gt_png_only',
 'stagea_archive_sha256':r['source']['stagea_archive_sha256'],
 'stagea_lock_commit':r['source']['stagea_lock_commit'],
 'stagea_predictions_digest':r['source']['predictions_sha256'],
 'png_basename_allowlist':['000002.png','000004.png','000006.png','000008.png'],
 'method_count':12,'pair_count':4,
 'predictions_refitted_after_gt':False,
 'native_flow':False,'native_learning':False,'original_p_writes':0,
 'reserved_validation_blind_read':False,
 'immutable_append_only':True}
(out/'protocol.json').write_text(json.dumps(p,sort_keys=True,indent=2)+'\n')
PY
(cd "$OUT" && sha256sum report.json protocol.json console.log > SHA256SUMS && sha256sum -c SHA256SUMS)
TAR="$OUT.tar.gz"
tar -C "$ROOT" -czf "$TAR" "$(basename "$OUT")"
sha256sum "$TAR" > "$TAR.sha256"
printf '%s\n' 'STAGEB_DEV_GT_SCORED__ENGINEERING_RESEARCH_SCIENTIFIC_HOLD'
printf 'PACCHETTO_EVIDENZE: %s\n' "$TAR"
sha256sum "$TAR"
printf 'SHA256_SIDECAR: %s\n' "$TAR.sha256"
