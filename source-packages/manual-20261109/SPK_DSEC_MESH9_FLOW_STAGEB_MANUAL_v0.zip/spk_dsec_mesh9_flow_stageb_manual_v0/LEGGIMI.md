# SPK/* DSEC 9 isole — Stage B DEV optical-flow scoring v0

**Solo esecuzione manuale su Fedora fwork.** Il codice usa un file Stage A **già bloccato su GitHub PR #218** (commit `a6098e4dc716862e9baae4bd1b74ef56904c320e`). Non contiene addestramento, né modifica alcun neurone, PE, ISA, compiler o dato di ingresso. Calcola soltanto metriche con un **decoder esterno** sulle ipotesi di movimento già congelate.

## Preconditions non negoziabili

- Stage A esatto `~/workspace/spk-manual-runs/20261109T223220Z-dsec-mesh9-readout-stagea.tar.gz`, SHA256 `3d3b37b646bab09a6dbace45c3ab56ae11c4b5d3ae57cb174d4df5eb0fd03105`, con 48 mappe frozen. **Il verificatore controlla archivio e 48 digest PRIMA di leggere PNG GT**.
- `~/Scaricati/train_optical_flow.zip`: apertura di soli **quattro PNG DEV `thun_00_a`**, `000002.png`, `000004.png`, `000006.png`, `000008.png`, e nessun contenuto delle sequenze riservate `zurich_city_01_a` o `zurich_city_02_a`. L'inventario ZIP (central directory) è verificato prima dell'apertura di qualunque PNG.
- PNG DSEC formato **RGB 16 bit**, 640×480; canali R/G valori codificati di u/v, B=maschera validità in {0,1}; `u=(R-32768)/128`, `v=(G-32768)/128`. Lettura tramite **pypng**, non OpenCV/BGR/uint8. Pixel non validi sempre esclusi.
- Verifiche storiche D2c0 DEV #128: **214.102** pixel validi complessivi, EPE zero flow circa **11,188 px**. Differenze marcate nei due controlli provocano errore, non aggiustamento del metodo.

## Installazione/avvio

Scarica `SPK_DSEC_MESH9_FLOW_STAGEB_MANUAL_v0.zip` in `~/Scaricati`. Quindi:

```bash
cd ~/Scaricati
unzip SPK_DSEC_MESH9_FLOW_STAGEB_MANUAL_v0.zip
cd spk_dsec_mesh9_flow_stageb_manual_v0
source ~/Scaricati/spk_dsec_mesh9_dev_v0/.venv/bin/activate
python -m pip install pypng
bash run_spk_dsec_mesh9_flow_stageb_manual.sh
```

Il lanciatore verifica prima i checksum del proprio codice, poi i test, quindi il lock del run precedente. Solo alla fine legge il GT della sequenza DEV. Una seconda esecuzione in processo Python fresco ricalcola e verifica il report senza sovrascriverlo.

Il risultato è un TAR versionato, in `~/workspace/spk-manual-runs/<UTC>-dsec-mesh9-stageb-dev-gt-v0.tar.gz`, e un file `.sha256`. Carica **entrambi** nella chat per l'audit CIAT. Nei file di evidenza non sono inclusi PNG o array di pixel ground truth, soltanto SHA dei quattro PNG, EPE e percentuali PE1/2/3 per metodo e finestra.

## Scientificità e limiti

Metodi fissi: movimento nullo, PI_RAW_LOG_COUNT, PI_TOPK_PULSE_COUNT, C6_TOPK_PULSE_COUNT, e Pi/C6 emissioni originali SPK per fanout2/4 × mesh OFF/ON = 12 predizioni per coppia. Test già **DEV e post hoc**: il fanout4 è stato scelto sulla prima finestra DEV. Nessuna generalizzazione, optical flow nativo, apprendimento SPK, BV→P o GO scientifico. L'EPE storico D2c0 non è direttamente comparabile nei dettagli metodologici per risoluzione/griglia diversa, ma il movimento zero sullo stesso GT resta un controllo rigoroso.

**Codice:** l'archivio contiene soltanto scorer, test, shell, README, manifest SHA256. Il runtime della rete e le mappe sono nel pacchetto originale Stage A già committato in DRAFT #218 e nell'evidenza SHA-congelata. Nessuna versione precedente viene sovrascritta. In caso di VETO non aprire validazione/blind o cambiare i parametri dopo aver visto il GT.
