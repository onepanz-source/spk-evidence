#!/usr/bin/env python3
"""SPK/* DSEC Stage B, DEV ONLY: evaluate FROZEN #217 Stage A predictions.

This tool is solely an EXTERNAL metric scorer, NOT a native SPK flow estimator.
It reads exactly four thun_00_a DEV flow PNG members after verifying the
pre-GT prediction-lock SHA. Reserved validation/blind GT must remain unread.
No tuning, learning, BV, owner writes, or DSEC event input source edits.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import zipfile

SCHEMA = "spk-dsec-mesh9-readout-stageb-gt-dev-only/v0"
LOCK_COMMIT = "a6098e4dc716862e9baae4bd1b74ef56904c320e"
STAGEA_ARCHIVE_SHA256 = "3d3b37b646bab09a6dbace45c3ab56ae11c4b5d3ae57cb174d4df5eb0fd03105"
STAGEA_REPORT_SHA256 = "150caae20e100bbc89d958513ee8ad2e3a1cc04d14e8c9da078edd8d2ae0a890"
STAGEA_PREDICTIONS_SHA256 = "416202547568b3a18d858dab784d714f7da63cabf1e7c4c531c516b697dec7e3"
STAGEA_EMISSIONS_SHA256 = "720018c362ecacd32a3c186c2ebe878d049dfa303d4f96dda9b3ae0c10fb27b4"
STAGEA_RAW_PRED_FILE_SHA256 = "0e4e889d0e9bca952edecda6667dc35a7e79f9b336b939ac132aca685d037e0b"
STAGEA_RAW_REPORT_FILE_SHA256 = "639481a626f463998120e1041eb71ae9a3692c5a9946ba675a5c3a6d92ec07c4"
PRIOR_ZERO_EPE = 11.188 # Historical #128 D2c0, rounded to 3dp; scientific sanity guard
PRIOR_VALID_PIXELS = 214102
EXACT_DEV_PNGS = tuple(f"{k:06d}.png" for k in (2,4,6,8))
STAGEA_SUBDIR = "20261109T223220Z-dsec-mesh9-readout-stagea"
EXPECTED_MEMBERS = {f"{STAGEA_SUBDIR}/{n}" for n in
 ("report.json", "protocol.json", "predictions.json", "emissions.jsonl", "SHA256SUMS", "console.log")}
EXPECTED_METHODS = {"ZERO_FLOW_PI", "PI_RAW_LOG_COUNT", "PI_TOPK_PULSE_COUNT", "C6_TOPK_PULSE_COUNT"} | {
    f"{geo}_PE_F{f}_M{m}" for geo in ("PI", "C6") for f in (2,4) for m in (0,1)
}
DSEC_DEV_PREFIX="thun_00_a/flow/forward/"
# #128 official mapping: first four sorted DEV files 000002/4/6/8; 41 in total
DEV_FORWARD_COUNT=41
WIDTH,HEIGHT=640,480


def guard(ok, code):
    if not ok:
        raise RuntimeError(code)


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(obj):
    return hashlib.sha256(canonical(obj).encode('utf-8')).hexdigest()


def sha(b):return hashlib.sha256(b).hexdigest()


def sha_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for x in iter(lambda:f.read(4*1024*1024),b''):h.update(x)
    return h.hexdigest()


def load_pre_gt_lock(archive):
    """Full cryptographic/shape validation strictly BEFORE any GT member read."""
    path=Path(archive).expanduser().resolve()
    guard(path.is_file(),"STAGEA_ARCHIVE_MISSING")
    guard(sha_file(path)==STAGEA_ARCHIVE_SHA256,"STAGEA_ARCHIVE_SHA_MISMATCH_STOP_BEFORE_GT")
    contents={}
    with tarfile.open(path,'r:gz') as t:
        infos=t.getmembers()
        names={i.name for i in infos if i.isfile()}
        guard(names==EXPECTED_MEMBERS and all(i.isfile() or i.isdir() for i in infos),
              "STAGEA_TAR_MEMBERS_CHANGED")
        guard(all(i.size<=3_000_000 and not i.issym() and not i.islnk() for i in infos if i.isfile()),
              "STAGEA_TAR_UNSAFE_ENTRY")
        for name in sorted(names):
            contents[name.split('/')[-1]]=t.extractfile(name).read()
    checksum_lines=contents['SHA256SUMS'].decode().strip().splitlines()
    guard(len(checksum_lines)==5,"STAGEA_MANIFEST_SIZE")
    seen=set()
    for line in checksum_lines:
        m=re.fullmatch(r'([a-f0-9]{64})  ([A-Za-z0-9_.]+)',line)
        guard(m is not None,"STAGEA_MANIFEST_FORMAT")
        want,name=m.groups()
        guard(name not in seen and name in contents and name!='SHA256SUMS' and sha(contents[name])==want,
              "STAGEA_MANIFEST_MISMATCH")
        seen.add(name)
    guard(seen==set(contents)-{'SHA256SUMS'},"STAGEA_MANIFEST_INCOMPLETE")
    guard(sha(contents['report.json'])==STAGEA_RAW_REPORT_FILE_SHA256,"STAGEA_REPORT_BYTE_SHA")
    guard(sha(contents['predictions.json'])==STAGEA_RAW_PRED_FILE_SHA256,"STAGEA_PREDICTION_BYTE_SHA")
    report=json.loads(contents['report.json']);preds=json.loads(contents['predictions.json'])
    guard(report.get('canonical_sha256')==STAGEA_REPORT_SHA256 and
          digest({k:v for k,v in report.items() if k!='canonical_sha256'})==STAGEA_REPORT_SHA256,
          "STAGEA_REPORT_CANONICAL_SHA")
    guard(report.get('predictions_sha256')==STAGEA_PREDICTIONS_SHA256 and
          digest(preds)==STAGEA_PREDICTIONS_SHA256,"STAGEA_PRED_CANONICAL_SHA")
    emits=[json.loads(line) for line in contents['emissions.jsonl'].decode().splitlines()]
    guard(len(emits)==26809 and report.get('all_emissions_rows')==26809 and
          digest(emits)==STAGEA_EMISSIONS_SHA256==report.get('all_emissions_sha256'),
          "STAGEA_EMISSIONS_CANONICAL_SHA")
    guard(report['gt_pixels_read'] is False and report['reserved_val_blind_read'] is False and
          report['spk_learning'] is False and report['p_writes']==0 and
          report['native_spk_flow_estimation'] is False and
          report['dev_pairs']==[0,1,2,3] and report['dev_scene']=='thun_00_a',
          "STAGEA_SCOPE_MISMATCH")
    guard(len(preds)==4 and len(report['observer_checks'])==16 and
          all(x.get('observer_noninterference') is True for x in report['observer_checks']),
          "STAGEA_OBSERVER_INVARIANCE_MISSING")
    for pair_i,p in enumerate(preds):
        guard(p['pair']==pair_i and len(p['predictions'])==12,"STAGEA_PAIR_OR_METHOD_COUNT")
        methods={m['method']:m for m in p['predictions']}
        guard(set(methods)==EXPECTED_METHODS,"STAGEA_METHOD_SET")
        for name,m in methods.items():
            f=m['forward_flow_uv_px'];w=m['grid_width'];h=m['grid_height']
            guard((w,h)==((32,16) if name.startswith('PI_') or name=='ZERO_FLOW_PI' else (16,16)),
                  "STAGEA_FLOW_GRID")
            guard(len(f)==w*h and all(isinstance(z,list) and len(z)==2 and
                  all(type(v)==int and abs(v)<=160 for v in z) for z in f),
                  "STAGEA_VECTOR_RANGE")
            guard(m['flow_sha256']==digest(f)==report['projections'][pair_i]['method_flow_digests'][name],
                  "STAGEA_METHOD_FLOW_DIGEST")
        guard(all(v==[0,0] for v in methods['ZERO_FLOW_PI']['forward_flow_uv_px']),
              "STAGEA_ZERO_NOT_ZERO")
    return report,preds


def select_dev_gt_names(zf):
    """Central directory only; NEVER use validation or blind entries."""
    names=[i.filename for i in zf.infolist() if not i.is_dir()]
    guard(len(names)==len(set(names)),"FLOW_ZIP_DUPLICATE_NAMES")
    dev=sorted(x for x in names if x.startswith(DSEC_DEV_PREFIX) and x.endswith('.png'))
    guard(len(dev)==DEV_FORWARD_COUNT,"FLOW_ZIP_DEV_PNG_COUNT_DRIFT")
    chosen=dev[:4]
    guard(tuple(Path(x).name for x in chosen)==EXACT_DEV_PNGS,"FLOW_ZIP_GT_MAPPING_DRIFT")
    guard(all(x==DSEC_DEV_PREFIX+n for x,n in zip(chosen,EXACT_DEV_PNGS)),
          "FLOW_ZIP_PATH_NOT_EXACT_DEV")
    # > before ANY payload read, type- and size-guard exact four DEV members
    for name in chosen:
        info=zf.getinfo(name)
        guard(info.file_size>1000 and info.file_size<=7_000_000 and info.compress_size<=7_000_000,
              "FLOW_ZIP_DEV_PNG_SIZE")
    return chosen


def decode_rgb16_png(raw):
    """Use pypng to PRESERVE all 16bit RGB channels in DSEC order."""
    import numpy as np
    import png
    reader=png.Reader(bytes=raw)
    w,h,rows,info=reader.asDirect()
    guard((w,h)==(WIDTH,HEIGHT) and info.get('bitdepth')==16 and
          info.get('planes')==3 and not info.get('alpha') and not info.get('greyscale'),
          "GT_IMAGE_NOT_RGB_UINT16_640x480")
    arr=np.array(list(rows),dtype=np.uint16).reshape(HEIGHT,WIDTH,3)
    guard(np.all((arr[:,:,2]==0)|(arr[:,:,2]==1)),"GT_VALID_MASK_NOT_BOOLEAN")
    valid=arr[:,:,2].astype(bool)
    guard(bool(valid.any()),"GT_NO_VALID_PIXELS")
    uv=np.stack(((arr[:,:,0].astype(np.float64)-32768.0)/128.0,
                 (arr[:,:,1].astype(np.float64)-32768.0)/128.0),axis=2)
    guard(np.isfinite(uv).all(),"GT_NONFINITE")
    return uv,valid


def expand_coarse_prediction(p):
    import numpy as np
    w,h,cx,cy=p['grid_width'],p['grid_height'],p['cell_x_px'],p['cell_y_px']
    guard(w*cx==WIDTH and h*cy==HEIGHT and (w,h) in ((32,16),(16,16)),"COARSE_GRID_SPATIAL_MISMATCH")
    raw=np.asarray(p['forward_flow_uv_px'],dtype=np.float64).reshape(h,w,2)
    return np.repeat(np.repeat(raw,cy,axis=0),cx,axis=1)


def metric_counts(pred,truth,valid):
    import numpy as np
    guard(pred.shape==truth.shape==(HEIGHT,WIDTH,2) and valid.shape==(HEIGHT,WIDTH),
          "SCORING_SHAPE_MISMATCH")
    e=np.hypot(pred[:,:,0]-truth[:,:,0],pred[:,:,1]-truth[:,:,1])[valid]
    guard(len(e)>0 and np.isfinite(e).all(),"SCORING_INVALID_PIXELS")
    return {'valid_pixels':int(len(e)),'sum_epe':float(e.sum(dtype=np.float64)),
            'gt1':int((e>1).sum()),'gt2':int((e>2).sum()),'gt3':int((e>3).sum())}


def as_metrics(counts):
    n=counts['valid_pixels'];guard(n>0,'EMPTY_SCORE_COUNT')
    return {'valid_pixels':n,'EPE':counts['sum_epe']/n,
            'PE1_pct':100*counts['gt1']/n,'PE2_pct':100*counts['gt2']/n,
            'PE3_pct':100*counts['gt3']/n}


def score(preds,gt_zip,archive_sha=STAGEA_ARCHIVE_SHA256):
    """CALL ONLY AFTER load_pre_gt_lock has succeeded and lock is on GitHub."""
    import numpy as np
    result=[];totals={m:{'valid_pixels':0,'sum_epe':0.0,'gt1':0,'gt2':0,'gt3':0} for m in sorted(EXPECTED_METHODS)}
    zpath=Path(gt_zip).expanduser().resolve()
    guard(zpath.is_file(),"FLOW_GT_ZIP_NOT_FOUND")
    with zipfile.ZipFile(zpath,'r') as z:
        chosen=select_dev_gt_names(z)
        for pair,name in enumerate(chosen):
            raw=z.read(name) # sole access to GT bytes, four EXACT thun_00_a DEV PNGs
            uv,valid=decode_rgb16_png(raw)
            bymethod={}
            for m in preds[pair]['predictions']:
                s=metric_counts(expand_coarse_prediction(m),uv,valid)
                bymethod[m['method']]=as_metrics(s)
                for key in ('valid_pixels','gt1','gt2','gt3'):totals[m['method']][key]+=s[key]
                totals[m['method']]['sum_epe']+=s['sum_epe']
            result.append({'pair':pair,'dev_png_basename':Path(name).name,'dev_png_sha256':sha(raw),
                           'gt_valid_pixels':int(valid.sum()),'methods':bymethod})
    pooled={name:as_metrics(s) for name,s in totals.items()}
    # Failure here indicates a different GT mapping, PNG channel decode, or source.
    # We do NOT tune the model or suppress negative results on any mismatch.
    valid=pooled['ZERO_FLOW_PI']['valid_pixels'];zero=pooled['ZERO_FLOW_PI']['EPE']
    guard(valid==PRIOR_VALID_PIXELS,"HISTORICAL_DEV_GT_VALID_PIXEL_COUNT_MISMATCH_STOP")
    guard(abs(zero-PRIOR_ZERO_EPE)<=0.05,"HISTORICAL_ZERO_FLOW_EPE_MISMATCH_STOP")
    return {'schema':SCHEMA, 'stage':'B_DEV_GT_SCORED_AFTER_PRE_GT_SHA_LOCK',
        'scope':'already_exposed_thun_00_a_DEV_only_no_independent_generalization',
        'source':{'stagea_archive_sha256':archive_sha,'stagea_lock_commit':LOCK_COMMIT,
                  'predictions_sha256':STAGEA_PREDICTIONS_SHA256,'method_count':12,
                  'pair_indices':[0,1,2,3]},
        'gt':{'dev_png_read':True,'validation_gt_read':False,'blind_gt_read':False,
              'png_sha256_by_pair':[x['dev_png_sha256'] for x in result],
              'valid_pixels_total':valid},
        'per_pair':result,'pooled_pixel_weighted':pooled,
        'historical_reference_D2c0':{'zero_EPE_3dp':11.188,'host_raw_log_EPE_3dp':13.023,
                                    'prior_spk_external_matcher_EPE_3dp':16.436,
                                    'note':'different grid/prediction methods; compare cautiously'},
        'scientific':{'SPK_native_flow':False,'SPK_learning':False,'original_P_writes':0,
                      'scientific_GO':False,'flow_estimator':'EXTERNAL_FIXED_BLOCK_MATCHER',
                      'no_tuning_after_gt':True,'fanout4_selected_posthoc_on_dev_pair0':True},
        'verdict':'DEV_EXTERNAL_FLOW_SCORED_ENGINEERING_ONLY_SCIENTIFIC_HOLD'}


def main(argv=None):
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--stagea',default='~/workspace/spk-manual-runs/20261109T223220Z-dsec-mesh9-readout-stagea.tar.gz')
    a.add_argument('--flow-zip',default='~/Scaricati/train_optical_flow.zip')
    a.add_argument('--out',required=True)
    a.add_argument('--verify',action='store_true',help='Recompute and verify a previously locked report, never overwrite')
    args=a.parse_args(argv)
    report,locked=load_pre_gt_lock(args.stagea)
    print('PRE_GT_SHA_AND_PREDICTIONS_LOCK_VERIFIED',STAGEA_ARCHIVE_SHA256,flush=True)
    if args.verify:
        output=Path(args.out);guard(output.is_file(),"VERIFY_EXPECTED_REPORT_NOT_FOUND")
        expected=json.loads(output.read_text());previous_sha=expected.get('canonical_sha256')
    else:
        output=Path(args.out);guard(not output.exists(),"OUTPUT_EXISTS_NO_OVERWRITE")
    scores=score(locked,args.flow_zip)
    scores['canonical_sha256']=digest(scores)
    if args.verify:
        guard(previous_sha==scores['canonical_sha256'] and expected==scores,
              "SCORED_REPLAY_MISMATCH")
        print('STAGEB_FRESH_PROCESS_REPLAY_EXACT_PASS',scores['canonical_sha256'])
    else:
        output.parent.mkdir(parents=True,exist_ok=True)
        output.write_text(json.dumps(scores,sort_keys=True,indent=2)+'\n')
        print('STAGEB_DEV_GT_SCORED_SCIENTIFIC_HOLD',scores['canonical_sha256'])
        print('ZERO_FLOW_EPE',round(scores['pooled_pixel_weighted']['ZERO_FLOW_PI']['EPE'],5))
        for name in sorted(EXPECTED_METHODS):
            x=scores['pooled_pixel_weighted'][name]
            print('POOL',name,'N',x['valid_pixels'],'EPE',round(x['EPE'],5))
    return 0

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as e:
        print('SCORING_HOLD:',type(e).__name__,str(e),file=sys.stderr)
        sys.exit(4)
