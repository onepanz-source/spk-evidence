import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock
import numpy as np
import spk_dsec_mesh9_flow_stageb_v0 as m

class TestStageB(unittest.TestCase):
 def test_locked_pred_source_hash_different(self):
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'old.tar.gz';f.write_bytes(b'fake')
   with self.assertRaisesRegex(RuntimeError,'SHA_MISMATCH'):
    m.load_pre_gt_lock(f)
 def test_methods_exactly_twelve(self):
  self.assertEqual(len(m.EXPECTED_METHODS),12)
  self.assertIn('PI_PE_F4_M1',m.EXPECTED_METHODS)
 def test_png_allowlist_is_names_only(self):
  z=MagicMock()
  z.infolist.return_value=[type('M',(),{'filename':m.DSEC_DEV_PREFIX+f'{(k+1)*2:06d}.png', 'is_dir':lambda self:False})() for k in range(41)]
  z.getinfo.return_value=type('I',(),{'file_size':5000,'compress_size':4000})()
  self.assertEqual([Path(x).name for x in m.select_dev_gt_names(z)],list(m.EXACT_DEV_PNGS))
  z.read.assert_not_called()
 def test_invalid_png_mapping_stops_before_pixels(self):
  z=MagicMock()
  z.infolist.return_value=[type('M',(),{'filename':m.DSEC_DEV_PREFIX+f'{k:06d}.png', 'is_dir':lambda self:False})() for k in range(41)]
  with self.assertRaisesRegex(RuntimeError,'MAPPING_DRIFT'):
   m.select_dev_gt_names(z)
  z.read.assert_not_called()
 def test_dense_projection_correct_coordinates(self):
  p={'grid_width':32,'grid_height':16,'cell_x_px':20,'cell_y_px':30,
     'forward_flow_uv_px':[[0,0]]*512}
  p['forward_flow_uv_px'][1]=[40,-60]
  dense=m.expand_coarse_prediction(p)
  self.assertEqual(tuple(dense.shape),(480,640,2))
  self.assertTrue(np.all(dense[0:30,20:40,0]==40))
  self.assertTrue(np.all(dense[0:30,20:40,1]==-60))
  self.assertTrue(np.all(dense[30:60,20:40]==0))
 def test_epe_synthetic_sign_and_mask(self):
  a=np.zeros((480,640,2));b=a.copy();v=np.zeros((480,640),dtype=bool)
  b[4,5]=[-3,4];v[4,5]=True
  r=m.as_metrics(m.metric_counts(a,b,v))
  self.assertEqual(r['valid_pixels'],1);self.assertEqual(r['EPE'],5)
  self.assertEqual(r['PE1_pct'],100);self.assertEqual(r['PE3_pct'],100)
 def test_zero_mask_rejected(self):
  a=np.zeros((480,640,2));v=np.zeros((480,640),dtype=bool)
  with self.assertRaisesRegex(RuntimeError,'SCORING_INVALID_PIXELS'):
   m.metric_counts(a,a,v)
 def test_digest_stability(self):
  self.assertEqual(m.digest({'b':1,'a':2}),hashlib.sha256(b'{"a":2,"b":1}').hexdigest())
 def test_source_archive_actual_if_available(self):
  src=Path('/mnt/data/20261109T223220Z-dsec-mesh9-readout-stagea.tar.gz')
  if src.exists():
   report,preds=m.load_pre_gt_lock(src)
   self.assertEqual(len(preds),4)
   self.assertEqual(report['all_emissions_rows'],26809)

if __name__=='__main__':unittest.main()
