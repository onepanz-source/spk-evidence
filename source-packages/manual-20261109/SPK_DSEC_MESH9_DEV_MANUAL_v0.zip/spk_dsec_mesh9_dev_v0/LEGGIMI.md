# SPK/* × DSEC DEV Stage A — Nine islands, real event data

## Cosa fa

Legge **direttamente due ZIP locali già scaricati**, SENZA decomprimerli integralmente:

- `~/Scaricati/train_events.zip`: legge SOLO la sequenza DSEC **`thun_00_a`** (`events/left/events.h5`, `rectify_map.h5`).
- `~/Scaricati/train_optical_flow.zip`: legge SOLO i **timestamp forward** di `thun_00_a`, per selezionare le prime quattro finestre ufficiali da circa 100 ms. **NON legge alcun pixel o PNG di ground truth optical flow**.

Dalle directory centrali degli ZIP legge soltanto i nomi delle sequenze riservate (`zurich_city_01_a` per validazione, `zurich_city_02_a` per blind), per la verifica del partizionamento storico preregistrato (#128). Le due sequenze riservate non vengono estratte, aperte, usate o valutate. Nessuna nuova scelta di scene è consentita nel caso di errore.

Prima riutilizza i sorgenti `~/workspace/spk-dsec-intake/thun_00_a/...` già estratti in D0, **solo dopo SHA256 dei TRE singoli file**, contro i pin fissati in #128. Se assenti, estrae individualmente soltanto quei tre membri in `spk-dsec-intake`, verificando CRC ZIP e SHA256, senza leggere gli altri ~125 GB del dataset. Non calcola SHA dei due ZIP interi: oltre a essere costoso, non servirebbe a provare che il singolo segmento H5 fosse corretto. Non sovrascrive mai un file differente. Lo spazio disco aggiuntivo dipende dai singoli membri; l'inventory riporta i loro byte prima dell'estrazione.

**Step 1: ingresso DSEC**: VGA 640×480; rettifica con `rectify_map[y,x]` e arrotondamento `floor(+0.5)`; sincronizzazione tramite `t_offset` ufficiale; ogni finestra forward dura ~100 ms, suddivisa in 20 intervalli causali di ~5 ms. Eventi di polarità 0 e 1 restano distinti.

**Step 2: encoder con limite di banda**: 16×16 celle spaziali×2 polarità→512 neuroni delle otto isole C6 (`2 colonne ×16 righe×2 polarità=64` neuroni per isola), 32×16×2→1.024 neuroni della singola isola Pi5. Il Pi vede una seconda codifica degli stessi eventi, quindi **NON** rappresenta un sensore indipendente: l'informazione originale è duplicata intenzionalmente, e non si può attribuire alla mesh un vantaggio informativo intrinseco. Per ogni finestra di 5 ms, solo gli **8** bin con maggior numero di eventi per isola C6 e i **32** per Pi vengono inoltrati, con pari merito risolto per ID crescente; conteggi `<40, 40..159, >=160`→1/2/3 impulsi. Questa scelta è basata solo su eventi già avvenuti nell'intervallo, senza target futuro o GT. I contatori raw, di scarto e compressione sono riportati per ogni finestra.

**Step 3: compute/mesh**: per ciascuna coppia temporale, stato delle nove isole reimpostato, `mesh OFF` vs `mesh ON`, stessi input, stesso originale `_compute_local()` PE A1b pinnato (ACC,CMP,EMIT,RESET), scheduler distribuito di ricerca, 1.536 neuroni, 12.288 edge locali, 14 radio +1 Ethernet, gateway G9 senza neuroni, code locali e link finite, conteggio delle perdite e dell'attività reale dei neuroni. Si esegue il replay deterministico e si registrano SHA delle tracce/stati. **No BV, no learning, no native P writes.** Il tempo dei 20 tick descrive bin temporali, ma la mesh usa latenze in tick logici non calibrate su ESP32-C6 reali.

## Comandi su Fedora fwork

```bash
cd ~/Scaricati
unzip SPK_DSEC_MESH9_DEV_MANUAL_v0.zip
cd spk_dsec_mesh9_dev_v0

# 1. Nomi, dimensioni e split dai soli indici ZIP, NESSUN dato ottico GT letto:
bash run_spk_dsec_mesh9_manual.sh inventory

# 2. Dipendenze per H5 Blosc ZSTD e NumPy. Riattiva un venv esistente o creane uno:
python3 -m venv .venv
source .venv/bin/activate
python -m pip install numpy h5py hdf5plugin

# 3. Primo segmento DSEC reale:
bash run_spk_dsec_mesh9_manual.sh smoke

# 4. Quattro segmenti DEV DSEC già autorizzati:
bash run_spk_dsec_mesh9_manual.sh full
```

Il repository viene cercato in `~/workspace/spk-backvalidation-v0` (oppure secondo argomento del launcher). Viene estratto solo in una cartella temporanea il Git commit originale PE `787c8fbe...`: checkout attuale, branch main, PR ed evidence root **non vengono modificati**. `inventory` non richiede venv. Per `smoke/full`, **si richiedono** `numpy`, `h5py` e `hdf5plugin` dentro il venv attivo.

L'output append-only viene scritto sotto `~/workspace/spk-manual-runs/<UTC>-dsec-mesh9-dev-<profilo>/` insieme al file `.tar.gz` e al relativo `.tar.gz.sha256`. Carica entrambi. I file interni `protocol.json`, `zip_inventory.json`, `report.json` e `console.log` sono verificati da `SHA256SUMS`.

### Cosa NON significa un risultato positivo

Non è EPE DSEC, non valuta GT optical flow, non confronta precisione percettiva, non dimostra apprendimento, inferenza video, generalizzazione o comportamento emergente. `thun_00_a` è un DEV già esposto storicamente. Lo scopo è misurare quanti eventi **reali** DSEC raggiungono neuroni SPK e quanti vengono trattati, persi o trasportati sulla mesh. Se abbiamo overflow, sarà un risultato diagnostico utile, non un PASS scientifico.

Non avvia scheduler M/W/V, non legge altre sequenze e non tocca i confini HUMAN HOLD.
