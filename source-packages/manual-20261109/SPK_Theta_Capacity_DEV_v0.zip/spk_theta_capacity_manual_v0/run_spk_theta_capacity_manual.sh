#!/usr/bin/env bash
# SPK/* MANUAL Test A: no scheduler, no agent execution, no holdout, no GitHub writes.
set -Eeuo pipefail
export LC_ALL=C

PROFILE="${1:-quick}"
REPO="${2:-${SPK_REPO:-$HOME/workspace/spk-backvalidation-v0}}"
case "$PROFILE" in smoke|quick|full) ;; *) echo "USO: bash $0 [smoke|quick|full] [repo_git_locale]" >&2; exit 2;; esac
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
( cd "$SCRIPT_DIR" && sha256sum --check CODE_SHA256SUMS ) || { echo "PACKAGE_HASH_MISMATCH" >&2; exit 4; }
MAIN="787c8fbed87c1e2e4b703e985f68ae53c81c8444"
E1G="5311376e4dfe681e860e87dd95e48ada232f54c3"
E1G_FILES=(
  research/spk_sci_lrn_e1g_task_v0.py
  research/spk_sci_lrn_e1g_pe_v0.py
)

[[ -d "$REPO/.git" || -f "$REPO/.git" ]] || {
  echo "ERRORE: non trovo il repository Git in $REPO" >&2
  echo "Passa il percorso come secondo argomento." >&2
  exit 3
}
command -v git >/dev/null || { echo 'Serve git' >&2; exit 3; }
command -v tar >/dev/null || { echo 'Serve tar' >&2; exit 3; }
PYTHON="${PYTHON:-python3}"
"$PYTHON" -c 'import numpy' || {
  echo 'ERRORE: attiva il venv Python di SPK con numpy installato (o imposta PYTHON=/percorso/python)' >&2
  exit 3
}

# Only local git object reads in the normal case. Fallback fetch is for missing
# pinned objects, never checkout/reset/merge/push and never changes current files.
if ! git -C "$REPO" cat-file -e "${MAIN}^{commit}" 2>/dev/null; then
  echo "Manca main pin $MAIN; recupero read-only degli oggetti da origin..."
  git -C "$REPO" fetch --no-tags origin "$MAIN"
fi
if ! git -C "$REPO" cat-file -e "${E1G}^{commit}" 2>/dev/null; then
  echo "Manca PR #209 commit $E1G; recupero read-only di refs/pull/209/head..."
  git -C "$REPO" fetch --no-tags origin refs/pull/209/head
  GOT="$(git -C "$REPO" rev-parse FETCH_HEAD)"
  [[ "$GOT" == "$E1G" ]] || { echo "PR_PIN_DRIFT $GOT != $E1G" >&2; exit 4; }
fi
[[ "$(git -C "$REPO" rev-parse "${MAIN}^{commit}")" == "$MAIN" ]] || { echo MAIN_PIN_DRIFT >&2; exit 4; }
[[ "$(git -C "$REPO" rev-parse "${E1G}^{commit}")" == "$E1G" ]] || { echo E1G_PIN_DRIFT >&2; exit 4; }

TMP="$(mktemp -d -t spk-theta-testA-XXXXXXXX)"
trap 'rm -rf -- "$TMP"' EXIT
mkdir -p "$TMP/source"
echo "Preparo snapshot SOURCE in area temporanea; non tocco il checkout attivo..."
git -C "$REPO" archive --format=tar "$MAIN" | tar -xf - -C "$TMP/source"
for FILE in "${E1G_FILES[@]}"; do
  mkdir -p "$TMP/source/$(dirname "$FILE")"
  git -C "$REPO" show "${E1G}:${FILE}" > "$TMP/source/$FILE"
done

"$PYTHON" "$SCRIPT_DIR/spk_theta_capacity_dev_v0.py" --selftest
BASE_OUT="${SPK_THETA_OUTPUT_BASE:-$HOME/workspace/spk-manual-runs}"
mkdir -p "$BASE_OUT"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$BASE_OUT/${STAMP}-theta-capacity-${PROFILE}"
[[ ! -e "$OUT" ]] || { echo "OUTPUT_ESISTENTE $OUT; non sovrascrivo" >&2; exit 5; }

echo "TEST A, PROFILO=$PROFILE, ORIGINAL_PE=$MAIN, REG6=$E1G"
echo 'Nessun holdout, nessun aggiornamento BV, nessuna scrittura GitHub.'
"$PYTHON" "$SCRIPT_DIR/spk_theta_capacity_dev_v0.py" \
  --root "$TMP/source" --out "$OUT" --profile "$PROFILE" | tee "$TMP/console.log"
cp "$TMP/console.log" "$OUT/console.log"
(
  cd "$OUT"
  sha256sum --check SHA256SUMS
)
ARCHIVE="${OUT}.tar.gz"
tar -czf "$ARCHIVE" -C "$BASE_OUT" "$(basename "$OUT")"
sha256sum "$ARCHIVE" > "${ARCHIVE}.sha256"
echo
printf 'PACCHETTO_EVIDENZE: %s\n' "$ARCHIVE"
printf 'SHA256_PACCHETTO: '; sha256sum "$ARCHIVE" | awk '{print $1}'
echo 'Carica qui il .tar.gz e il relativo .sha256: CIAT controllera i risultati e aggiornera GitHub.'
