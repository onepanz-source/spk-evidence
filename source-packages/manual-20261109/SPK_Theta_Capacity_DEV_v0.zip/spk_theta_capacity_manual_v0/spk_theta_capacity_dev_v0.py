#!/usr/bin/env python3
"""SPK/* Test A: finite theta-response capacity of the pinned original PE.

DEV-only, explicitly post-hoc exploratory: E1G validation labels already exposed.
No BV writes, no A/B/C updates, no holdout, no GitHub writes. Source PE and REG6
are supplied by a read-only pinned Git worktree prepared by the shell launcher.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np

BASE_HEAD = '787c8fbed87c1e2e4b703e985f68ae53c81c8444'
E1G_HEAD = '5311376e4dfe681e860e87dd95e48ada232f54c3'
EXPECTED_GIT_BLOBS = {
    'spk_architecture_v1/pe_execution_v1b.py': '2e16bdeddc7fc5eacbd341a6dbdf245d71095678',
    'spk_architecture_v1/pe_fabric_v1a.py': 'b0cf8b01a8e5ede6ad640349e11b91194c454763',
    'research/spk_v5_t7abc_def_ghi/scheduler_bridge_v0.py': '28850504b30d5a4e441d50833f40302a09a97796',
    'research/spk_sci_lrn_e1g_task_v0.py': '091d557fa7efd693d3d34c6c5444b1d8bd60da0d',
    'research/spk_sci_lrn_e1g_pe_v0.py': '943b6d1d8dd08b8931e53b6f8167b0de3935eb0e',
}
THETAS = tuple(range(1, 17))
SEED = 20261109
RIDGE = 0.05
SPLITS = {
    'smoke': {'train': list(range(0, 2)), 'select': [24], 'dev_exposed': [32]},
    'quick': {'train': list(range(0, 8)), 'select': list(range(24, 28)), 'dev_exposed': list(range(32, 36))},
    'full': {'train': list(range(0, 24)), 'select': list(range(24, 32)), 'dev_exposed': list(range(32, 48))},
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_blob(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\x00' + data).hexdigest()


def verify_pins(root: Path) -> dict:
    found = {}
    for relative, expected in EXPECTED_GIT_BLOBS.items():
        path = root / relative
        if not path.is_file():
            raise RuntimeError(f'PIN_MISSING {path}')
        actual = git_blob(path.read_bytes())
        if actual != expected:
            raise RuntimeError(f'PIN_DRIFT {relative}: expected={expected} actual={actual}')
        found[relative] = actual
    return found


def canonical(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def sigmoid(v):
    v = np.clip(v, -35.0, 35.0)
    return 1.0 / (1.0 + np.exp(-v))


def fit_logistic(X, y, ridge=RIDGE):
    """Deterministic L2-penalized logistic IRLS (no sklearn dependency)."""
    X = np.asarray(X, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    if X.ndim != 2 or X.shape[0] < 2 or len(y) != X.shape[0]:
        raise ValueError('INVALID_TRAIN_MATRIX')
    mean = X.mean(axis=0)
    scale = X.std(axis=0)
    scale = np.where(scale < 1e-10, 1.0, scale)
    features = (X - mean) / scale
    Z = np.column_stack([np.ones(len(features)), features])
    prior = float(np.clip(y.mean(), 1e-4, 1.0 - 1e-4))
    weight = np.zeros(Z.shape[1])
    weight[0] = math.log(prior / (1.0 - prior))
    penalty = np.diag([0.0] + [ridge] * (Z.shape[1] - 1))
    for _ in range(60):
        p = sigmoid(Z @ weight)
        curvature = np.clip(p * (1.0 - p), 1e-5, None)
        gradient = (Z.T @ (p - y)) / len(y) + penalty @ weight
        hessian = (Z.T * curvature) @ Z / len(y) + penalty + np.eye(Z.shape[1]) * 1e-10
        step = np.linalg.solve(hessian, gradient)
        # Backtracking keeps the deterministic optimizer stable for tiny splits.
        alpha = 1.0
        old_loss = logistic_objective(Z, y, weight, ridge)
        while alpha > 1.0 / 128.0:
            candidate = weight - alpha * step
            if logistic_objective(Z, y, candidate, ridge) <= old_loss + 1e-12:
                break
            alpha *= 0.5
        weight -= alpha * step
        if np.max(np.abs(alpha * step)) < 1e-9:
            break
    return {'mean': mean.tolist(), 'scale': scale.tolist(), 'weight': weight.tolist(), 'ridge': ridge}


def logistic_objective(Z, y, w, ridge):
    v = Z @ w
    return float(np.mean(np.logaddexp(0.0, v) - y * v) + ridge * np.sum(w[1:] ** 2) / 2.0)


def predict_logistic(model, X):
    X = np.asarray(X, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(1, -1)
    mean = np.array(model['mean'])
    scale = np.array(model['scale'])
    w = np.array(model['weight'])
    Z = np.column_stack([np.ones(len(X)), (X - mean) / scale])
    return sigmoid(Z @ w)


def auc(y, p):
    """Exact pairwise AUC with 0.5 credit for tied scores."""
    positives = [float(pi) for yi, pi in zip(y, p) if yi == 1]
    negatives = [float(pi) for yi, pi in zip(y, p) if yi == 0]
    if not positives or not negatives:
        return None
    wins = sum(1.0 if a > b else 0.5 if a == b else 0.0 for a in positives for b in negatives)
    return round(wins / (len(positives) * len(negatives)), 8)


def score(y, p):
    y = np.asarray(y, dtype=np.float64)
    p = np.clip(np.asarray(p, dtype=np.float64), 1e-8, 1.0 - 1e-8)
    return {'n': int(len(y)), 'positives': int(y.sum()),
            'brier': round(float(np.mean((p - y) ** 2)), 9),
            'logloss': round(float(-np.mean(y * np.log(p) + (1.0 - y) * np.log(1.0 - p))), 9),
            'auc': auc(y.astype(int).tolist(), p.tolist()),
            'p_min': round(float(p.min()), 6), 'p_max': round(float(p.max()), 6)}


def sensor_features(trajectory, ep):
    start = ep * 128
    ch1 = trajectory['ch1'][start:start + 65]
    ch2 = trajectory['ch2'][start:start + 65]
    return [sum(ch1) / 65.0, sum(ch2) / 65.0,
            sum(a and b for a, b in zip(ch1, ch2)) / 65.0,
            sum(ch2[t-1] and ch1[t] for t in range(1, 65)) / 64.0]


def collect_rows(root, profile, module_task, module_pe):
    rows = []
    selected = SPLITS[profile]
    all_ids = sorted(set(selected['train'] + selected['select'] + selected['dev_exposed']))
    for idx in all_ids:
        tr = module_task.gen_trajectory(idx)  # id >= 48 FORBIDDEN by source.
        split = next(k for k, ids in selected.items() if idx in ids)
        for ep in range(module_task.EPISODES):
            y = int(tr['y'][ep])  # used ONLY for training/score, never submitted to PE
            row = {'trajectory': idx, 'episode': ep, 'split': split, 'y': y,
                   'sensor_features': [round(v, 9) for v in sensor_features(tr, ep)],
                   'theta': {}}
            for theta in THETAS:
                raw = module_pe.run_observation_segment(root, tr['ch1'], tr['ch2'], ep, theta)
                source_trace = {'emissions': raw['emissions'], 'routes': raw['routes'],
                                'terminal': raw['terminal'], 'processed_batches': raw['batches'],
                                'batch_ids': raw['batch_ids']}
                row['theta'][str(theta)] = {
                    'p_raw': round(float(raw['p_raw']), 12),
                    'c7_pre': int(raw['c7_pre']),
                    'occupied_pre': int(raw['occupied_pre']),
                    'raw_at_64': int(raw['raw_at_64']),
                    'source_trace_sha256': sha256_bytes(canonical(source_trace).encode()),
                }
            rows.append(row)
        print(f'PROGRESS: completed trajectory {idx} [{split}], {len(rows)} episodes', flush=True)
    return rows


def build_report(rows, profile, pins):
    trains = [x for x in rows if x['split'] == 'train']
    selects = [x for x in rows if x['split'] == 'select']
    exposed = [x for x in rows if x['split'] == 'dev_exposed']
    groups = {'train': trains, 'select': selects, 'dev_exposed': exposed}
    labels_train = np.array([x['y'] for x in trains])
    models = {}
    scores = {}
    for theta in THETAS:
        key = f'theta_{theta:02d}'
        def xvalues(group):
            return np.array([[r['theta'][str(theta)]['p_raw']] for r in group])
        model = fit_logistic(xvalues(trains), labels_train)
        models[key] = model
        scores[key] = {
            name: score([r['y'] for r in group], predict_logistic(model, xvalues(group)))
            for name, group in groups.items()}
        scores[key]['distinct_raw_train'] = len({r['theta'][str(theta)]['p_raw'] for r in trains})
        scores[key]['raw_min_train'] = min(r['theta'][str(theta)]['p_raw'] for r in trains)
        scores[key]['raw_max_train'] = max(r['theta'][str(theta)]['p_raw'] for r in trains)
    for name, features in [('sensor_ch1_rate', [0]), ('sensor_four_features', [0, 1, 2, 3])]:
        def xvalues(group):
            return np.array([[r['sensor_features'][j] for j in features] for r in group])
        model = fit_logistic(xvalues(trains), labels_train)
        models[name] = model
        scores[name] = {group_name: score([r['y'] for r in group], predict_logistic(model, xvalues(group)))
                        for group_name, group in groups.items()}
    prior = float(labels_train.mean())
    scores['constant_train_prior'] = {group_name: score([r['y'] for r in group], [prior] * len(group))
                                       for group_name, group in groups.items()}
    # Selection depends on INTERNAL_SELECT only; exposed DEV is never used to choose theta.
    winner = min(THETAS, key=lambda th: (scores[f'theta_{th:02d}']['select']['brier'], th))
    per_row_distinct = [len({r['theta'][str(t)]['p_raw'] for t in THETAS}) for r in rows]
    differences_vs_theta6 = [sum(r['theta'][str(t)]['p_raw'] != r['theta']['6']['p_raw']
                                  for t in THETAS if t != 6) for r in rows]
    return {
        'schema': 'spk-theta-capacity-dev/v0',
        'verdict': 'DESCRIPTIVE_CAPACITY_MAP_ONLY__NO_LEARNING_CLAIM',
        'scientific_status': 'EXPLORATORY_POSTHOC_DEV; DEV_VAL 32..47 ALREADY EXPOSED IN E1G',
        'no_native_bv': True, 'P_writes': 0, 'science_GO': '0/3', 'holdout_accesses': 0,
        'source_heads': {'original_main': BASE_HEAD, 'E1G_dev_source': E1G_HEAD},
        'source_blobs': pins, 'profile': profile, 'splits': SPLITS[profile],
        'episodes_per_trajectory': 8, 'theta_sweep': list(THETAS),
        'train_only_logistic_calibration': {'ridge': RIDGE, 'optimizer': 'deterministic_L2_IRLS',
                                            'models': models},
        'scores': scores,
        'selection_rule': 'min INTERNAL_SELECT Brier among theta1..16; ties -> smaller theta; DEV not consulted',
        'selected_theta_internal_only': winner,
        'theta6_select_brier': scores['theta_06']['select']['brier'],
        'winner_select_brier': scores[f'theta_{winner:02d}']['select']['brier'],
        'theta6_exposed_dev_brier': scores['theta_06']['dev_exposed']['brier'],
        'winner_exposed_dev_brier': scores[f'theta_{winner:02d}']['dev_exposed']['brier'],
        'capacity': {
            'n_episodes': len(rows),
            'mean_distinct_praw_per_episode_across_16_theta': round(float(np.mean(per_row_distinct)), 6),
            'min_distinct_praw': min(per_row_distinct), 'max_distinct_praw': max(per_row_distinct),
            'episodes_with_any_theta_sensitive_readout': sum(n > 1 for n in per_row_distinct),
            'mean_changed_vs_theta6_out_of_15': round(float(np.mean(differences_vs_theta6)), 6),
        },
        'interpretation_fences': [
            'Different theta values alter the source PE readout; this is not evidence of learning.',
            'Logistic calibration fitted independently using TRAIN only, theta held fixed during each run.',
            'Sensor baseline uses only observed ticks 0..64 and no source PE outputs.',
            'Unblinded DEV_EXPOSED scores are diagnostic only; not generalization confirmation.',
            'No target suffix provided to source PE; teacher labels are used only for fitting/scoring.',
            'Original PE and generator are unmodified and verified by pinned Git blob hashes.',
        ],
    }


def selftest():
    X = np.array([[0.0], [1.0], [2.0], [3.0], [4.0], [5.0]])
    y = [0, 0, 0, 1, 1, 1]
    m = fit_logistic(X, y)
    p = predict_logistic(m, X)
    assert all(math.isfinite(float(z)) and 0 < z < 1 for z in p)
    assert float(p[-1]) > float(p[0])
    assert auc(y, p.tolist()) == 1.0
    assert git_blob(b'hello\n') == 'ce013625030ba8dba906f756967f9e9ca394464a'
    assert len(THETAS) == 16 and len(SPLITS['quick']['dev_exposed']) == 4
    print('SELFTEST_PASS deterministic_IRLS AUC exact_ties git_blob_sha1 theta_space')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, help='Pinned source worktree with original PE and E1G modules')
    parser.add_argument('--out', type=Path, help='New output directory (must not exist)')
    parser.add_argument('--profile', choices=tuple(SPLITS), default='quick')
    parser.add_argument('--selftest', action='store_true')
    args = parser.parse_args()
    if args.selftest:
        selftest()
        return 0
    if args.root is None or args.out is None:
        parser.error('--root and --out are required except for --selftest')
    root = args.root.resolve()
    pins = verify_pins(root)  # must fail closed before data access
    sys.path.insert(0, str(root))
    from research import spk_sci_lrn_e1g_task_v0 as task
    from research import spk_sci_lrn_e1g_pe_v0 as pe
    try:
        task.gen_trajectory(48)
    except task.HoldoutForbidden:
        pass
    else:
        raise RuntimeError('HOLDOUT_GUARD_NOT_TRIGGERED')
    # A brand-new directory is mandatory: never overwrite a previous run.
    if args.out.exists():
        raise RuntimeError(f'OUTPUT_PATH_ALREADY_EXISTS {args.out}')
    rows = collect_rows(root, args.profile, task, pe)
    report = build_report(rows, args.profile, pins)
    args.out.mkdir(parents=True, exist_ok=False)
    predictions = args.out / 'observations.jsonl'
    with predictions.open('w', encoding='utf-8') as f:
        for item in rows:
            f.write(canonical(item) + '\n')
    with (args.out / 'report.json').open('w', encoding='utf-8') as f:
        f.write(json.dumps(report, sort_keys=True, indent=2, allow_nan=False) + '\n')
    protocol = {
        'schema': 'spk-theta-capacity-dev-protocol/v0',
        'purpose': 'Quantify fixed-theta representation/readout capacity, not learning.',
        'predeclare_split': SPLITS[args.profile],
        'predeclare_theta': list(THETAS),
        'predeclare_models': ['one-feature PE-output logistic', 'one-feature raw ch1-rate logistic',
                              'four-feature raw-sensor logistic', 'TRAIN class prior'],
        'predeclare_selection': 'theta chosen using only internal SELECT Brier (DEV exposed only diagnostic)',
        'source_pin_scope': EXPECTED_GIT_BLOBS,
        'previously_exposed_DEV': True,
        'no_holdout': True,
        'no_BV_update': True,
    }
    (args.out / 'protocol.json').write_text(json.dumps(protocol, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    sha_lines = []
    for filename in ('protocol.json', 'observations.jsonl', 'report.json'):
        blob = (args.out / filename).read_bytes()
        sha_lines.append(f'{sha256_bytes(blob)}  {filename}')
    (args.out / 'SHA256SUMS').write_text('\n'.join(sha_lines) + '\n', encoding='utf-8')
    print('RUN_COMPLETE__DESCRIPTIVE_POSTHOC_ONLY')
    print('OUTPUT:', args.out.resolve())
    print('CAPACITY:', canonical(report['capacity']))
    print('SELECTED_THETA_INTERNAL_ONLY:', report['selected_theta_internal_only'])
    for name in (f'theta_{report["selected_theta_internal_only"]:02d}', 'theta_06',
                 'sensor_ch1_rate', 'sensor_four_features', 'constant_train_prior'):
        s = report['scores'][name]
        print(f'{name:23s} SELECT_BRIER={s["select"]["brier"]:.6f} '
              f'EXPOSED_DEV_BRIER={s["dev_exposed"]["brier"]:.6f}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
