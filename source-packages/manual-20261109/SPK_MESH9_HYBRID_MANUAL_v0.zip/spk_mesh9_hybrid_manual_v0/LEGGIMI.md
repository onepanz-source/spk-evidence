# SPK-MESH-9-HYBRID · manuale v0

Il primo simulatore **ibrido** conta 8 isole ESP32-C6-class (64 neuroni ciascuna) e
1 isola Raspberry Pi 5-class da 1.024 neuroni, per **1.536 neuroni e 12.288
connessioni locali**. Il Pi è l'isola `I8` e si collega alla mesh preesistente
tramite I0 e I4: 14 link logici bidirezionali (28 direzioni), non una rete full
mesh. È un *riferimento di ricerca*, non firmware per Pi5 o ESP32-C6.

## Esecuzione Fedora fwork

Scarica l'archivio ZIP in `~/Scaricati`, poi:

```bash
cd ~/Scaricati
unzip SPK_MESH9_HYBRID_MANUAL_v0.zip
cd spk_mesh9_hybrid_manual_v0
bash run_spk_mesh9_hybrid_manual.sh smoke
bash run_spk_mesh9_hybrid_manual.sh full
```

Non occorre il virtualenv né NumPy, basta Python 3.10+, Git e tar/sha256sum.
Repository sorgente predefinito: `~/workspace/spk-backvalidation-v0` (puoi
specificare un altro percorso come secondo argomento). Il launcher non esegue
checkout/reset/merge/commit/push: usa un `git archive` del commit originale
pinnato `787c8fbe...` in una cartella temporanea e verifica i blob del PE e
fabric prima dell'esecuzione. Se mancano oggetti Git può eseguire un `git
fetch` di soli oggetti per recuperare il commit storico, senza modificare il
working tree. Tutti i file del pacchetto sono verificati con SHA256.

Gli output finiscono in `~/workspace/spk-manual-runs/`, ciascuno con un nome
versionato UTC e `.tar.gz` + `.tar.gz.sha256` separati. Inviami entrambi.

## Invarianti e interpretazione

- **I0–I7**: 8×64 neuroni, 512 link locali per isola, coda 256 eventi, 128
  record BV *solo riservati nel modello RAM*, nessuna scrittura BV.
- **I8 Raspberry Pi5**: 1.024 neuroni, 8.192 connessioni locali, coda 2.048
  eventi, 512 slot BV *solo nel modello RAM*. La memoria SPK stimata da layout
  simulato è 360 KiB, **non** memoria residente Python, non un bench sul Pi.
- Le sorgenti neuronali per l'ISA `ACC, CMP, EMIT, RESET` sono richiamate
  dall'originale PE `_compute_local` verificato con Git blob SHA1. Lo
  scheduler e la mesh ibrida sono **NUOVI**, non la scheduler/authority nativa.
- Link a un hop: ritardo logico 2 tick, 2 pacchetti/tick per link direzionale;
  16 pacchetti in attesa, 8 in volo. **Tutti i link con I8 condividono un
  solo budget di 2 trasmissioni/tick**: simula un singolo RCP esterno, non
  multiple radio indipendenti. I tick non rappresentano direttamente millisecondi
  o un'implementazione Thread certificata.
- Comparazione ON/OFF: stessi 360 impulsi sensoriali; la mesh influenza gli
  stati delle isole. Il report verifica ordinamento FIFO, limiti, conservazione
  dei pacchetti, replay deterministico e digest di tracce e stati.
- Le unit tests verificano anche la **regressione del simulatore 8×64**: a
  mesh OFF le otto isole piccole devono elaborare gli stessi eventi e produrre
  gli stessi contatori della versione precedente.
- La RAM stimata per ogni C6 continua a essere 54 KiB; per il Pi5 360 KiB.
  Sono ipotesi di layout *non misurate* su firmware embedded. La connettività
  reale Pi5↔Thread richiederebbe un co-processore 802.15.4 (RCP) esterno,
  ad esempio ESP32-C6 o H2 con OpenThread, su SPI/UART. Pi5 non ha radio
  IEEE 802.15.4 integrata.
- Nessun apprendimento, nessun BackValidation reale, zero scritture native P,
  nessun holdout e nessun GO scientifico. HOLD umani C0–C5/G2/dispatch/BV→P
  invariati. Il test misura solo comunicazione forward e stato.

## Una trappola interpretativa

1024 neuroni sono **allocati**, ma lo stimolo sintetico ne attiva inizialmente
solo una piccola parte. Non confondere dimensione nominale, neuroni realmente
attivi e capacità predittiva. I test futuri dovranno aggiungere utilizzazione,
variabilità dei compiti, robustezza e misure con hardware reale.

## Append-only

Nessun file preesistente del progetto viene modificato. Ogni run scrive un
nuovo output UTC. Mantieni intatti i tar.gz e lo SHA256 restituiti.
