#!/usr/bin/env bash
# Manual only: no daemon, remote mutations, merges or M/W/V execution.
set -Eeuo pipefail
export LC_ALL=C
PROFILE="${1:-smoke}"
REPO="${2:-${SPK_REPO:-$HOME/workspace/spk-backvalidation-v0}}"
case "$PROFILE" in smoke|full) ;; *) echo "USO: bash $0 [smoke|full] [percorso_repo]" >&2; exit 2;; esac
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
for cmd in git python3 tar sha256sum; do
  command -v "$cmd" >/dev/null || { echo "COMANDO_MANCANTE: $cmd" >&2; exit 3; }
done
( cd "$ROOT" && sha256sum -c CODE_SHA256SUMS ) || { echo "PACKAGE_SHA256_MISMATCH" >&2; exit 4; }
[[ -e "$REPO/.git" ]] || { echo "REPOSITORY_NOT_FOUND: $REPO" >&2; exit 3; }
MAIN="787c8fbed87c1e2e4b703e985f68ae53c81c8444"
if ! git -C "$REPO" cat-file -e "${MAIN}^{commit}" 2>/dev/null; then
  echo 'Manca il commit storico, git fetch READ-ONLY dei soli oggetti...'
  git -C "$REPO" fetch --no-tags origin "$MAIN"
fi
[[ "$(git -C "$REPO" rev-parse "${MAIN}^{commit}")" == "$MAIN" ]] || {
  echo 'ORIGINAL_COMMIT_PIN_MISMATCH' >&2; exit 4;
}
TMP="$(mktemp -d -t spk-mesh9-hybrid-XXXXXXXX)"
trap 'rm -rf -- "$TMP"' EXIT
mkdir -p "$TMP/src"
git -C "$REPO" archive --format=tar "$MAIN" \
  spk_architecture_v1/pe_execution_v1b.py \
  spk_architecture_v1/pe_fabric_v1a.py | tar -xf - -C "$TMP/src"

echo 'Verifica sorgenti originali e SELFTEST con PE + oracolo locale...'
( cd "$ROOT" && python3 spk_mesh9_hybrid_ref_v0.py --source-root "$TMP/src" --profile selftest )
echo 'Test indipendenti del simulatore ibrido (11 casi)...'
( cd "$ROOT" && python3 -m unittest -v test_spk_mesh9_hybrid_ref_v0 )
echo 'Verifica regressioni originali 8x64 (8 casi)...'
( cd "$ROOT" && python3 -m unittest -v test_spk_mesh8x64_ref_v0 )
OUTPUT_BASE="${SPK_MESH_OUTPUT_BASE:-$HOME/workspace/spk-manual-runs}"
mkdir -p "$OUTPUT_BASE"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$OUTPUT_BASE/${STAMP}-mesh9hybrid-${PROFILE}"
[[ ! -e "$OUT" && ! -e "$OUT.tar.gz" ]] || { echo "NONOVERWRITE_FILE_EXISTS: $OUT" >&2; exit 5; }
echo "SPK-MESH-9 HYBRID manual profile=$PROFILE original_PE=$MAIN"
echo '8 ESP32-C6-class 64 neurons + Raspberry Pi5-class 1024; external 802.15.4 RCP simulated.'
echo 'Research only; no BV, no learning, no original P writes, no holdout, no GitHub writes.'
( cd "$ROOT" && python3 spk_mesh9_hybrid_ref_v0.py --source-root "$TMP/src" \
 --profile "$PROFILE" --out "$OUT" ) | tee "$TMP/console.log"
cp "$TMP/console.log" "$OUT/console.log"
( cd "$OUT" && sha256sum console.log >> SHA256SUMS && sha256sum -c SHA256SUMS )
ARCHIVE="$OUT.tar.gz"
tar -czf "$ARCHIVE" -C "$OUTPUT_BASE" "$(basename "$OUT")"
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"
echo "PACCHETTO_EVIDENZE: $ARCHIVE"
echo -n 'SHA256_PACCHETTO: '; sha256sum "$ARCHIVE" | awk '{print $1}'
echo 'Carica .tar.gz e .tar.gz.sha256 in ChatGPT per audit indipendente e pubblicazione GitHub.'
