#!/usr/bin/env bash
# SPK DSEC real DEV events -> original pinned A1b PE local ISA / 9-island mesh.
# Fedora fwork manual invocation only; NEVER alters source checkout or commits.
set -Eeuo pipefail
export LC_ALL=C
export PYTHONDONTWRITEBYTECODE=1
PROFILE="${1:-inventory}"
REPO="${2:-${SPK_REPO:-$HOME/workspace/spk-backvalidation-v0}}"
case "$PROFILE" in inventory|smoke|full) ;; *) echo 'USO: bash run_spk_dsec_mesh9_manual.sh [inventory|smoke|full] [repo]' >&2; exit 2;; esac
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
for cmd in python3 git tar sha256sum; do
  command -v "$cmd" >/dev/null || { echo "COMANDO_MANCANTE: $cmd" >&2; exit 3; }
done
( cd "$ROOT" && sha256sum -c CODE_SHA256SUMS ) || { echo 'SOURCE_PACKAGE_SHA256_MISMATCH' >&2; exit 4; }
EV="${SPK_DSEC_EVENTS_ZIP:-$HOME/Scaricati/train_events.zip}"
FLOW="${SPK_DSEC_FLOW_ZIP:-$HOME/Scaricati/train_optical_flow.zip}"
INTAKE="${SPK_DSEC_INTAKE:-$HOME/workspace/spk-dsec-intake}"
[[ -f "$EV" && -f "$FLOW" ]] || { echo "DSEC_ZIPS_MISSING: $EV $FLOW" >&2; exit 3; }
echo "DSEC_DEV_SOURCE: $EV + $FLOW"
echo "SOURCE_ERRATA: v0p1 DSEC comma-separated official forward_timestamps.txt supported"
echo 'FENCE: inspect ZIP central-directory only; only DEV thun_00_a source content; no flow GT PNG.'
( cd "$ROOT" && python3 spk_dsec_mesh9_dev_v0.py inventory --events-zip "$EV" --flow-zip "$FLOW" )
if [[ "$PROFILE" == inventory ]]; then
  echo 'INVENTORY_COMPLETE_NO_EVENT_OR_GT_BYTES_READ'
  exit 0
fi
python3 -c 'import numpy, h5py, hdf5plugin' || {
  echo 'MISSING_DEP: attiva il virtualenv e installa: python -m pip install numpy h5py hdf5plugin' >&2
  exit 3
}
( cd "$ROOT" && python3 -m unittest -v test_spk_dsec_mesh9_dev_v0 \
  test_spk_mesh9_ethgateway_ref_v1 test_spk_mesh9_hybrid_ref_v0 test_spk_mesh8x64_ref_v0 )
[[ -e "$REPO/.git" ]] || { echo "SPK_REPO_MISSING: $REPO" >&2; exit 3; }
MAIN=787c8fbed87c1e2e4b703e985f68ae53c81c8444
if ! git -C "$REPO" cat-file -e "${MAIN}^{commit}" 2>/dev/null; then
  echo 'REPO SOURCE PIN MISSING: read-only git fetch of exact historical commit...'
  git -C "$REPO" fetch --no-tags origin "$MAIN"
fi
[[ "$(git -C "$REPO" rev-parse "${MAIN}^{commit}")" == "$MAIN" ]] || {
  echo 'ORIGINAL_PE_COMMIT_MISMATCH' >&2; exit 4;
}
TMP="$(mktemp -d -t spk-dsec-mesh9-XXXXXXXX)"
trap 'rm -rf -- "$TMP"' EXIT
mkdir -p "$TMP/src"
git -C "$REPO" archive --format=tar "$MAIN" \
 spk_architecture_v1/pe_execution_v1b.py \
 spk_architecture_v1/pe_fabric_v1a.py | tar -xf - -C "$TMP/src"
# Prove original pinned _compute_local equals our independently coded mirror.
echo 'SELFTEST ORIGINALE PE A1b vs oracolo locale e regressioni del gateway...'
( cd "$ROOT" && python3 spk_mesh9_ethgateway_ref_v1.py --source-root "$TMP/src" --profile selftest )
OUTPUT_BASE="${SPK_MESH_OUTPUT_BASE:-$HOME/workspace/spk-manual-runs}"
mkdir -p "$OUTPUT_BASE"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$OUTPUT_BASE/${STAMP}-dsec-mesh9-dev-${PROFILE}"
[[ ! -e "$OUT" && ! -e "$OUT.tar.gz" ]] || { echo "NONOVERWRITE $OUT" >&2; exit 5; }
echo "START_DSEC_REAL_DEV profile=$PROFILE first-4-dev-flow-windows, sensor pixels FROM EVENTS only"
echo 'NO_FLOW_GT_PNG_READ, NO_VAL, NO_BLIND, NO_BV, NO_LEARNING, NO_P_WRITES'
( cd "$ROOT" && python3 -u spk_dsec_mesh9_dev_v0.py "$PROFILE" \
 --source-root "$TMP/src" --events-zip "$EV" --flow-zip "$FLOW" \
 --intake "$INTAKE" --out "$OUT" ) | tee "$TMP/console.log"
cp "$TMP/console.log" "$OUT/console.log"
( cd "$OUT" && sha256sum console.log >> SHA256SUMS && sha256sum -c SHA256SUMS )
ARCHIVE="$OUT.tar.gz"
tar -czf "$ARCHIVE" -C "$OUTPUT_BASE" "$(basename "$OUT")"
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"
echo "PACCHETTO_EVIDENZE: $ARCHIVE"
echo -n 'SHA256_PACCHETTO: '; sha256sum "$ARCHIVE" | awk '{print $1}'
echo 'Carica .tar.gz + .tar.gz.sha256 in chat per audit indipendente CIAT.'
