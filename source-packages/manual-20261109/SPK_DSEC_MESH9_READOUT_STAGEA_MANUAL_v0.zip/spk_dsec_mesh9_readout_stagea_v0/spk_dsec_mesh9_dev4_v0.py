#!/usr/bin/env python3
"""Manual DSEC development-only four-window recurrent-load test.

Preserves original frozen PE local instruction semantics; uses source-based
bounded transport research simulator; no flow target pixels at any stage.
Fanout 4 is POST-HOC SELECTED based on pair0 loss analysis, and fanout 2 is a
predeclared lower-activity control. This cannot establish generalization.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import hashlib
import json
import sys

import spk_dsec_mesh9_dev_v0 as dsec
import spk_dsec_mesh9_fanout_diag_v0 as diag
import spk_mesh9_hybrid_ref_v0 as frozen_ref
import spk_mesh9_ethgateway_ref_v1 as mesh

SCHEMA='spk-dsec-mesh9-fanout24-dev4-stagea/v0'
PAIR_INDICES=(0,1,2,3)
FANOUTS=(2,4)
# From user-uploaded prior manual pair0 fanout diagnostic, SOURCE-LOCKED.
PAIR0_ANCHOR={
 (2,False): ('1b074f590e04a260001114bc8f9ab1fdaace160059d09acecffc874e42781def','cf6bcf06ce6536d4a15b4b0af029e3d458d5c7ce54d8cdfb6b7e3789eb11f37f'),
 (2,True): ('98f7e713b3becd5ca28518261d177597e3d3979fb45aa9edd415f529346bbcc2','a437ee59ba53c83d722f5522d5b27d0891ff6212e84c93ef79f83d119b8ac51c'),
 (4,False): ('e5b6261c5cc560306a8cff442e0077c385c31df57a53f9f0a7820d37cf560af3','c33eaf2827553c7f0785eb6f35e12f78657ddbc2df848d2992cf365f48f7e565'),
 (4,True): ('733f65ff81539bcd2a04ebeb78fa76bc213e23f03b88581857258b8b192ff195','d59c72bfffbca10a3dec806431ba35fe003a8d29060857090fe5bf11056f1d13'),
}

def summarize(result,history, fanout, enabled, pair_index, input_count):
    st=result['stats']
    s={
      'pair_index':pair_index,'fanout':fanout,'mesh_enabled':enabled,
      'sensor_created':st.get('external_created',0),
      'sensor_admitted':st.get('external_admitted',0),
      'sensor_rejected':st.get('external_rejected',0),
      'events_processed':st.get('events_processed',0),
      'emissions':st.get('emissions',0),
      'local_edges_created':st.get('local_edge_events_created',0),
      'local_edges_rejected':st.get('local_edge_events_rejected',0),
      'packets_created':st.get('packets_created',0),
      'packets_arrived':st.get('packets_arrived_at_destination',0),
      'mesh_neuron_admitted':st.get('mesh_neuron_admitted',0),
      'mesh_neuron_rejected':st.get('mesh_neuron_rejected',0),
      'packets_link_dropped':st.get('packets_dropped_link_queue',0),
      'packets_queued_at_horizon':st.get('link_queued_at_horizon',0),
      'packets_inflight_at_horizon':st.get('link_flight_at_horizon',0),
      'tick_budget_drops':st.get('dropped_tick_budget',0),
      'active_neurons':result['active_neurons_processed_total'],
      'active_neurons_by_island':result['active_neurons_processed_per_island'],
      'queue_peaks_by_island':[x['queue_peak'] for x in result['per_island']],
      'local_queue_drops_by_island':[x['dropped_queue'] for x in result['per_island']],
      'horizon_drops_by_island':[x['dropped_horizon'] for x in result['per_island']],
      'state_sha256':result['state_sha256'],
      'trace_sha256':result['trace_sha256'],
      'tick_telemetry_sha256':dsec.digest(history),
    }
    if s['sensor_created']!=input_count or s['sensor_admitted']+s['sensor_rejected']!=input_count:
        raise RuntimeError('SENSOR_INPUT_COUNT_DIVERGED')
    if s['local_edges_created']!=fanout*s['emissions']:
        raise RuntimeError('LOCAL_EDGE_FANOUT_NONCONSERVATION')
    if s['packets_created']!=(s['packets_arrived']+s['packets_link_dropped']+
        s['packets_queued_at_horizon']+s['packets_inflight_at_horizon']):
        raise RuntimeError('MESH_CONSERVATION_FAILURE')
    if s['packets_arrived']!=s['mesh_neuron_admitted']+s['mesh_neuron_rejected']:
        raise RuntimeError('MESH_DELIVERY_ADMISSION_MISMATCH')
    if sum(x['external_admitted'] for x in history)!=s['sensor_admitted']:
        raise RuntimeError('TICK_INGRESS_INCONSISTENT')
    if sum(x['processed'] for x in history)!=s['events_processed']:
        raise RuntimeError('TICK_PROCESSING_INCONSISTENT')
    return s


def run_four_pairs(compute,h5,rect,pairs):
    cfg=mesh.Config(horizon=64,stimulus_last_tick=24,max_processed_events=1_000_000)
    result=[];all_ticks=[];source=[]
    if len(pairs)!=4:raise RuntimeError('DEV_PAIR_COUNT_NOT_FOUR')
    for pair in PAIR_INDICES:
        c6,pi,raw=dsec.dataset_bins(h5,rect,pairs[pair])
        stim,enc=dsec.encode_inputs(c6,pi)
        if pair==0 and (enc['sensor_input_sha256']!=diag.ANCHOR_INPUT_SHA256 or
                        enc['sensor_spike_total']!=diag.ANCHOR_SENSOR_PULSES):
            raise RuntimeError('PAIR0_FROZEN_ORIGINAL_DSEC_ENCODER_DRIFT')
        source.append({'pair_index':pair,'raw_event_count':raw['raw_events'],
            'rectified_valid_events':raw['rectified_valid_events'],
            'rectified_oob_events':raw['rectified_out_of_bounds'],
            'time_window_us':raw['event_window_us'],
            'source_h5_range':raw['h5_index_range'],
            'sensor_pulses':enc['sensor_spike_total'],
            'sensor_input_sha256':enc['sensor_input_sha256'],
            'per_island_sensor_pulses':enc['per_island_input_pulses']})
        for f in FANOUTS:
            for enabled in (False,True):
                out,history=diag.run_arm(compute,cfg,stim,f,enabled)
                if pair==0:
                    expected=PAIR0_ANCHOR.get((f,enabled))
                    if expected and expected[0] and (out['state_sha256'],out['trace_sha256'])!=expected:
                        raise RuntimeError('PAIR0_PRIOR_DIAGNOSTIC_ANCHOR_MISMATCH')
                s=summarize(out,history,f,enabled,pair,enc['sensor_spike_total'])
                # Deterministic second run for the mesh-active reference arm.
                if enabled:
                    repeated,_=diag.run_arm(compute,cfg,stim,f,enabled)
                    if dsec.canonical(out)!=dsec.canonical(repeated):
                        raise RuntimeError('PER_PAIR_REPLAY_MISMATCH')
                result.append(s)
                tag=f'pair{pair}_fanout{f}_mesh{int(enabled)}'
                all_ticks.extend({'arm':tag,**t} for t in history)
                print('ARM',tag,'RAW',raw['raw_events'],'SPK',s['sensor_created'],
                      'INPUT_ADMITTED',s['sensor_admitted'],'INPUT_REJECTED',s['sensor_rejected'],
                      'ACTIVE',s['active_neurons'],'PACKETS_ACCEPTED',s['mesh_neuron_admitted'],
                      'PACKETS_CREATED',s['packets_created'],flush=True)
    return source,result,all_ticks


def run(args):
    import h5py
    import hdf5plugin  # noqa: F401; real H5 compression filters
    out=Path(args.out)
    if out.exists():raise RuntimeError('OUTPUT_EXISTS_NO_OVERWRITE')
    if args.source_root is None:raise RuntimeError('PINNED_ORIGINAL_PE_SOURCE_REQUIRED')
    compute=frozen_ref.load_compute(args.source_root)
    events=Path(args.events_zip).expanduser()
    flow=Path(args.flow_zip).expanduser()
    dsec.inventory(events,flow)   # reserved splits only filenames in zip central directory
    sources=dsec.prepare_dev(events,flow,Path(args.intake).expanduser())
    pairs=dsec.pair_times(Path(sources['flow/forward_timestamps.txt']['path']))
    with h5py.File(sources['events/left/events.h5']['path'],'r') as h5, \
         h5py.File(sources['events/left/rectify_map.h5']['path'],'r') as rm:
        source,runs,ticks=run_four_pairs(compute,h5,rm['rectify_map'][:],pairs)
    if len(runs)!=16 or len(ticks)!=16*64:
        raise RuntimeError('INCOMPLETE_DEV4_ARMS_OR_TICK_TELEMETRY')
    report={
        'schema':SCHEMA,'scope':'DSEC_DEV_THUN_00_A_FIRST4_FORWARD_PAIRS_ONLY_NO_FLOW_GT',
        'source_original_pe_main':frozen_ref.MAIN,
        'source_original_pe_blobs':frozen_ref.PINS,
        'source_dsec_pins':dsec.PINS,
        'selected_fanout':4,'selection_origin':'POST_HOC_FANOUT_DIAG_ON_DEV_PAIR0',
        'comparison_fanout':2,'same_sensor_input_mesh_off_on_per_pair':True,
        'source_pairs':source,'runs':runs,
        'tick_telemetry_records':len(ticks),
        'tick_telemetry_canonical_sha256':dsec.digest(ticks),
        'gt_pixels_read':False,'reserved_validation_blind_read':False,
        'native_learning':False,'bv_writes':0,'original_P_writes':0,
        'no_information_gain_or_prediction_claim':True,
        'episode_reset_between_pairs':True,
        'not_an_independent_validation':True,
        'logical_ticks_not_wallclock':True,
        'verdict':'DSEC_MESH9_FANOUT24_DEV4_LOAD_RESEARCH_ONLY_SCIENTIFIC_HOLD',
    }
    report['canonical_sha256']=dsec.digest(report)
    protocol={
        'schema':SCHEMA+'/protocol',
        'original_main_commit':frozen_ref.MAIN,'original_pe_blobs':frozen_ref.PINS,
        'dsec_member_sha256':dsec.PINS,
        'dataset_archives':['train_events.zip','train_optical_flow.zip'],
        'locked_scene':'thun_00_a','dev_pairs':[0,1,2,3],
        'flow_ground_truth_png_read':False,'validation_blind_payload_read':False,
        'time_bins':dsec.TIME_BINS,'fixed_c6_topk':dsec.C6_TOPK,
        'fixed_pi_topk':dsec.PI_TOPK,'pulse_count_thresholds':[1,40,160],
        'network_islands':[64]*8+[1024],
        'fanout_enabled':[2,4],'fanout_order':list(frozen_ref.EDGE_OFFSETS),
        'mesh_enabled':[False,True],
        'memory_queuing_uncertainty':'abstract logical tick budgets, not ESP-IDF memory or RF throughput',
        'pair0_source_input_sha256':diag.ANCHOR_INPUT_SHA256,
        'pair0_manual_prior_diagnostic_sha256':'0f5b9b71806956c212226da39d68a84f894bdb3c875b756a34673f65d7ce247b',
        'prior_archive_sha256':'a1d60b4ad41900db7793bf3f861fa9e012e78a8aaa98dd644b2a9541035c20ed',
        'fanout4_selected_posthoc_using_pair0':True,
        'no_scientific_go':True,'no_native_learning':True,'original_p_writes':0,
    }
    out.mkdir(parents=True)
    (out/'report.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    (out/'protocol.json').write_text(json.dumps(protocol,sort_keys=True,indent=2)+'\n')
    (out/'tick_telemetry.jsonl').write_text(''.join(dsec.canonical(x)+'\n' for x in ticks))
    (out/'SHA256SUMS').write_text(''.join(f'{dsec.hash_file(out/n)}  {n}\n'
                                         for n in ('report.json','protocol.json','tick_telemetry.jsonl')))
    print('RUN_COMPLETE_DEV4_FANOUT24_RESEARCH_SCIENTIFIC_HOLD')
    print('REPORT_SHA256',report['canonical_sha256'])
    print('TICKS_SHA256',report['tick_telemetry_canonical_sha256'])
    print('OUTPUT',out)
    return 0


def cli():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--events-zip',default='~/Scaricati/train_events.zip')
    parser.add_argument('--flow-zip',default='~/Scaricati/train_optical_flow.zip')
    parser.add_argument('--intake',default='~/workspace/spk-dsec-intake')
    parser.add_argument('--source-root',required=True,type=Path)
    parser.add_argument('--out',required=True,type=Path)
    return run(parser.parse_args())

if __name__=='__main__':sys.exit(cli())
