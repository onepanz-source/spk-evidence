#!/usr/bin/env bash
# User-operated Fedora fwork, DSEC DEV only. Stage A: NEVER flow GT PNG.
set -Eeuo pipefail
export LC_ALL=C
export PYTHONDONTWRITEBYTECODE=1
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO="${1:-${SPK_REPO:-$HOME/workspace/spk-backvalidation-v0}}"
for cmd in python3 git tar sha256sum; do
  command -v "$cmd" >/dev/null || { echo "MISSING_REQUIRED_COMMAND: $cmd" >&2; exit 3; }
done
( cd "$BASE" && sha256sum -c CODE_SHA256SUMS ) || { echo 'SOURCE_MANIFEST_MISMATCH' >&2; exit 4; }
python3 -c 'import numpy, h5py, hdf5plugin' || { echo 'ACTIVATE_DSEC_VENV (numpy h5py hdf5plugin)' >&2; exit 3; }
EVENTS="${SPK_DSEC_EVENTS_ZIP:-$HOME/Scaricati/train_events.zip}"
FLOW="${SPK_DSEC_FLOW_ZIP:-$HOME/Scaricati/train_optical_flow.zip}"
INTAKE="${SPK_DSEC_INTAKE:-$HOME/workspace/spk-dsec-intake}"
[[ -f "$EVENTS" && -f "$FLOW" ]] || { echo 'ORIGINAL_DSEC_TRAIN_ZIPS_NOT_FOUND' >&2; exit 3; }
[[ -e "$REPO/.git" ]] || { echo "REPO_NOT_FOUND: $REPO" >&2; exit 3; }
( cd "$BASE" && python3 -m unittest -q \
    test_spk_dsec_mesh9_readout_stagea_v0 \
    test_spk_dsec_mesh9_dev4_v0 \
    test_spk_dsec_mesh9_fanout_diag_v0 \
    test_spk_dsec_mesh9_dev_v0 \
    test_spk_mesh9_ethgateway_ref_v1 \
    test_spk_mesh9_hybrid_ref_v0 \
    test_spk_mesh8x64_ref_v0 )
MAIN=787c8fbed87c1e2e4b703e985f68ae53c81c8444
if ! git -C "$REPO" cat-file -e "${MAIN}^{commit}" 2>/dev/null; then
  echo 'PINNED_ORIGINAL_NOT_PRESENT_READONLY_FETCH'
  git -C "$REPO" fetch --no-tags origin "$MAIN"
fi
[[ "$(git -C "$REPO" rev-parse "${MAIN}^{commit}")" == "$MAIN" ]] || { echo 'PINNED_ORIGINAL_MAIN_DRIFT' >&2; exit 4; }
TMP="$(mktemp -d -t spk-dsec-readout-XXXXXXXX)"
trap 'rm -rf -- "$TMP"' EXIT
mkdir -p "$TMP/original"
git -C "$REPO" archive --format=tar "$MAIN" \
  spk_architecture_v1/pe_execution_v1b.py \
  spk_architecture_v1/pe_fabric_v1a.py | tar -xf - -C "$TMP/original"
# Actual PE local ISA mirror test against ORIGINAL PEs in isolated source snapshot.
( cd "$BASE" && python3 spk_mesh9_ethgateway_ref_v1.py --source-root "$TMP/original" --profile selftest )
OUT_BASE="${SPK_MESH_OUTPUT_BASE:-$HOME/workspace/spk-manual-runs}"
mkdir -p "$OUT_BASE"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$OUT_BASE/${STAMP}-dsec-mesh9-readout-stagea"
[[ ! -e "$OUT" && ! -e "$OUT.tar.gz" ]] || { echo 'OUTPUT_EXISTS_NO_OVERWRITE' >&2; exit 5; }
echo 'STAGE A: ONLY DEV THUN_00_A PAIRS 0..3. ZERO FLOW GT PIXELS; ZERO VALIDATION/BLIND PAYLOAD.'
echo 'Observer must match all 16 archived source state/trace anchors; no target scoring.'
( cd "$BASE" && python3 -u spk_dsec_mesh9_readout_stagea_v0.py \
  --events-zip "$EVENTS" --flow-zip "$FLOW" --intake "$INTAKE" \
  --source-root "$TMP/original" --anchors "$BASE/baseline_anchors.json" \
  --out "$OUT" ) | tee "$TMP/console.log"
cp "$TMP/console.log" "$OUT/console.log"
( cd "$OUT" && sha256sum console.log >> SHA256SUMS && sha256sum -c SHA256SUMS )
# Do not claim the run is a GH-frozen Stage A lock until CIAT audits and commits the output.
tar -czf "$OUT.tar.gz" -C "$OUT_BASE" "$(basename "$OUT")"
sha256sum "$OUT.tar.gz" > "$OUT.tar.gz.sha256"
echo "PACCHETTO_EVIDENZE: $OUT.tar.gz"
echo -n 'SHA256_PACCHETTO: '; sha256sum "$OUT.tar.gz" | awk '{print $1}'
echo 'Upload both .tar.gz and its .sha256; no DEV GT reading until CIAT Stage A lock.'
