#!/usr/bin/env python3
"""SCI-DSEC MESH9 Stage A: passive original-PE emission observer + target-free flow lock.

No ground-truth PNG bytes, reserved sequences, native learning, BV, or P writes.
All flow vectors in this Stage A are *EXTERNAL* fixed block-matching hypotheses.
No EPE/accuracy estimate is calculated. All 16 simulation arms are hash-anchored
and compared with a separate non-observed execution (zero observer interference).
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

import spk_dsec_mesh9_dev_v0 as dsec
import spk_dsec_mesh9_fanout_diag_v0 as diag
import spk_dsec_mesh9_dev4_v0 as prev
import spk_mesh9_ethgateway_ref_v1 as mesh
import spk_mesh9_hybrid_ref_v0 as v0

SCHEMA = 'spk-dsec-mesh9-readout-stagea-targetfree/v0'
FANOUTS = (2, 4)
PAIR_IDS = (0, 1, 2, 3)
BIN_CUTOFF = 10  # chronological half1 ticks 1..10, half2 ticks 11..20
MATCH_RADIUS = 2
PATCH_RADIUS = 1
TIME_CENTER_TO_FLOW_SCALE = 2
ORIGINAL_DEV4_REPORT = '686945b524d7aee0127425bd8ebc767df6ac7188775b10ffa4696a9182128123'


def anchor_key(pair, fanout, mesh_on):
    return (pair, fanout, bool(mesh_on))


def read_anchors(path):
    a=json.loads(Path(path).read_text())
    if (a.get('source_report_canonical_sha256') != ORIGINAL_DEV4_REPORT
            or len(a.get('arms', [])) != 16 or len(a.get('input_pairs', [])) != 4):
        raise RuntimeError('PRIOR_DEV4_BASELINE_ANCHOR_INVALID')
    lookup={}
    for row in a['arms']:
        key=anchor_key(row['pair'],row['fanout'],row['mesh'])
        if key in lookup: raise RuntimeError('BASELINE_DUPLICATE_ARM')
        lookup[key]=row
    if set(lookup)!={anchor_key(p,f,m) for p in PAIR_IDS for f in FANOUTS for m in (False,True)}:
        raise RuntimeError('BASELINE_ARMS_INCOMPLETE')
    for j,p in enumerate(a['input_pairs']):
        if p['pair']!=j or len(p['sensor_input_sha256'])!=64:
            raise RuntimeError('BASELINE_INPUT_PAIR_INVALID')
    return a, lookup


class PassiveEmissionSimulation(diag.DiagnosticSimulation):
    """Observe only the exact logged original PE emission, after source.log().

    Do NOT alter the log or original PE compute. The source's normal SHA256 trace
    is constructed first and is compared byte-semantically to the baseline run.
    """
    def __init__(self, compute, cfg, enabled, stimuli):
        self.emission_rows=[]
        super().__init__(compute,cfg,enabled,stimuli)

    def log(self, row):
        super().log(row)
        if isinstance(row, list) and row and row[0]=='emit':
            if len(row)!=5:
                raise RuntimeError('EMISSION_RECORD_SCHEMA_DRIFT')
            _,tick,iid,neuron,eid=row
            if not (type(tick) is int and 0<=tick<self.cfg.horizon and
                    type(iid) is int and 0<=iid<9 and type(neuron) is int and
                    0<=neuron<(1024 if iid==8 else 64) and type(eid) is int):
                raise RuntimeError('EMISSION_RECORD_INVALID')
            self.emission_rows.append((tick,iid,neuron,eid))


def run_observed_arm(compute,cfg,stimuli,fanout,mesh_on,baseline_row=None):
    # Use the EXACT route-enable mask from #215 / #216, restoration guaranteed.
    with diag.masked_local_routes(fanout):
        sim=PassiveEmissionSimulation(compute,cfg,mesh_on,stimuli)
        out=sim.run()
    # Separately run the same frozen scheduler WITHOUT the observer. This checks
    # every state, event trace hash, packet counter, and timeline, not just totals.
    reference, history=diag.run_arm(compute,cfg,stimuli,fanout,mesh_on)
    if dsec.canonical(out)!=dsec.canonical(reference):
        raise RuntimeError('PASSIVE_OBSERVER_INTERFERENCE_FULL_RESULT_MISMATCH')
    if dsec.canonical(sim.tick_audit)!=dsec.canonical(history):
        raise RuntimeError('PASSIVE_OBSERVER_INTERFERENCE_TICK_TIMELINE_MISMATCH')
    if len(sim.emission_rows)!=out['stats'].get('emissions',0):
        raise RuntimeError('EMISSION_CAPTURE_LOST_OR_DUPLICATED')
    for j in range(1,len(sim.emission_rows)):
        if sim.emission_rows[j][3]<=sim.emission_rows[j-1][3]:
            raise RuntimeError('EMISSION_IDS_OUT_OF_ORDER')
    if baseline_row:
        for key in ('state_sha256','trace_sha256'):
            if out[key]!=baseline_row[key]:
                raise RuntimeError(f'PRIOR_DEV4_{key.upper()}_MISMATCH')
        if out['stats'].get('emissions',0)!=baseline_row['emissions'] or out['stats']['events_processed']!=baseline_row['events_processed']:
            raise RuntimeError('PRIOR_DEV4_COUNTER_MISMATCH')
    return out,tuple(sim.emission_rows),sim.tick_audit


def source_pulse_grids(stimuli):
    import numpy as np
    pi=np.zeros((2,16,32,2),dtype=np.float64)
    c6=np.zeros((2,16,16,2),dtype=np.float64)
    for tick,iid,n,count in stimuli:
        if not 1<=tick<=20:raise RuntimeError('SOURCE_TICK_OUTSIDE_FIRST20')
        half=int(tick>BIN_CUTOFF)
        if iid==8:
            x=n//32; y=(n%32)//2;pol=n%2
            pi[half,y,x,pol]+=count
        else:
            x=iid*2+n//32;y=(n%32)//2;pol=n%2
            c6[half,y,x,pol]+=count
    return pi,c6


def observed_emission_grids(emissions):
    import numpy as np
    pi=np.zeros((2,16,32,2),dtype=np.float64)
    c6=np.zeros((2,16,16,2),dtype=np.float64)
    early_count=0
    for tick,iid,n,eid in emissions:
        if not 1<=tick<=20:continue   # no post-window emissions in the decoder
        early_count+=1
        half=int(tick>BIN_CUTOFF)
        if iid==8:
            x=n//32;y=(n%32)//2;pol=n%2
            pi[half,y,x,pol]+=1
        else:
            x=iid*2+n//32;y=(n%32)//2;pol=n%2
            c6[half,y,x,pol]+=1
    return pi,c6,early_count


def raw_pi_grid(pi_bins):
    import numpy as np
    arr=np.asarray(pi_bins,dtype=np.float64)
    if arr.shape!=(20,1024) or (arr<0).any():
        raise RuntimeError('SOURCE_PI_RAW_GRID_SHAPE_OR_SIGN')
    return np.stack((arr[:10].sum(axis=0),arr[10:20].sum(axis=0))).reshape(2,32,16,2).transpose(0,2,1,3)


def decode_fixed_half_match(two_halves, cell_x, cell_y):
    """External 3x3 SSE; dx,dy in {-2..+2}; 2x extrapolation 50ms to ~100ms.

    Compare source (first 50ms) patch to later (second 50ms) moved patch.
    Source/target near borders are assigned zero. No GT used in any call.
    """
    import numpy as np
    x=np.asarray(two_halves,dtype=np.float64)
    if x.ndim!=4 or x.shape[0]!=2 or x.shape[-1]!=2:
        raise ValueError('INVALID_HALF_FEATURE_GRID')
    _,height,width,_=x.shape
    if height<8 or width<8 or cell_x<=0 or cell_y<=0 or not np.all(np.isfinite(x)) or (x<0).any():
        raise ValueError('INVALID_FEATURE_RANGE')
    a,b=np.log1p(x[0]),np.log1p(x[1])  # fixed identical transform for all methods
    pred=np.zeros((height,width,2),dtype=np.int32)
    # The required footprint is 3x3 with candidate +/-2 shifts, so 3-cell
    # border (not 2) cannot be scored without clipped patch asymmetries.
    margin=PATCH_RADIUS+MATCH_RADIUS
    cy0,cy1=margin,height-margin
    cx0,cx1=margin,width-margin
    ah=a[cy0:cy1,cx0:cx1,:]
    # All empty source neighborhoods receive literal zero (not arbitrary dx).
    source_power=np.zeros((cy1-cy0,cx1-cx0),dtype=np.float64)
    for sy in range(-PATCH_RADIUS,PATCH_RADIUS+1):
        for sx in range(-PATCH_RADIUS,PATCH_RADIUS+1):
            source_power+=a[cy0+sy:cy1+sy,cx0+sx:cx1+sx,:].sum(axis=-1)
    eligible=(source_power>0)
    best=np.full(eligible.shape,np.inf,dtype=np.float64)
    # Candidate tie-break lexicographic: (SSE, |dx|+|dy|, dy, dx).
    # Evaluate in precisely that order so equals keep the first incumbent.
    choices=sorted(((dx,dy) for dy in range(-MATCH_RADIUS,MATCH_RADIUS+1)
                         for dx in range(-MATCH_RADIUS,MATCH_RADIUS+1)),
                   key=lambda z:(abs(z[0])+abs(z[1]),z[1],z[0]))
    for dx,dy in choices:
        sse=np.zeros_like(best)
        for sy in range(-PATCH_RADIUS,PATCH_RADIUS+1):
            for sx in range(-PATCH_RADIUS,PATCH_RADIUS+1):
                lhs=a[cy0+sy:cy1+sy,cx0+sx:cx1+sx,:]
                rhs=b[cy0+sy+dy:cy1+sy+dy,cx0+sx+dx:cx1+sx+dx,:]
                diff=lhs-rhs
                sse+=np.sum(diff*diff,axis=-1)
        better=eligible & (sse < best)
        # If two finite SSE values are equal (or exact all-zeros), the initial
        # iteration order defines the fixed tie-breaking preference.
        sub=pred[cy0:cy1,cx0:cx1,:]
        sub[better,0]=dx*cell_x*TIME_CENTER_TO_FLOW_SCALE
        sub[better,1]=dy*cell_y*TIME_CENTER_TO_FLOW_SCALE
        best[better]=sse[better]
    if np.any(pred%1 !=0):raise AssertionError('NONINTEGER_COARSE_FLOW')
    return pred


def make_prediction(label,features,cell_x,cell_y):
    import numpy as np
    src=np.asarray(features)
    out=decode_fixed_half_match(src,cell_x,cell_y)
    h,w=out.shape[:2]
    field=out.reshape(-1,2).tolist()
    return {'method':label,'grid_width':w,'grid_height':h,'cell_x_px':cell_x,'cell_y_px':cell_y,
            'forward_flow_uv_px':field,'flow_sha256':dsec.digest(field),
            'half_counts':[int(src[0].sum()),int(src[1].sum())],
            'nonzero_flow_cells':int(np.count_nonzero(np.any(out!=0,axis=2)))}


def targetfree_predictions(c6,pi,stimuli,emissions_by_arm):
    import numpy as np
    pi_pulses,c6_pulses=source_pulse_grids(stimuli)
    maps=[make_prediction('PI_RAW_LOG_COUNT',raw_pi_grid(pi),20,30),
          make_prediction('PI_TOPK_PULSE_COUNT',pi_pulses,20,30),
          make_prediction('C6_TOPK_PULSE_COUNT',c6_pulses,40,30)]
    zero=np.zeros((16,32,2),dtype=np.int32).reshape(-1,2).tolist()
    maps.append({'method':'ZERO_FLOW_PI','grid_width':32,'grid_height':16,'cell_x_px':20,'cell_y_px':30,
                 'forward_flow_uv_px':zero,'flow_sha256':dsec.digest(zero),
                 'half_counts':[0,0],'nonzero_flow_cells':0})
    counts={}
    for f in FANOUTS:
        for on in (False,True):
            key=(f,on)
            pi_features,c6_features,within=observed_emission_grids(emissions_by_arm[key])
            counts[f'F{f}_M{int(on)}']={
                 'all_emissions':len(emissions_by_arm[key]),
                 'within_input_time_window_emissions':within,
                 'pi_source_window_emissions':int(pi_features.sum()),
                 'c6_source_window_emissions':int(c6_features.sum())}
            maps.append(make_prediction(f'PI_PE_F{f}_M{int(on)}',pi_features,20,30))
            maps.append(make_prediction(f'C6_PE_F{f}_M{int(on)}',c6_features,40,30))
    if len(maps)!=12 or len({m['method'] for m in maps})!=12:
        raise RuntimeError('PREDICTION_METHOD_SET_DRIFT')
    return maps,counts


def run_four(compute,h5,rect,pairs,anchors):
    cfg=mesh.Config(horizon=64,stimulus_last_tick=24,max_processed_events=1_000_000)
    lookup={anchor_key(row['pair'],row['fanout'],row['mesh']):row for row in anchors['arms']}
    source=[];projections=[];all_emits=[];all_predictions=[]; all_events=[]
    for pair in PAIR_IDS:
        c6,pi,raw=dsec.dataset_bins(h5,rect,pairs[pair])
        stimuli,enc=dsec.encode_inputs(c6,pi)
        expected=anchors['input_pairs'][pair]
        if (enc['sensor_input_sha256']!=expected['sensor_input_sha256'] or
                enc['sensor_spike_total']!=expected['sensor_pulses'] or
                raw['raw_events']!=expected['raw_events']):
            raise RuntimeError('DSEC_FROZEN_PAIR_INPUT_DIGEST_OR_COUNT_MISMATCH')
        source.append({'pair':pair,'raw_events':raw['raw_events'],
                       'sensor_pulses':enc['sensor_spike_total'],
                       'sensor_input_sha256':enc['sensor_input_sha256'],
                       'rectified_valid_events':raw['rectified_valid_events']})
        records={}
        for f in FANOUTS:
            for on in (False,True):
                baseline=lookup[anchor_key(pair,f,on)]
                out,emissions,ticks=run_observed_arm(compute,cfg,stimuli,f,on,baseline)
                tag=f'P{pair}_F{f}_M{int(on)}'
                records[(f,on)]=emissions
                all_emits.extend({'arm':tag,'tick':t,'island':i,'neuron':n,'eid':eid}
                                 for t,i,n,eid in emissions)
                all_events.append({'arm':tag,'source_state_sha256':out['state_sha256'],
                                   'source_trace_sha256':out['trace_sha256'],
                                   'emissions_captured':len(emissions),
                                   'emissions_sha256':dsec.digest(emissions),
                                   'tick_telemetry_sha256':dsec.digest(ticks),
                                   'observer_noninterference':True})
                print('PASSIVE',tag,'EMIT',len(emissions),'STATE',out['state_sha256'][:12],flush=True)
        predictions,counts=targetfree_predictions(c6,pi,stimuli,records)
        projections.append({'pair':pair,'method_flow_digests':{m['method']:m['flow_sha256'] for m in predictions},
                            'emission_counts':counts})
        all_predictions.append({'pair':pair,'predictions':predictions})
    return source,projections,all_emits,all_predictions,all_events


def run(args):
    import h5py
    import hdf5plugin  # registers DSEC compression filters
    out=Path(args.out)
    if out.exists():raise RuntimeError('OUTPUT_EXISTS_NO_OVERWRITE')
    if args.source_root is None:raise RuntimeError('PINNED_ORIGINAL_PE_REQUIRED')
    compute=v0.load_compute(args.source_root)
    anchors,lookup=read_anchors(args.anchors)
    archives=(Path(args.events_zip).expanduser(),Path(args.flow_zip).expanduser())
    dsec.inventory(*archives) # reserved names ONLY, no reserved payloads
    source_files=dsec.prepare_dev(*archives,Path(args.intake).expanduser())
    pairs=dsec.pair_times(Path(source_files['flow/forward_timestamps.txt']['path']))
    with h5py.File(source_files['events/left/events.h5']['path'],'r') as h5, \
         h5py.File(source_files['events/left/rectify_map.h5']['path'],'r') as rm:
        source,projections,emissions,preds,checks=run_four(compute,h5,rm['rectify_map'][:],pairs,anchors)
    if len(checks)!=16 or len(preds)!=4:
        raise RuntimeError('INCOMPLETE_OBSERVER_STAGE_A')
    expected_methods={'ZERO_FLOW_PI','PI_RAW_LOG_COUNT','PI_TOPK_PULSE_COUNT',
                      'C6_TOPK_PULSE_COUNT'} | {f'{geo}_PE_F{f}_M{int(on)}'
                      for geo in ('PI','C6') for f in FANOUTS for on in (False,True)}
    for pair in preds:
        if {m['method'] for m in pair['predictions']}!=expected_methods:
            raise RuntimeError('PREDICTIONS_INCOMPLETE')
    report={
      'schema':SCHEMA,'verdict':'TARGET_FREE_EMISSIONS_AND_COARSE_FLOW_PREDICTIONS_LOCK_PROPOSED_SCIENTIFIC_HOLD',
      'source_main':v0.MAIN,'original_pe_git_blobs':v0.PINS,
      'dev_pairs':[0,1,2,3],'dev_scene':dsec.SEQUENCE,
      'first_4_dev_pairs_already_exposed':True,'fanout4_selected_posthoc_on_pair0':True,
      'original_dev4_report_sha256':ORIGINAL_DEV4_REPORT,
      'baseline_anchors_sha256':dsec.hash_file(args.anchors),
      'sources_sha256':dsec.PINS,
      'source_pairs':source,'observer_checks':checks,
      'projections':projections,
      'all_emissions_rows':len(emissions),'all_emissions_sha256':dsec.digest(emissions),
      'predictions_sha256':dsec.digest(preds),
      'gt_pixels_read':False,'reserved_val_blind_read':False,
      'native_spk_flow_estimation':False,'external_block_matcher':True,
      'spk_learning':False,'bv_messages':0,'p_writes':0,'scientific_go':False,
      'predictive_quality_measured':False,
      'network_transport_is_abstract_logical_clock':True,
    }
    report['canonical_sha256']=dsec.digest(report)
    protocol={
      'schema':SCHEMA+'/protocol',
      'main':v0.MAIN,'original_blobs':v0.PINS,'dsec_member_pins':dsec.PINS,
      'anchors_sha256':dsec.hash_file(args.anchors),
      'scene':dsec.SEQUENCE,'pairs':[0,1,2,3],
      'fanout':[2,4],'mesh':[False,True],
      'pi_width':32,'c6_width':16,'height':16,'polarity':2,
      'temporal_halves':[[1,10],[11,20]],
      'emission_window':'tick1..20 only, all full-trace emissions separately recorded',
      'source_pi_raw':'rectified event-count histogram; exact same sensor input also fed to C6 islands',
      'fixed_transform':'log1p of count array per-half per-cell per-polarity',
      'decoder':'EXTERNAL 3x3 SSE block matcher, offsets dx/dy -2..2; fixed tie (SSE,|dx|+|dy|,dy,dx)',
      'border_behavior':'3-cell border zero, all-zero source-neighborhood zero',
      'flow_factor':'2 x displacement from half-center delta (~50ms) to official pair (~100ms)',
      'pi_cell_pixels':[20,30],'c6_cell_pixels':[40,30],
      'raw_flow_png_read':False,'validation_or_blind_content_read':False,
      'prediction_method_count_per_pair':12,'prediction_count_pairs':4,
      'learning':False,'native_BV':False,'original_P_writes':0,
      'case_status':'DEV_ONLY_TARGET_FREE_PRELOCK_NO_FLOW_SCORING',
      'observer_invariance':'full source result and per-tick history matched against uninstrumented simulation; original 16 anchors pinned',
    }
    out.mkdir(parents=True)
    files={
       'report.json':json.dumps(report,sort_keys=True,indent=2)+'\n',
       'protocol.json':json.dumps(protocol,sort_keys=True,indent=2)+'\n',
       'predictions.json':json.dumps(preds,sort_keys=True,separators=(',',':'))+'\n',
       'emissions.jsonl':''.join(dsec.canonical(x)+'\n' for x in emissions),
    }
    for name,data in files.items():
        (out/name).write_text(data)
    manifest=('report.json','protocol.json','predictions.json','emissions.jsonl')
    (out/'SHA256SUMS').write_text(''.join(f'{dsec.hash_file(out/name)}  {name}\n' for name in manifest))
    print('TARGET_FREE_STAGE_A_COMPLETE_PENDING_CIAT_CUSTODY_LOCK__NO_GT')
    print('RUN_REPORT_SHA256',report['canonical_sha256'])
    print('PREDICTIONS_SHA256',report['predictions_sha256'])
    print('EMISSION_ROWS',len(emissions))
    print('OUTPUT',out)
    return 0


def cli():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--events-zip',default='~/Scaricati/train_events.zip')
    ap.add_argument('--flow-zip',default='~/Scaricati/train_optical_flow.zip')
    ap.add_argument('--intake',default='~/workspace/spk-dsec-intake')
    ap.add_argument('--source-root',type=Path,required=True)
    ap.add_argument('--anchors',type=Path,default=Path(__file__).with_name('baseline_anchors.json'))
    ap.add_argument('--out',type=Path,required=True)
    return run(ap.parse_args())

if __name__=='__main__':sys.exit(cli())
