"""Offline fixture tests only: never open original DSEC, flow GT, validation or blind."""
from __future__ import annotations
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
import h5py

import spk_dsec_mesh9_readout_stagea_v0 as s
import spk_dsec_mesh9_dev_v0 as dsec
import spk_dsec_mesh9_fanout_diag_v0 as diag
import spk_mesh9_ethgateway_ref_v1 as mesh
from test_spk_dsec_mesh9_fanout_diag_v0 import mirror


class ReadoutInvariantTests(unittest.TestCase):
    def test_source_anchors_read_exact_and_16(self):
        a,look=s.read_anchors(Path(s.__file__).with_name('baseline_anchors.json'))
        self.assertEqual(len(look),16)
        self.assertEqual(a['source_report_canonical_sha256'],s.ORIGINAL_DEV4_REPORT)
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'bad.json';a['arms'].pop()
            p.write_text(json.dumps(a))
            with self.assertRaisesRegex(RuntimeError,'PRIOR_DEV4_BASELINE_ANCHOR_INVALID'):
                s.read_anchors(p)

    def test_passthrough_observer_exact_identity(self):
        cfg=mesh.Config(horizon=28,stimulus_last_tick=20,max_processed_events=1000000)
        stim=((1,8,0,3),(5,0,8,2),(11,8,32,2),(13,3,23,3),(19,4,48,3))
        for f in (2,4):
            for on in (False,True):
                out,rows,ticks=s.run_observed_arm(mirror,cfg,stim,f,on)
                self.assertEqual(len(rows),out['stats'].get('emissions',0))
                self.assertEqual(len(ticks),28)
                self.assertTrue(all(len(e)==4 for e in rows))

    def test_anchor_mismatch_is_fatal(self):
        cfg=mesh.Config(horizon=24,stimulus_last_tick=20,max_processed_events=100000)
        with self.assertRaisesRegex(RuntimeError,'PRIOR_DEV4_STATE_SHA256_MISMATCH'):
            s.run_observed_arm(mirror,cfg,((1,8,0,3),),2,False,
                               {'state_sha256':'0'*64,'trace_sha256':'0'*64,
                                'emissions':1,'events_processed':3})

    def test_grid_round_trip_and_causal_half_split(self):
        source=((1,0,0,2),(1,8,0,3),(10,7,63,1),(11,8,1023,2),(20,7,62,3))
        pi,c6=s.source_pulse_grids(source)
        self.assertEqual(pi[0,0,0,0],3)
        self.assertEqual(pi[1,15,31,1],2)
        self.assertEqual(c6[0,0,0,0],2)
        self.assertEqual(c6[0,15,15,1],1)
        self.assertEqual(c6[1,15,15,0],3)
        pi2,c62,n=s.observed_emission_grids(((1,8,0,11),(20,7,62,12),(21,8,0,13)))
        self.assertEqual(n,2)
        self.assertEqual(int(pi2.sum()),1)
        self.assertEqual(int(c62.sum()),1)

    def test_raw_pi_hist_is_correct_coordinate_order(self):
        x=np.zeros((20,1024),dtype=np.int64)
        n=5*32+4*2+1
        x[0,n]=7
        x[9,n]=3
        x[10,n]=20
        a=s.raw_pi_grid(x)
        self.assertEqual(a.shape,(2,16,32,2))
        self.assertEqual(a[0,4,5,1],10)
        self.assertEqual(a[1,4,5,1],20)

    def test_zero_and_flat_do_not_hallucinate_flow(self):
        x=np.zeros((2,16,32,2),dtype=np.float64)
        self.assertEqual(np.count_nonzero(s.decode_fixed_half_match(x,20,30)),0)
        x[:]=10.0
        self.assertEqual(np.count_nonzero(s.decode_fixed_half_match(x,20,30)),0)

    def test_known_positive_motion_sign_and_scale(self):
        x=np.zeros((2,16,32,2),dtype=np.float64)
        x[0,7,12,0]=50
        x[0,8,11,1]=23
        x[0,6,13,0]=18
        # target shifted RIGHT 1 and DOWN 1 cell; center7,12 -> 40,60 px
        x[1,8,13,0]=50
        x[1,9,12,1]=23
        x[1,7,14,0]=18
        y=s.decode_fixed_half_match(x,20,30)
        self.assertEqual(y[7,12].tolist(),[40,60])
        self.assertEqual(y[0,0].tolist(),[0,0])

    def test_decoder_rejects_invalid_features(self):
        with self.assertRaisesRegex(ValueError,'INVALID_HALF_FEATURE_GRID'):
            s.decode_fixed_half_match(np.zeros((16,32,2)),20,30)
        with self.assertRaisesRegex(ValueError,'INVALID_FEATURE_RANGE'):
            s.decode_fixed_half_match(np.ones((2,16,32,2))*-1,20,30)

    def test_complete_methods_and_no_gt(self):
        pi=np.zeros((20,1024),dtype=np.int64)
        stim=((1,0,8,3),(1,8,256,3),(15,8,257,3))
        cfg=mesh.Config(horizon=25,stimulus_last_tick=20,max_processed_events=1000000)
        emits={}
        for f in s.FANOUTS:
            for on in (False,True):
                _,r,_=s.run_observed_arm(mirror,cfg,stim,f,on)
                emits[(f,on)]=r
        maps,c=s.targetfree_predictions(None,pi,stim,emits)
        self.assertEqual(len(maps),12)
        for m in maps:
            self.assertEqual(len(m['forward_flow_uv_px']),m['grid_width']*m['grid_height'])
            self.assertEqual(m['flow_sha256'],dsec.digest(m['forward_flow_uv_px']))
        self.assertEqual([x['nonzero_flow_cells'] for x in maps if x['method']=='ZERO_FLOW_PI'],[0])

    def test_synthetic_four_h5_windows_16_arm_observer_lock(self):
        with tempfile.TemporaryDirectory() as td:
            fn=Path(td)/'synthetic_events.h5'
            times=[];xs=[];ys=[];ps=[]
            for pair in range(4):
                for j in range(36):
                    times.append(pair*100000+1000+j*1800)
                    xs.append((j*11+pair*7)%640)
                    ys.append((j*5+pair*13)%480)
                    ps.append(j%2)
            with h5py.File(fn,'w') as h:
                g=h.create_group('events');g['t']=np.array(times,dtype=np.int64)
                g['x']=np.array(xs,dtype=np.int32);g['y']=np.array(ys,dtype=np.int32)
                g['p']=np.array(ps,dtype=np.int8);h['t_offset']=np.int64(100000)
            rect=np.zeros((480,640,2),dtype=np.float32)
            rect[:,:,0]=np.arange(640,dtype=np.float32)
            rect[:,:,1]=np.arange(480,dtype=np.float32)[:,None]
            pairs=[(100000+k*100000,200000+k*100000) for k in range(4)]
            cfg=mesh.Config(horizon=64,stimulus_last_tick=24,max_processed_events=1000000)
            anchors={'input_pairs':[],'arms':[]}
            with h5py.File(fn,'r') as h:
                for pair in range(4):
                    c6,pi,raw=dsec.dataset_bins(h,rect,pairs[pair])
                    stim,encoded=dsec.encode_inputs(c6,pi)
                    anchors['input_pairs'].append({'pair':pair,
                       'sensor_input_sha256':encoded['sensor_input_sha256'],
                       'sensor_pulses':encoded['sensor_spike_total'],'raw_events':raw['raw_events']})
                    for f in s.FANOUTS:
                        for on in (False,True):
                            out,_=diag.run_arm(mirror,cfg,stim,f,on)
                            anchors['arms'].append({'pair':pair,'fanout':f,'mesh':on,
                              'state_sha256':out['state_sha256'],'trace_sha256':out['trace_sha256'],
                              'events_processed':out['stats']['events_processed'],
                              'emissions':out['stats'].get('emissions',0)})
                inputs,projections,all_emits,all_preds,checks=s.run_four(mirror,h,rect,pairs,anchors)
            self.assertEqual(len(inputs),4)
            self.assertEqual(len(projections),4)
            self.assertEqual(len(all_preds),4)
            self.assertEqual(len(checks),16)
            self.assertTrue(all(z['observer_noninterference'] for z in checks))
            self.assertEqual(len(all_emits),sum(a['emissions'] for a in anchors['arms']))
            self.assertEqual({len(x['predictions']) for x in all_preds},{12})


if __name__=='__main__':unittest.main()
