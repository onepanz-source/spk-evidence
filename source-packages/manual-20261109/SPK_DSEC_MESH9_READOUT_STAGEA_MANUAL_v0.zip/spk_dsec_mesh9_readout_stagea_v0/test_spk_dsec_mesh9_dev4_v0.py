"""DEV4 new tests: synthetic HDF5 only. Absolutely no DSEC/flow-GT payload read."""
from __future__ import annotations
import tempfile
from pathlib import Path
from unittest import TestCase, mock

import numpy as np
import h5py
import spk_dsec_mesh9_dev_v0 as dsec
import spk_dsec_mesh9_dev4_v0 as dev4
from test_spk_dsec_mesh9_fanout_diag_v0 import mirror


class Dev4Test(TestCase):
    def test_protocol_fixed_and_no_blind(self):
        self.assertEqual(dev4.PAIR_INDICES,(0,1,2,3))
        self.assertEqual(dev4.FANOUTS,(2,4))
        self.assertEqual(dsec.SEQUENCE,'thun_00_a')
        self.assertEqual(dsec.RESERVED,('zurich_city_01_a','zurich_city_02_a'))
        self.assertEqual(dsec.C6_TOPK,8)
        self.assertEqual(dsec.PI_TOPK,32)

    def test_all_four_original_pair0_anchors_are_exact(self):
        self.assertEqual(len(dev4.PAIR0_ANCHOR),4)
        for hashes in dev4.PAIR0_ANCHOR.values():
            self.assertEqual(len(hashes),2)
            self.assertTrue(all(len(h)==64 for h in hashes))

    def test_summary_detects_wrong_input_accounting(self):
        import spk_dsec_mesh9_fanout_diag_v0 as diag
        import spk_mesh9_ethgateway_ref_v1 as mesh
        stim=((1,0,0,1),(1,8,0,2))
        cfg=mesh.Config(horizon=16,stimulus_last_tick=8,max_processed_events=100000)
        result,history=diag.run_arm(mirror,cfg,stim,2,False)
        ok=dev4.summarize(result,history,2,False,0,3)
        self.assertEqual(ok['sensor_created'],3)
        with self.assertRaisesRegex(RuntimeError,'SENSOR_INPUT_COUNT_DIVERGED'):
            dev4.summarize(result,history,2,False,0,4)

    def test_four_synthetic_h5_windows_no_target_data(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'events.h5'
            ts=[]; xs=[]; ys=[]; ps=[]
            for pair in range(4):
                for n in range(30):
                    ts.append(pair*100000 + 1000 + n*2000)
                    xs.append((n*7+pair*17)%640)
                    ys.append((n*3+pair*9)%480)
                    ps.append(n%2)
            with h5py.File(path,'w') as fh:
                ev=fh.create_group('events')
                ev['t']=np.array(ts,dtype=np.int64)
                ev['x']=np.array(xs,dtype=np.int32)
                ev['y']=np.array(ys,dtype=np.int32)
                ev['p']=np.array(ps,dtype=np.int8)
                fh['t_offset']=np.int64(100000)
            rect=np.zeros((480,640,2),dtype=np.float32)
            rect[:,:,0]=np.arange(640,dtype=np.float32)
            rect[:,:,1]=np.arange(480,dtype=np.float32)[:,None]
            pairs=[(100000+i*100000,200000+i*100000) for i in range(4)]
            with h5py.File(path,'r') as fh:
                c6,pi,raw=dsec.dataset_bins(fh,rect,pairs[0])
                stim,enc=dsec.encode_inputs(c6,pi)
                # Synthetic fixture: no provenance claim, disable real pair0 anchors ONLY inside test.
                with mock.patch.object(dev4.diag,'ANCHOR_INPUT_SHA256',enc['sensor_input_sha256']), \
                     mock.patch.object(dev4.diag,'ANCHOR_SENSOR_PULSES',enc['sensor_spike_total']), \
                     mock.patch.object(dev4,'PAIR0_ANCHOR',{}):
                    sources,runs,ticks=dev4.run_four_pairs(mirror,fh,rect,pairs)
            self.assertEqual(len(sources),4)
            self.assertEqual(len(runs),16)
            self.assertEqual(len(ticks),1024)
            self.assertEqual({v['fanout'] for v in runs},{2,4})
            self.assertTrue(all(v['sensor_rejected']==0 for v in runs))
            self.assertEqual([s['raw_event_count'] for s in sources],[30]*4)
            self.assertTrue(all(v['packets_created']==0 for v in runs if not v['mesh_enabled']))

    def test_incomplete_pair_scope_veto(self):
        with self.assertRaisesRegex(RuntimeError,'DEV_PAIR_COUNT_NOT_FOUR'):
            dev4.run_four_pairs(mirror,None,None,[(100000,200000)])
