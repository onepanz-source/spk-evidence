# SPK/* #217: DSEC DEV stage A, osservatore passivo e predizioni PRE-GT

**Esecuzione soltanto manuale su fwork.** Questa fase NON legge pixel di optical flow, NON usa validation/blind, NON apprende e NON scrive BV→P.

## Input e selezione congelata

- `~/Scaricati/train_events.zip` e `~/Scaricati/train_optical_flow.zip`, mai estratti integralmente. Il secondo archivio è letto solo per la lista centrale e i timestamp forward di `thun_00_a`, NON per le PNG con ground truth.
- Soltanto le prime 4 coppie official forward DEV `thun_00_a`; `zurich_city_01_a` e `zurich_city_02_a` sono riservate, solo verifica dei nomi nel central directory ZIP.
- Sorgente originale PE A1b, commit `787c8fbed87c1e2e4b703e985f68ae53c81c8444` e hash Git blob verificati. Simulatore distribuito 9 isole: 8×64 C6 + 1×1024 Pi, gateway Ethernet/Thread NON neuronale, clock logico e code bounded. PE originale solo per `ACC`, `CMP`, `EMIT`, `RESET`.
- *Fanout 4 già scelto post hoc* sulla finestra DEV 0; controllo fanout 2; entrambi mesh OFF/ON. Nessuna validazione indipendente.
- Finestra sensore ~100 ms in 20 intervalli di circa 5 ms; observer seleziona emissioni sino al tick 20 e le raggruppa in metà cronologiche 1–10 e 11–20. Le emissioni dai tick 21–63 sono archiviate ma escluse dalla predizione per non sfruttare attività post-finestra.
- Tutti i 16 casi devono corrispondere ESATTAMENTE alle ancore originali del report #216 (`baseline_anchors.json`): SHA256 di stato, traccia originale, emissioni e eventi. Inoltre, **per ogni caso** viene eseguita una seconda simulazione non osservata: risultato e telemetria devono coincidere. Se non coincidono, STOP e nessuna predizione certificata.

## Decoder ESTERNO e controlli (fissati prima del GT)

Pi: griglia 32×16, polarità doppia, celle 20×30 px. C6: 16×16, polarità doppia, celle 40×30 px.

**12 metodi per coppia**: `ZERO_FLOW_PI`, `PI_RAW_LOG_COUNT`, `PI_TOPK_PULSE_COUNT`, `C6_TOPK_PULSE_COUNT`, più 8 osservazioni originali Pi/C6 PE nei casi `fanout 2/4 × mesh OFF/ON`. Gli ingressi al Pi sono una seconda vista (a risoluzione diversa) degli **stessi** sensori distribuiti ai C6, non informazioni nuove.

Per ogni feature si costruiscono 2 mappe di conteggio, poi `log1p` fisso. Per ciascuna cella interna si confronta un patch 3×3 nella metà iniziale con 25 patch 3×3 candidate della seconda metà (shift dx,dy -2..2), scegliendo per SSE crescente e parità `(abs(dx)+abs(dy), dy, dx)`; margine esterno di 3 celle e patch vuoti ⇒ movimento zero. Displacement ottico in pixel `(2*cell_width*dx, 2*cell_height*dy)` (approssimazione temporale costante da centri separati ~50ms a riferimento forward ~100ms). **Non è un optical flow nativo SPK**, è una previsione esterna fissa, ancora NON valutata con ground truth.

Nota scientifica: `N` del PE è un indice logico non una vera posizione visiva dopo diverse propagazioni ricorrenti. Mappare le emissioni su quella griglia è un'ipotesi falsificabile, non una proprietà garantita del PE.

## Avvio su Fedora fwork

Scaricare prima lo ZIP dal messaggio di ChatGPT in `~/Scaricati`:

```bash
cd ~/Scaricati
unzip SPK_DSEC_MESH9_READOUT_STAGEA_MANUAL_v0.zip
cd spk_dsec_mesh9_readout_stagea_v0
source ~/Scaricati/spk_dsec_mesh9_dev_v0/.venv/bin/activate
bash run_spk_dsec_mesh9_readout_stagea_manual.sh
```

Conclude con un TAR append-only in `~/workspace/spk-manual-runs/*-dsec-mesh9-readout-stagea.tar.gz` e `.tar.gz.sha256`. Il TAR include `report.json`, `protocol.json`, `predictions.json` (tutte le mappe coarse, NO GT), `emissions.jsonl` (tutti gli eventi di emissione con tick/eid/isola/neurone), `console.log`, `SHA256SUMS`.

I vettori di flow restano **predizioni non valutate**. Non avviare alcuno script che legga le PNG DSEC sino a conferma successiva di lock SHA e controllo indipendente su GitHub. La produzione del TAR su fwork **non equivale** ancora al lock GitHub.

## Limitazioni

Nessuna modifica a ISA/PE/Compiler o ai sorgenti precedenti; dati val/blind mai letti; nessun outcome di apprendimento o generalizzazione; nessuna misura di radio reale. No M/W/V, original P_writes0, scientific GO0/3, HOLD revisione umana invariati.
